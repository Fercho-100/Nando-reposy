﻿namespace WebApplication1._6.Clases
{
    public class ClaseAplicaciones2
    {
        public string? NombreAplicacion { get; set; }

        public bool? ActivoAplicacion { get; set; }
    }
}
