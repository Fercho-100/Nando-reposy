﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaCriteriosDelete
    {
        public int IdListaCriterio {  get; set; }
        public string? Criterio { get; set; }


    }
}
