﻿namespace WebApplication1._6.Clases
{
    public class ClaseTabla2
    {
        public int IdPuestosRegionales { get; set; }
        public string? EvaluacionPuesto { get; set; }
        public string? NivelImpacto { get; set; }
        public int IdRiesgo { get; set; }

        public int? empleadoSeleccionado { get; set; }

        public int? selectedPuestoLaboral { get; set; }
    }
}
