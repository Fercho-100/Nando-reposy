﻿namespace WebApplication1._6.Clases
{
    public class ClasePermisos
    {
        public int? id { get; set; }

        public bool? respuesta { get; set; }

    }
}
