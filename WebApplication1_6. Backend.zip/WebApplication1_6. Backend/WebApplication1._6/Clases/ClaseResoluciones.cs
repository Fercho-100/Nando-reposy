﻿namespace WebApplication1._6.Clases
{
    public class ClaseResoluciones
    {


        public int IdResolucion { get; set; }
        public string? Resolucion { get; set; }
    }
}