﻿namespace WebApplication1._6.Clases
{
    public class ClaseTabla2_1
    {
        public int? IdPuestosRegionales { get; set; }

        public int? IdListaCriterios { get; set; }

        public bool? Respuesta { get; set; }
    }
}
