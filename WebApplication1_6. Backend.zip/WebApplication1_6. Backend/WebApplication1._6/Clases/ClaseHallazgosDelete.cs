﻿namespace WebApplication1._6.Clases
{
    public class ClaseHallazgosDelete

    {
        public int IdMatrizHallazgos { get; set; }

        public int IdPuestosRegionales { get; set; }

        public string? NombreAplicacion { get; set; }

        public string? NombreMenu { get; set; }

        public string? NombreSubMenu { get; set; }

        public string? Hallazgo { get; set; }

        public string? NombreCriterio { get; set; }

        public string? Recomendacion { get; set; }

        public string? Descripcion { get; set; }
    }
}
