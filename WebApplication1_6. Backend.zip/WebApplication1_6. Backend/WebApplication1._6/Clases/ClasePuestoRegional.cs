﻿namespace WebApplication1._6.Clases
{
    public class ClasePuestoRegional
    {

        public int? IdPais { get; set; }

        public int? IdEmpresa { get; set; }

        public int? IdDivision { get; set; }

        public int? IdDepto { get; set; }

        public int? IdPuestoLaboral { get; set; }

        public int? NdeUsuarios { get; set; }

    }
}
