﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarNotasInternas
    {
        public int id { get;  set; }
        public string? NotasInternas { get;  set; }
    }
}