﻿namespace WebApplication1._6.Clases
{
    internal class ClaseAplicacionesPais
    {
        public int? IdPais { get; set; }
        public string? NombrePais { get; set; }
        public int? IdAplicacion { get; set; }
        public string? NombreAplicacion { get; set; }
        public int CountIdAplicacion { get; set; }
    }
}