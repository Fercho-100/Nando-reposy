﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarSinHallazgos
    {
        public int? id { get;  set; }

        public int? idAplicacion { get; set; }
        public string? descripcion { get;  set; }
       
    }
}
