﻿namespace WebApplication1._6.Clases
{
    public class ClaseTiempoEstimado
    {
        public int? IdPuestosRegionales { get; set; }

        public int? IdAplicacion { get; set; }

        public string? TiempoEstimado1 { get; set; }
    }
}
