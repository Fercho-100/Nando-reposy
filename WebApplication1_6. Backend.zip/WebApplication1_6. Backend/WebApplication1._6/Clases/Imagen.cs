﻿namespace WebApplication1._6.Clases
{
    public class Imagen
    {
        public byte[]? Evidencia1 { get; set; }
    }
}
