﻿namespace WebApplication1._6.Clases
{
    public class ClaseLogin
    { 
        public string? UsuarioRed { get; set; }
        public string? Contrasenia { get; set; }




    }
}
