﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarTextboxs
    {
        public int id { get;  set; }
        public string? NotasInternas { get;  set; }
        public string? PlanAccion { get;  set; }
        public string? Ticket { get;  set; }
    }
}