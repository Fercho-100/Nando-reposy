﻿namespace WebApplication1._6.Clases
{
    public class ClaseEmpleados
    {
        
        public int value { get; set; }

        public string? UsuarioRed { get; set; }

        public string? label { get; set; }

        public string? CorreoEmpleado { get; set; }

        public bool? ActivoEmpleado { get; set; }
    }
}
