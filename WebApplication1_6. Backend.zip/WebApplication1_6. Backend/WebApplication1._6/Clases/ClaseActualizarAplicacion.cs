﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarAplicacion
    {
        public int? IdMatrizHallazgos { get;  set; }
        public int? IdAplicacion { get;  set; }
    }
}
