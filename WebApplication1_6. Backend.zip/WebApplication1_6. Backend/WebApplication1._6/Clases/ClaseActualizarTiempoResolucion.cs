﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarTiempoResolucion
    {
        public int id { get; set; }

        public string? TiempoResolucion { get; set; }
    }
}