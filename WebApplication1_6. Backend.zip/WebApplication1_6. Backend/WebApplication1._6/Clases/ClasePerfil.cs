﻿namespace WebApplication1._6.Clases
{
    public class ClasePerfil
    {

        public string? NombrePerfil { get; set; }
    }
}
