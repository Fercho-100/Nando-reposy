﻿namespace WebApplication1._6.Clases
{
    public class ClaseTerminosDetalle
    {
        public int? IdPuestosRegionales { get; set; }

        public int? IdListaTerminologia { get; set; }
    }
}
