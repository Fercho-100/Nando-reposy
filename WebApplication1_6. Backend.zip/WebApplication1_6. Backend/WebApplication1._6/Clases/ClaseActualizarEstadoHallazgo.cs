﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarEstadoHallazgo
    {

        public int id { get; set; }

        public string? EstadoHallazgo { get; set; }
    }
}