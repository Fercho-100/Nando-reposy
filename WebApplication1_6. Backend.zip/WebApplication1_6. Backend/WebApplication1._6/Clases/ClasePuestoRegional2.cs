﻿namespace WebApplication1._6.Clases
{
    public class ClasePuestoRegional2
    {
        public int IdPuestosRegionales { get; set; }

        public string? IdPais { get; set; }

        public string? IdEmpresa { get; set; }

        public string? IdResponsable { get; set; }

        public string? IdDivisíon { get; set; }

        public string? IdDepto { get; set; }

        public string? IdPuestoLaboral { get; set; }

        public string? IdInforme { get; set; }

        public DateOnly? FechaAsignacion { get; set; }

        public bool? EstadoAsignacion { get; set; }

        public DateOnly? FechaRevision { get; set; }

        public string? IdRiesgo { get; set; }

        public string? EvaluacionPuesto { get; set; }

        public string? NivelImpacto { get; set; }

        public string? IdEstado { get; set; }

        public DateOnly? FechaFinalizacion { get; set; }

        public string? Encargado { get; set; }

        public string? PuestoEncargado { get; set; }

        public int? NdeUsuarios { get; set; }

    }
}