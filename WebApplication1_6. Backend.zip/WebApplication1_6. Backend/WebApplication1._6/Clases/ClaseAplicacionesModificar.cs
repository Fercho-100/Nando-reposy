﻿namespace WebApplication1._6.Clases
{
    public class ClaseAplicacionesModificar
    {
        public string? NombreAplicacion { get; set; }

        
    }
}
