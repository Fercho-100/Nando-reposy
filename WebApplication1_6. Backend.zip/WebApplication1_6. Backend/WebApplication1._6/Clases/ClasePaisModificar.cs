﻿namespace WebApplication1._6.Clases
{
    public class ClasePaisEliminar
    {
        public string? NombrePais { get; set; }

        public string? AbreviacionPais { get; set; }

        public bool? ActivoPais { get; set; }
    }
}
