﻿namespace WebApplication1._6.Clases
{
    public class ClaseFecha
    {
        public int IdPuestosRegionales { get; set; }
        public String? FechaAsignacion { get; set; }
    }
}
