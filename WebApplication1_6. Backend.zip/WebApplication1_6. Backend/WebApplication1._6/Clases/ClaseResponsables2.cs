﻿namespace WebApplication1._6.Clases
{
    public class ClaseResponsables2
    {


        public int IdResponsable { get; set; }
        public string? NombreNombreResponsable { get; set; }
        public string? Correo { get; set; }
        public string? UsuarioRed { get; set; }
        public int? IdPerfil { get; set; }

        public string? NombrePerfil { get; set; }

        public bool? Activo { get; set; }
    }
}