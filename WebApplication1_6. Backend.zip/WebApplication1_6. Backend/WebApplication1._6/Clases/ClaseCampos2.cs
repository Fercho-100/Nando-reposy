﻿namespace WebApplication1._6.Clases
{
    public class ClaseCampos2
    {
        public int IdPuestosRegionales { get; set; }
        public string Nombrepais { get; set; }


        public string nombreEmpresa { get; set; }


        public string NombrePuestoLaboral { get; set; }


        public string? NombreDivision { get; set; }

        public string? NombreDepto { get; set; }

        public string? NombreEstado { get; set; }

        public int IdEstado { get; set; }
    }
}
