﻿namespace WebApplication1._6.Clases
{
    public class ClaseEstadoSeleccionado
    {

        public int IdEstado { get; set; }

        public string? NombreEstado { get; set; }
    }
}
