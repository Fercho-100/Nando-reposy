﻿namespace WebApplication1._6.Clases
{
    public class ClaseResolucion
    {
        public string? Resolucion { get; set; }

    }
}
