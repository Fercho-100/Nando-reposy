﻿namespace WebApplication1._6.Clases
{
    public class ClaseCampos3
    {
        public string? NombrePais { get; set; }

        public string? NombreEmpresa { get; set; }

        public string? NombreResponsable { get; set; }

        public string? NombreDivision { get; set; }

        public string? NombreDepto { get; set; }

        public string? NombrePuestoLaboral { get; set; }

        public string? IdInforme { get; set; }

        public DateOnly? FechaRevision { get; set; }

        public DateOnly? FechaFinalizacion { get; set; }

        public string? Riesgo { get; set; }

        public string? EvaluacionPuesto { get; set; }

        public string? NivelImpacto { get; set; }

        public string? encargado { get; set; }

        public string? puestoEncargado { get; set; }
    }
}
