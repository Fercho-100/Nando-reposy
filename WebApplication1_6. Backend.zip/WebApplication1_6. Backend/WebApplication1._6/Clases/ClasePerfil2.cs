﻿namespace WebApplication1._6.Clases
{
    public class ClasePerfil2
    {

        public int Id { get; set; }
        public string? nombrePerfil { get; set; }
    }
}