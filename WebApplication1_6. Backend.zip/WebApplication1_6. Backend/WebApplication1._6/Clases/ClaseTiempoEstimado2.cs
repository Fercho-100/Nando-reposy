﻿namespace WebApplication1._6.Clases
{
    public class ClaseTiempoEstimado2
    {
        public string? NombreAplicacion { get; set; }

        public string? TiempoEstimado1 { get; set; }
    }
}
