﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarResponsable
    {
        public int IdPuestosRegionales { get; set; }

        public int? IdResponsable { get; set; }
    }
}
