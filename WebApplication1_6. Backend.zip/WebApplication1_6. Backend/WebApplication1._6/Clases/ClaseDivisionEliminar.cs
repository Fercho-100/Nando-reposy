﻿namespace WebApplication1._6.Clases
{
    public class ClaseDivisionEliminar
    {
        public string? NombreDivision { get; set; }

        public bool? ActivoDivision { get; set; }
    }
}
