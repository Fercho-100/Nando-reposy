﻿namespace WebApplication1._6.Clases
{
    public class ClaseDeptoModificar
    {
        public string? NombreDepto { get; set; }

        public bool? ActivoDepto { get; set; }
    }
}
