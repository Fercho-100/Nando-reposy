﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaCriterio2
    {

        public string? Criterio { get; set; }
        public bool? Respuesta { get; set; }
    }
}
