﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1._6.Clases
{
    public class ClaseRegistro
    {
        [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Solo se permiten letras y espacios.")]
        public string? NombreNombreResponsable { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage = "Ingresa una dirección de correo válida.")]
        public string? Correo { get; set; }

        public string? Contrasenia { get; set; }

        [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Solo se permiten letras y espacios.")]
        public string? UsuarioRed { get; set; }
        public int? IdPerfil { get; set; }

        public bool? Activo {  get; set; }
    }
}
