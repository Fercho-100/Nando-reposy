﻿namespace WebApplication1._6.Clases
{
    public class ClaseSinHallazgosDelete
    {
        public int IdMatrizHallazgos { get; set; }

        public String? NombreAplicacion { get; set; }

        public string? Descripcion { get; set; }

        
    }
}
