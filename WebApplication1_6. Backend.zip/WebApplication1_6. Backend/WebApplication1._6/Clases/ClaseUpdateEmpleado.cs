﻿namespace WebApplication1._6.Clases
{
    public class ClaseUpdateEmpleado
    {
        public int IdPuestosRegionales { get; set; }
        public int IdEmpleado { get; set; }
    }
}
