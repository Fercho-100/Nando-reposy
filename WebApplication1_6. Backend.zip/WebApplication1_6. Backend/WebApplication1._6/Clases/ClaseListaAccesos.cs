﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaAccesos
    {
        public int IdDescripcionAcceso { get; set; }

        public string? DescripcionAcceso1 { get; set; }
    }
}
