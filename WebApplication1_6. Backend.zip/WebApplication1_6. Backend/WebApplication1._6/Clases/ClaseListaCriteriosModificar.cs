﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaCriteriosModificar
    {
        public string? Criterio { get; set; }

        public int Peso { get; set; }

        public bool? Estado { get; set; }

    }
}
