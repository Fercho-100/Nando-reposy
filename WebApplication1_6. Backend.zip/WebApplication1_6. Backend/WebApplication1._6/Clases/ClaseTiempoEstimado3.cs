﻿namespace WebApplication1._6.Clases
{
    public class ClaseTiempoEstimado3
    {
        public int? IdAplicacion { get; set; }

        public string? Aplicacion { get; set; }
    }
}
