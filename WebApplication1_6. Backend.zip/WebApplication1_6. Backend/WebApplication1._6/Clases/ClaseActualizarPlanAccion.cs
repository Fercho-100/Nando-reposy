﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarPlanAccion
    {
        public int id { get; set; }
        public string? PlanAccion { get; set; }
    }
}