﻿namespace WebApplication1._6.Clases
{
    public class ClaseCamposPrueba
    {
        public string? NombrePais { get; set; }

        public string? NombreEmpresa { get; set; }

        public string? NombreResponsable { get; set; }

        public string? NombreDivision { get; set; }

        public string? NombreDepto { get; set; }

        public string? NombrePuestoLaboral { get; set; }

        public string? IdInforme { get; set; }

        public DateOnly? FechaRevision { get; set; }

        public DateOnly? FechaFinalizacion { get; set; }

        public string? Riesgo { get; set; }

        public string? EvaluacionPuesto { get; set; }

        public string? NivelImpacto { get; set; }

        public int? encargado { get; set; }

        public int? puestoEncargado { get; set; }
    }
}
