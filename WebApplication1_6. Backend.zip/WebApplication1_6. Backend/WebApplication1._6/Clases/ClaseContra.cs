﻿namespace WebApplication1._6.Clases
{
    public class ClaseContra
    {
        public string? Contrasenia { get; set; }
    }
}
