﻿namespace WebApplication1._6.Clases
{
    public class ClaseCampos5
    {


        public int id { get; set; }
        public string? puesto { get; set; }
        public string? aplicacion { get; set; }
        public string? menu { get; set; }
        public string? submenu { get; set; }
        public string? hallazgos { get; set; }
        public string? criterio { get; set; }
        public string? recomendaciones { get; set; }
        public string? estado { get; set; }
        public string? empresa { get;  set; }
        public string? pais { get;  set; }
        public int? idPais { get;  set; }
        public int? idEmpresa { get;  set; }
        public int? idPuesto { get;  set; }
        public string? Resolucion { get;  set; }
        public string? EstadoHallazgo { get;  set; }
        public string? Descripcion { get; set; }
        public string? TiempoResolucion { get;  set; }
        public string? EstadoAceptacion { get;  set; }
        public string? NotasInternas { get; set; }

        public string? PlanAccion { get; set; }

        public string? Ticket { get; set; }

    }
}