﻿namespace WebApplication1._6.Clases
{
    public class ClaseCriterioModificar
    {
        public int IdCriterio { get; set; }

        public string? NombreCriterio{ get; set; }

        public bool? ActivoCriterio { get; set; }
    }
}
