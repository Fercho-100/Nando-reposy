﻿namespace WebApplication1._6.Clases
{
    public class ClaseEmpleados2
    {

        public string? UsuarioRed { get; set; }

        public string? NombreEmpleado { get; set; }

        public string? CorreoEmpleado { get; set; }

        public bool? ActivoEmpleado { get; set; }
    }
}
