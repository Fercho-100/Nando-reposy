﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarHallazgos
    {
        public int? id { get;  set; }
        public string? nombreMenu { get;  set; }
        public string? nombreSubMenu { get;  set; }
        public string? hallazgo { get;  set; }
        public string? recomendacion { get;  set; }
    }
}
