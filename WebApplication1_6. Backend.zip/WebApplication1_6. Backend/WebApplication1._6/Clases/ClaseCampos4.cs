﻿namespace WebApplication1._6.Clases
{
    public class ClaseCampos4
    {
        public int IdPuestosRegionales { get; set; }
        public string? Nombrepais { get; set; }


        public string? nombreEmpresa { get; set; }


        public string? NombrePuestoLaboral { get; set; }


        public string? NombreDivision { get; set; }

        public string? NombreDepto { get; set; }

        public string? NombreResponsable { get; set; }
        public DateOnly? FechaRevision { get; set; }

        public string? Estado { get; set; }

    }
}
