﻿namespace WebApplication1._6.Clases
{
    public class ClaseEstado
    {
        public int IdPuestosRegionales { get; set; }

        public int? IdEstado { get; set; }
    }
}
