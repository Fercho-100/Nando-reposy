﻿namespace WebApplication1._6.Clases
{
    public class ClaseHallazgos2
    {
        public int IdMatrizHallazgos { get; set; }

        public int IdAplicacion { get; set; }

        public String? NombreAplicacion { get; set; }

        public string? Descripcion { get; set; }

        
    }
}
