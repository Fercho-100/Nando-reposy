﻿namespace WebApplication1._6.Clases
{
    public class ClaseResponsables
    {
        public int IdResponsable { get; set; }

        public string? NombreNombreResponsable { get; set; }
    }
}
