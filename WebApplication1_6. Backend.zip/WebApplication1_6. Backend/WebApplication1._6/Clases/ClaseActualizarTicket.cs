﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarTicket
    {
        public int id { get; set; }
        public string? Ticket { get; set; }
    }
}