﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarAceptacion
    {

        public int id { get; set; }

        public string? EstadoAceptacion { get; set; }
    }
}