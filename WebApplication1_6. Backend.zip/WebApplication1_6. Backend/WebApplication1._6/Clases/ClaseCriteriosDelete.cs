﻿namespace WebApplication1._6.Clases
{
    public class ClaseCriteriosDelete
    {
        public string? NombreCriterio { get; set; }

        public bool? ActivoCriterio { get; set; }
    }
}
