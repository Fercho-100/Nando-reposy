﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarResolucion
    {

        public int id { get; set; }

        public int resolucion { get; set; }

    }
}