﻿namespace WebApplication1._6.Clases
{
    public class ClaseActualizarCriterio
    {
        public int? IdMatrizHallazgos { get; set; }
        public int? IdCriterio { get; set; }
    }
}
