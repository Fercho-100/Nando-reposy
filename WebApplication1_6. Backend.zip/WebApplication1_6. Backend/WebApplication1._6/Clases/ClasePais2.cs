﻿namespace WebApplication1._6.Clases
{
    public class ClasePais2
    {
        public int IdPais { get; set; }

        public string? NombrePais { get; set; }

        public string? AbreviacionPais { get; set; }

        public bool? ActivoPais { get; set; }
    }
}
