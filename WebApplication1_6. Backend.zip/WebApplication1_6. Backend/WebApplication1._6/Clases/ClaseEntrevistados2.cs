﻿namespace WebApplication1._6.Clases
{
    public class ClaseEntrevistados2
    {

        public int? IdEmpleado { get; set; }

        public string? NombreEmpleado { get; set; }
    }
}
