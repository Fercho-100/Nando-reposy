﻿namespace WebApplication1._6.Clases
{
    public class ClasePuestoLaboral
    {

        public int value { get; set; }

        public string? label { get; set; }

        public bool? ActivoPuestoLaboral { get; set; }
    }
}
