﻿namespace WebApplication1._6.Clases
{
    public class ClasePuestoModificar
    {
        public string? NombrePuestoLaboral { get; set; }

        public bool? ActivoPuestoLaboral { get; set; }
    }
}
