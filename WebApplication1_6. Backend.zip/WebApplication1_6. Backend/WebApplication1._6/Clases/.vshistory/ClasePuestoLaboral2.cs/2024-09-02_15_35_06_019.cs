﻿namespace WebApplication1._6.Clases
{
    public class ClasePuestoLaboral2
    {
        public string? NombrePuestoLaboral { get; set; }
    }
}
