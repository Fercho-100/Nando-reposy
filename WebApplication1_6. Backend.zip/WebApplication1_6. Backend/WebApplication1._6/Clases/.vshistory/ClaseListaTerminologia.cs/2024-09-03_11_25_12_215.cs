﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaTerminologia
    {
        public string? Nombre { get; set; }

        public string? Concepto { get; set; }

        public bool? ActivoLista {  get; set; }
    }
}
