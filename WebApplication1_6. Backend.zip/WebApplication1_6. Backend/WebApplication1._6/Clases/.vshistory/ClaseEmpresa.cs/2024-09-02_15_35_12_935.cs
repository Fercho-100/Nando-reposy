﻿namespace WebApplication1._6.Clases
{
    public class ClaseEmpresa
    {
        public string? NombreEmpresa { get; set; }

        public string? AbreviacionEmpresa { get; set; }
    }
}
