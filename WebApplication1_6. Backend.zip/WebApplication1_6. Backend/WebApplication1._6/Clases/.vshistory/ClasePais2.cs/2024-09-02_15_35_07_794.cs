﻿namespace WebApplication1._6.Clases
{
    public class ClasePais2
    {
        public int IdPais { get; set; }

        public string? NombrePais { get; set; }
    }
}
