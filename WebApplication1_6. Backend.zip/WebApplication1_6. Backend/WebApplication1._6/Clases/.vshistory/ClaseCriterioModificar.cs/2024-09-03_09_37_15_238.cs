﻿namespace WebApplication1._6.Clases
{
    public class ClaseCriterioModificar
    {
        public int IdCriterio { get; set; }

        public string? label { get; set; }

        public bool? ActivoCriterio { get; set; }
    }
}
