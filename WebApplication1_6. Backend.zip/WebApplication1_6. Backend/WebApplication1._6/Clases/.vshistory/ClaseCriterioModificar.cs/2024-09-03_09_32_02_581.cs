﻿namespace WebApplication1._6.Clases
{
    public class ClaseCriterio
    {
        public int IdCriterio { get; set; }

        public string? label { get; set; }

        public bool? ActivoCriterio { get; set; }
    }
}
