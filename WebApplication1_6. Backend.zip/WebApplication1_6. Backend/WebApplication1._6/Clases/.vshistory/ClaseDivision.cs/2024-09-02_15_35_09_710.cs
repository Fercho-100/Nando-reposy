﻿namespace WebApplication1._6.Clases
{
    public class ClaseDivision
    {
        public int IdDivision { get; set; }

        public string? NombreDivision { get; set; }
    }
}
