﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaTerminologia2
    {
        public string? Nombre { get; set; }

        public string? Concepto { get; set; }

        public bool? ActivoLista
    }
}
