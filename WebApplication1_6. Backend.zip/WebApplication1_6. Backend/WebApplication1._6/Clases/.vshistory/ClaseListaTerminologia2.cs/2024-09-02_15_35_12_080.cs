﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaTerminologia2
    {
        public int? value { get; set; }

        public string? label { get; set; }
    }
}
