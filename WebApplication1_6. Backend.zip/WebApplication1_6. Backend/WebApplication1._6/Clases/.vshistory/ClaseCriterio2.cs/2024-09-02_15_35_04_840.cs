﻿namespace WebApplication1._6.Clases
{
    public class ClaseCriterio2
    {
        public string? NombreCriterio { get; set; }
    }
}
