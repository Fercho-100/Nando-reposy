﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaTerminologiaModificar
    {
        public int? Nombre { get; set; }

        public string? Concepto { get; set; }

        
    }
}
