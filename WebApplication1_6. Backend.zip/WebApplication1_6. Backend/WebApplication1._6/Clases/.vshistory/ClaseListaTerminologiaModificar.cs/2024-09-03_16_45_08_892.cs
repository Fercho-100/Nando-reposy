﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaTerminologiaModificar
    {
        public int? value { get; set; }

        public string? label { get; set; }

        public bool? ActivoLista { get; set; }
    }
}
