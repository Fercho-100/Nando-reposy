﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaCriterios
    {
        public int IdListaCriterios { get; set; }

        public string? Criterio { get; set; }
    }
}
