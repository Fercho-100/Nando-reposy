﻿namespace WebApplication1._6.Clases
{
    public class ClaseEmpresa2
    {
        public int IdEmpresa { get; set; }

        public string? NombreEmpresa { get; set; }

        public string? AbreviacionEmpresa
    }
}
