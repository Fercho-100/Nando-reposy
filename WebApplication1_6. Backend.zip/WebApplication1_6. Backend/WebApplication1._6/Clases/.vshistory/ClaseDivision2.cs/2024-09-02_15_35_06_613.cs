﻿namespace WebApplication1._6.Clases
{
    public class ClaseDivision2
    {
        public string? NombreDivision { get; set; }
    }
}
