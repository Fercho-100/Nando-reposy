﻿namespace WebApplication1._6.Clases
{
    public class ClaseAplicaciones
    {
        public int IdAplicacion { get; set; }

        public string? label { get; set; }
    }
}
