﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaTerminologia3
    {
        public string? Nombre { get; set; }

        public string? Concepto { get; set; }
    }
}
