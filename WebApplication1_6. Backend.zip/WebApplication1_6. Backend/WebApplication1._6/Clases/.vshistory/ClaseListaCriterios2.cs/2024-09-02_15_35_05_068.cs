﻿namespace WebApplication1._6.Clases
{
    public class ClaseListaCriterios2
    {
        public string? Criterio { get; set; }

    }
}
