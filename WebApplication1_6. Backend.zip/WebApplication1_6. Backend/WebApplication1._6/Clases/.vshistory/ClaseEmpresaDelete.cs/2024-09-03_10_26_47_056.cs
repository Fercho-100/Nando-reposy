﻿namespace WebApplication1._6.Clases
{
    public class ClaseModificarEmpresa
    {
        public int IdEmpresa { get; set; }

        public string? NombreEmpresa { get; set; }

        public string? AbreviacionEmpresa { get; set; }

        public bool? ActivoEmpresa { get; set; }
    }
}
