﻿namespace WebApplication1._6.Clases
{
    public class ClasePuestoLaboralModificar
    {
        public string? NombrePuestoLaboral { get; set; }

        public bool? ActivoPuestoLaboral { get; set; }
    }
}
