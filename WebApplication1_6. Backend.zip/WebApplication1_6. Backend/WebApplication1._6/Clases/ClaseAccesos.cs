﻿namespace WebApplication1._6.Clases
{
    public class ClaseAccesos
    {
        public int? IdPerfil { get;  set; }
        public int? IdDescripcionAccesos { get; set; }
        public string? DescripcionAcceso { get; set; }
    }
}
