﻿namespace WebApplication1._6.Clases
{
    public class ClaseMatriz
    {
        public int? IdPuestosRegionales { get; set; }

        public int? IdAplicacion { get; set; }

        public string? NombreMenu { get; set; }

        public string? NombreSubMenu { get; set; }

        public string? Hallazgo { get; set; }

        public int? IdCriterio { get; set; }

        public string? Recomendacion { get; set; }

        public string? Descripcion { get; set; }

        public string? NombreAplicacion { get; set; }
        public string? NombreCriterio { get; set; }

    }
}
