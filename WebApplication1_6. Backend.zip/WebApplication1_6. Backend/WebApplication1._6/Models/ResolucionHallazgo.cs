﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class ResolucionHallazgo
{
    public int IdResolucion { get; set; }

    public string? Resolucion { get; set; }

    public virtual ICollection<MatrizHallazgo> MatrizHallazgos { get; set; } = new List<MatrizHallazgo>();
}
