﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class PuestosRegionale
{
    public int IdPuestosRegionales { get; set; }

    public int? IdPais { get; set; }

    public int? IdEmpresa { get; set; }

    public int? IdResponsable { get; set; }

    public int? IdDivision { get; set; }

    public int? IdDepto { get; set; }

    public int? IdPuestoLaboral { get; set; }

    public string? IdInforme { get; set; }

    public DateOnly? FechaAsignacion { get; set; }

    public bool? EstadoAsignacion { get; set; }

    public DateOnly? FechaRevision { get; set; }

    public int? IdRiesgo { get; set; }

    public string? EvaluacionPuesto { get; set; }

    public string? NivelImpacto { get; set; }

    public int? IdEstado { get; set; }

    public DateOnly? FechaFinalizacion { get; set; }

    public int? Encargado { get; set; }

    public int? PuestoEncargado { get; set; }

    public int? NdeUsuarios { get; set; }

    public virtual ICollection<CriteriosDetalle> CriteriosDetalles { get; set; } = new List<CriteriosDetalle>();

    public virtual Empleado? EncargadoNavigation { get; set; }

    public virtual ICollection<Entrevistado> Entrevistados { get; set; } = new List<Entrevistado>();

    public virtual Depto? IdDeptoNavigation { get; set; }

    public virtual Division? IdDivisionNavigation { get; set; }

    public virtual Empresa? IdEmpresaNavigation { get; set; }

    public virtual Estado? IdEstadoNavigation { get; set; }

    public virtual Pai? IdPaisNavigation { get; set; }

    public virtual PuestoLaboral? IdPuestoLaboralNavigation { get; set; }

    public virtual Responsable? IdResponsableNavigation { get; set; }

    public virtual Riesgo? IdRiesgoNavigation { get; set; }

    public virtual ICollection<MatrizHallazgo> MatrizHallazgos { get; set; } = new List<MatrizHallazgo>();

    public virtual PuestoLaboral? PuestoEncargadoNavigation { get; set; }

    public virtual ICollection<TerminologiaDetalle> TerminologiaDetalles { get; set; } = new List<TerminologiaDetalle>();

    public virtual ICollection<TiempoEstimado> TiempoEstimados { get; set; } = new List<TiempoEstimado>();
}
