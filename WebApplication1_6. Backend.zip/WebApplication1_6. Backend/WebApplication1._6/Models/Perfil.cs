﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Perfil
{
    public int IdPerfil { get; set; }

    public string? NombrePerfil { get; set; }

    public virtual ICollection<PermisosPerfil> PermisosPerfils { get; set; } = new List<PermisosPerfil>();

    public virtual ICollection<Responsable> Responsables { get; set; } = new List<Responsable>();
}
