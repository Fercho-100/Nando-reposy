﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Evidencia
{
    public int IdEvidencias { get; set; }

    public int? IdMatrizHallazgos { get; set; }

    public byte[]? Evidencia1 { get; set; }

    public virtual MatrizHallazgo? IdMatrizHallazgosNavigation { get; set; }
}
