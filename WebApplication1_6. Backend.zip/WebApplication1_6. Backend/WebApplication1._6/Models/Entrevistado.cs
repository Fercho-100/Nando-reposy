﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Entrevistado
{
    public int IdEntrevistados { get; set; }

    public int? IdPuestosRegionales { get; set; }

    public int? IdEmpleado { get; set; }

    public virtual Empleado? IdEmpleadoNavigation { get; set; }

    public virtual PuestosRegionale? IdPuestosRegionalesNavigation { get; set; }
}
