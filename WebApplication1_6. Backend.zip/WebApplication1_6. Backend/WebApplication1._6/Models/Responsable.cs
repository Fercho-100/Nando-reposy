﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Responsable
{
    public int IdResponsable { get; set; }

    public string? NombreNombreResponsable { get; set; }

    public string? Correo { get; set; }

    public string? Contrasenia { get; set; }

    public string? UsuarioRed { get; set; }

    public int? IdPerfil { get; set; }

    public bool? Activo { get; set; }

    public virtual Perfil? IdPerfilNavigation { get; set; }

    public virtual ICollection<PuestosRegionale> PuestosRegionales { get; set; } = new List<PuestosRegionale>();
}
