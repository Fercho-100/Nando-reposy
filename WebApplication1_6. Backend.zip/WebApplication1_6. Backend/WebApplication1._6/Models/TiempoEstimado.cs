﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class TiempoEstimado
{
    public int IdTiempoEstimado { get; set; }

    public int? IdPuestosRegionales { get; set; }

    public int? IdAplicacion { get; set; }

    public string? TiempoEstimado1 { get; set; }

    public virtual Aplicacion? IdAplicacionNavigation { get; set; }

    public virtual PuestosRegionale? IdPuestosRegionalesNavigation { get; set; }
}
