﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class ListaCriterio
{
    public int IdListaCriterios { get; set; }

    public string? Criterio { get; set; }

    public int? Peso { get; set; }

    public bool? Estado { get; set; }

    public virtual ICollection<CriteriosDetalle> CriteriosDetalles { get; set; } = new List<CriteriosDetalle>();
}
