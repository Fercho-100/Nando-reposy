﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class PermisosPerfil
{
    public int IdPermisosPerfil { get; set; }

    public int? IdPerfil { get; set; }

    public int? IdDescripcionAcceso { get; set; }

    public bool? Acceso { get; set; }

    public virtual DescripcionAcceso? IdDescripcionAccesoNavigation { get; set; }

    public virtual Perfil? IdPerfilNavigation { get; set; }
}
