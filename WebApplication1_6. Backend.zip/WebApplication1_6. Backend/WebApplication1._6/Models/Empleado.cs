﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Empleado
{
    public int IdEmpleado { get; set; }

    public string? UsuarioRed {  get; set; }

    public string? NombreEmpleado { get; set; }

    public string? CorreoEmpleado { get; set; }

    public bool? ActivoEmpleado { get; set; }

    public virtual ICollection<Entrevistado> Entrevistados { get; set; } = new List<Entrevistado>();

    public virtual ICollection<PuestosRegionale> PuestosRegionales { get; set; } = new List<PuestosRegionale>();
}
