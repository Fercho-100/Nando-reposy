﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Pai
{
    public int IdPais { get; set; }

    public string? NombrePais { get; set; }

    public string? AbreviacionPais { get; set; }

    public bool? ActivoPais { get; set; }

    public virtual ICollection<PuestosRegionale> PuestosRegionales { get; set; } = new List<PuestosRegionale>();
}
