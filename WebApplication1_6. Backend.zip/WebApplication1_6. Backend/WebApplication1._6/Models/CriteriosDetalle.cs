﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class CriteriosDetalle
{
    public int IdCriteriosDetalle { get; set; }

    public int? IdPuestosRegionales { get; set; }

    public int? IdListaCriterios { get; set; }

    public bool? Respuesta { get; set; }

    public virtual ListaCriterio? IdListaCriteriosNavigation { get; set; }

    public virtual PuestosRegionale? IdPuestosRegionalesNavigation { get; set; }
}
