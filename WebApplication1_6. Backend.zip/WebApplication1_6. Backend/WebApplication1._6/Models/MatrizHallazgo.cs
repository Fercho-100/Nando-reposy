﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class MatrizHallazgo
{
    public int IdMatrizHallazgos { get; set; }

    public int? IdPuestosRegionales { get; set; }

    public int? IdAplicacion { get; set; }

    public string? NombreMenu { get; set; }

    public string? NombreSubMenu { get; set; }

    public string? Hallazgo { get; set; }

    public int? IdCriterio { get; set; }

    public string? Recomendación { get; set; }

    public string? EstadoHallazgo { get; set; }

    public string? Descripcion { get; set; }

    public int? Resolucion { get; set; }

    public string? EstadoAceptacion { get; set; }

    public string? TiempoResolucion { get; set; }

    public string? NotasInternas { get; set; }

    public string? PlanAccion { get; set; }

    public string? Ticket { get; set; }


    public virtual ICollection<Evidencia> Evidencia { get; set; } = new List<Evidencia>();

    public virtual Aplicacion? IdAplicacionNavigation { get; set; }

    public virtual Criterio? IdCriterioNavigation { get; set; }

    public virtual PuestosRegionale? IdPuestosRegionalesNavigation { get; set; }

    public virtual ResolucionHallazgo? ResolucionNavigation { get; set; }
   
}
