﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Empresa
{
    public int IdEmpresa { get; set; }

    public string? NombreEmpresa { get; set; }

    public string? AbreviacionEmpresa { get; set; }

    public virtual ICollection<PuestosRegionale> PuestosRegionales { get; set; } = new List<PuestosRegionale>();
}
