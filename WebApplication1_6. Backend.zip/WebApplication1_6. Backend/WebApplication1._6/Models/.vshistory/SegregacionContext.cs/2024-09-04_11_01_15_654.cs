﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1._6.Models;

public partial class SegregacionContext : DbContext
{
    public SegregacionContext()
    {
    }

    public SegregacionContext(DbContextOptions<SegregacionContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Aplicacion> Aplicacions { get; set; }

    public virtual DbSet<Criterio> Criterios { get; set; }

    public virtual DbSet<CriteriosDetalle> CriteriosDetalles { get; set; }

    public virtual DbSet<Depto> Deptos { get; set; }

    public virtual DbSet<DescripcionAcceso> DescripcionAccesos { get; set; }

    public virtual DbSet<Division> Divisions { get; set; }

    public virtual DbSet<Empleado> Empleados { get; set; }

    public virtual DbSet<Empresa> Empresas { get; set; }

    public virtual DbSet<Entrevistado> Entrevistados { get; set; }

    public virtual DbSet<Estado> Estados { get; set; }

    public virtual DbSet<Evidencia> Evidencias { get; set; }

    public virtual DbSet<ListaCriterio> ListaCriterios { get; set; }

    public virtual DbSet<ListaTerminologium> ListaTerminologia { get; set; }

    public virtual DbSet<MatrizHallazgo> MatrizHallazgos { get; set; }

    public virtual DbSet<Pai> Pais { get; set; }

    public virtual DbSet<Perfil> Perfils { get; set; }

    public virtual DbSet<PermisosPerfil> PermisosPerfils { get; set; }

    public virtual DbSet<PuestoLaboral> PuestoLaborals { get; set; }

    public virtual DbSet<PuestosRegionale> PuestosRegionales { get; set; }

    public virtual DbSet<ResolucionHallazgo> ResolucionHallazgos { get; set; }

    public virtual DbSet<Responsable> Responsables { get; set; }

    public virtual DbSet<Riesgo> Riesgos { get; set; }

    public virtual DbSet<TerminologiaDetalle> TerminologiaDetalles { get; set; }

    public virtual DbSet<TiempoEstimado> TiempoEstimados { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=HNBNL1001PTC02\\SQLEXPRESS; Database=scriptBDSegregacionUltima; Integrated Security=true; TrustServerCertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Aplicacion>(entity =>
        {
            entity.HasKey(e => e.IdAplicacion).HasName("PK__Aplicaci__8B37C7D1D5DC7CFB");

            entity.ToTable("Aplicacion");

            entity.Property(e => e.IdAplicacion).HasColumnName("Id_aplicacion");
            entity.Property(e => e.NombreAplicacion)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombreAplicacion");
        });

        modelBuilder.Entity<Criterio>(entity =>
        {
            entity.HasKey(e => e.IdCriterio).HasName("PK__Criterio__E53AE756E8955D5F");

            entity.ToTable("Criterio");

            entity.Property(e => e.IdCriterio).HasColumnName("Id_criterio");
            entity.Property(e => e.NombreCriterio)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombreCriterio");
        });

        modelBuilder.Entity<CriteriosDetalle>(entity =>
        {
            entity.HasKey(e => e.IdCriteriosDetalle).HasName("PK__Criterio__D6C323465D0CC7B8");

            entity.ToTable("CriteriosDetalle");

            entity.Property(e => e.IdCriteriosDetalle).HasColumnName("Id_criteriosDetalle");
            entity.Property(e => e.IdListaCriterios).HasColumnName("Id_listaCriterios");
            entity.Property(e => e.IdPuestosRegionales).HasColumnName("Id_puestosRegionales");
            entity.Property(e => e.Respuesta).HasColumnName("respuesta");

            entity.HasOne(d => d.IdListaCriteriosNavigation).WithMany(p => p.CriteriosDetalles)
                .HasForeignKey(d => d.IdListaCriterios)
                .HasConstraintName("FK__Criterios__Id_li__48CFD27E");

            entity.HasOne(d => d.IdPuestosRegionalesNavigation).WithMany(p => p.CriteriosDetalles)
                .HasForeignKey(d => d.IdPuestosRegionales)
                .HasConstraintName("FK__Criterios__Id_pu__47DBAE45");
        });

        modelBuilder.Entity<Depto>(entity =>
        {
            entity.HasKey(e => e.IdDepto).HasName("PK__Depto__EDAC113FA30D7568");

            entity.ToTable("Depto");

            entity.Property(e => e.IdDepto).HasColumnName("Id_depto");
            entity.Property(e => e.NombreDepto)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombreDepto");
        });

        modelBuilder.Entity<DescripcionAcceso>(entity =>
        {
            entity.HasKey(e => e.IdDescripcionAcceso).HasName("PK__Descripc__8FD3EC28F51E6A2C");

            entity.ToTable("DescripcionAcceso");

            entity.Property(e => e.IdDescripcionAcceso).HasColumnName("Id_DescripcionAcceso");
            entity.Property(e => e.DescripcionAcceso1)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("DescripcionAcceso");
        });

        modelBuilder.Entity<Division>(entity =>
        {
            entity.HasKey(e => e.IdDivision).HasName("PK__Division__E1A3AA25D921A200");

            entity.ToTable("Division");

            entity.Property(e => e.IdDivision).HasColumnName("Id_division");
            entity.Property(e => e.NombreDivision)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombreDivision");
        });

        modelBuilder.Entity<Empleado>(entity =>
        {
            entity.HasKey(e => e.IdEmpleado).HasName("PK__Empleado__01AC2829EFB63FE0");

            entity.ToTable("Empleado");

            entity.Property(e => e.IdEmpleado)
                .ValueGeneratedNever()
                .HasColumnName("Id_empleado");
            entity.Property(e => e.CorreoEmpleado)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("correoEmpleado");
            entity.Property(e => e.NombreEmpleado)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombreEmpleado");
        });

        modelBuilder.Entity<Empresa>(entity =>
        {
            entity.HasKey(e => e.IdEmpresa).HasName("PK__Empresa__AF698F548C8796B4");

            entity.ToTable("Empresa");

            entity.Property(e => e.IdEmpresa).HasColumnName("Id_empresa");
            entity.Property(e => e.AbreviacionEmpresa)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("abreviacionEmpresa");
            entity.Property(e => e.NombreEmpresa)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nombreEmpresa");
        });

        modelBuilder.Entity<Entrevistado>(entity =>
        {
            entity.HasKey(e => e.IdEntrevistados).HasName("PK__Entrevis__8DBE7F88D93BE958");

            entity.Property(e => e.IdEntrevistados).HasColumnName("Id_Entrevistados");
            entity.Property(e => e.IdEmpleado).HasColumnName("Id_Empleado");
            entity.Property(e => e.IdPuestosRegionales).HasColumnName("Id_puestosRegionales");

            entity.HasOne(d => d.IdEmpleadoNavigation).WithMany(p => p.Entrevistados)
                .HasForeignKey(d => d.IdEmpleado)
                .HasConstraintName("FK__Entrevist__Id_Em__5165187F");

            entity.HasOne(d => d.IdPuestosRegionalesNavigation).WithMany(p => p.Entrevistados)
                .HasForeignKey(d => d.IdPuestosRegionales)
                .HasConstraintName("FK__Entrevist__Id_pu__5070F446");
        });

        modelBuilder.Entity<Estado>(entity =>
        {
            entity.HasKey(e => e.IdEstado).HasName("PK__Estado__AD3E5E1BB425DDD0");

            entity.ToTable("Estado");

            entity.Property(e => e.IdEstado).HasColumnName("Id_estado");
            entity.Property(e => e.NombreEstado)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nombre_estado");
        });

        modelBuilder.Entity<Evidencia>(entity =>
        {
            entity.HasKey(e => e.IdEvidencias).HasName("PK__Evidenci__B769C35008250D97");

            entity.Property(e => e.IdEvidencias).HasColumnName("Id_Evidencias");
            entity.Property(e => e.Evidencia1).HasColumnName("Evidencia");
            entity.Property(e => e.IdMatrizHallazgos).HasColumnName("Id_matrizHallazgos");

            entity.HasOne(d => d.IdMatrizHallazgosNavigation).WithMany(p => p.Evidencia)
                .HasForeignKey(d => d.IdMatrizHallazgos)
                .HasConstraintName("FK__Evidencia__Id_ma__66603565");
        });

        modelBuilder.Entity<ListaCriterio>(entity =>
        {
            entity.HasKey(e => e.IdListaCriterios).HasName("PK__ListaCri__CDDE815900365D96");

            entity.Property(e => e.IdListaCriterios).HasColumnName("Id_listaCriterios");
            entity.Property(e => e.Criterio)
                .HasMaxLength(300)
                .IsUnicode(false)
                .HasColumnName("criterio");
            entity.Property(e => e.Estado).HasColumnName("estado");
        });

        modelBuilder.Entity<ListaTerminologium>(entity =>
        {
            entity.HasKey(e => e.IdListaTerminologia).HasName("PK__ListaTer__18FFADFB97820B21");

            entity.Property(e => e.IdListaTerminologia).HasColumnName("Id_listaTerminologia");
            entity.Property(e => e.Concepto)
                .IsUnicode(false)
                .HasColumnName("concepto");
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nombre");
        });

        modelBuilder.Entity<MatrizHallazgo>(entity =>
        {
            entity.HasKey(e => e.IdMatrizHallazgos).HasName("PK__MatrizHa__0B92AD9844722D4A");

            entity.Property(e => e.IdMatrizHallazgos).HasColumnName("Id_matrizHallazgos");
            entity.Property(e => e.Descripcion)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.EstadoHallazgo).HasColumnName("estadoHallazgo");
            entity.Property(e => e.Hallazgo)
                .IsUnicode(false)
                .HasColumnName("hallazgo");
            entity.Property(e => e.IdAplicacion).HasColumnName("Id_aplicacion");
            entity.Property(e => e.IdCriterio).HasColumnName("Id_criterio");
            entity.Property(e => e.IdPuestosRegionales).HasColumnName("Id_puestosRegionales");
            entity.Property(e => e.NombreMenu)
                .IsUnicode(false)
                .HasColumnName("nombreMenu");
            entity.Property(e => e.NombreSubMenu)
                .IsUnicode(false)
                .HasColumnName("nombreSubMenu");
            entity.Property(e => e.Recomendación)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("recomendación");
            entity.Property(e => e.Resolucion).HasDefaultValue(1);

            entity.HasOne(d => d.IdAplicacionNavigation).WithMany(p => p.MatrizHallazgos)
                .HasForeignKey(d => d.IdAplicacion)
                .HasConstraintName("FK__MatrizHal__Id_ap__4CA06362");

            entity.HasOne(d => d.IdCriterioNavigation).WithMany(p => p.MatrizHallazgos)
                .HasForeignKey(d => d.IdCriterio)
                .HasConstraintName("FK__MatrizHal__Id_cr__4D94879B");

            entity.HasOne(d => d.IdPuestosRegionalesNavigation).WithMany(p => p.MatrizHallazgos)
                .HasForeignKey(d => d.IdPuestosRegionales)
                .HasConstraintName("FK__MatrizHal__Id_pu__4BAC3F29");

            entity.HasOne(d => d.ResolucionNavigation).WithMany(p => p.MatrizHallazgos)
                .HasForeignKey(d => d.Resolucion)
                .HasConstraintName("fk_Resolucion_Hallazgo");
        });

        modelBuilder.Entity<Pai>(entity =>
        {
            entity.HasKey(e => e.IdPais).HasName("PK__Pais__405FEBA903CE8B33");

            entity.Property(e => e.IdPais).HasColumnName("Id_pais");
            entity.Property(e => e.AbreviacionPais)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("abreviacionPais");
            entity.Property(e => e.NombrePais)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nombrePais");
        });

        modelBuilder.Entity<Perfil>(entity =>
        {
            entity.HasKey(e => e.IdPerfil).HasName("PK__Perfil__2CDD94196F8B74FA");

            entity.ToTable("Perfil");

            entity.Property(e => e.IdPerfil).HasColumnName("Id_Perfil");
            entity.Property(e => e.NombrePerfil)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombrePerfil");
        });

        modelBuilder.Entity<PermisosPerfil>(entity =>
        {
            entity.HasKey(e => e.IdPermisosPerfil).HasName("PK__Permisos__FC8EDEE975F3E8BE");

            entity.ToTable("PermisosPerfil");

            entity.Property(e => e.IdPermisosPerfil).HasColumnName("Id_PermisosPerfil");
            entity.Property(e => e.IdDescripcionAcceso).HasColumnName("Id_DescripcionAcceso");
            entity.Property(e => e.IdPerfil).HasColumnName("Id_Perfil");

            entity.HasOne(d => d.IdDescripcionAccesoNavigation).WithMany(p => p.PermisosPerfils)
                .HasForeignKey(d => d.IdDescripcionAcceso)
                .HasConstraintName("FK__PermisosP__Id_De__6383C8BA");

            entity.HasOne(d => d.IdPerfilNavigation).WithMany(p => p.PermisosPerfils)
                .HasForeignKey(d => d.IdPerfil)
                .HasConstraintName("FK__PermisosP__Id_Pe__628FA481");
        });

        modelBuilder.Entity<PuestoLaboral>(entity =>
        {
            entity.HasKey(e => e.IdPuestoLaboral).HasName("PK__PuestoLa__D9D1DB7487389069");

            entity.ToTable("PuestoLaboral");

            entity.Property(e => e.IdPuestoLaboral).HasColumnName("Id_puestoLaboral");
            entity.Property(e => e.NombrePuestoLaboral)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombrePuestoLaboral");
        });

        modelBuilder.Entity<PuestosRegionale>(entity =>
        {
            entity.HasKey(e => e.IdPuestosRegionales).HasName("PK__PuestosR__821129B84B4605AA");

            entity.Property(e => e.IdPuestosRegionales).HasColumnName("Id_puestosRegionales");
            entity.Property(e => e.Encargado).HasColumnName("encargado");
            entity.Property(e => e.EstadoAsignacion)
                .HasDefaultValue(false)
                .HasColumnName("estadoAsignacion");
            entity.Property(e => e.EvaluacionPuesto)
                .IsUnicode(false)
                .HasColumnName("evaluacionPuesto");
            entity.Property(e => e.FechaAsignacion).HasColumnName("fechaAsignacion");
            entity.Property(e => e.IdDepto).HasColumnName("Id_depto");
            entity.Property(e => e.IdDivision).HasColumnName("Id_division");
            entity.Property(e => e.IdEmpresa).HasColumnName("Id_empresa");
            entity.Property(e => e.IdEstado)
                .HasDefaultValue(1)
                .HasColumnName("Id_estado");
            entity.Property(e => e.IdInforme)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Id_informe");
            entity.Property(e => e.IdPais).HasColumnName("Id_pais");
            entity.Property(e => e.IdPuestoLaboral).HasColumnName("Id_puestoLaboral");
            entity.Property(e => e.IdResponsable).HasColumnName("Id_responsable");
            entity.Property(e => e.IdRiesgo).HasColumnName("Id_Riesgo");
            entity.Property(e => e.NivelImpacto)
                .IsUnicode(false)
                .HasColumnName("nivelImpacto");
            entity.Property(e => e.PuestoEncargado).HasColumnName("puestoEncargado");

            entity.HasOne(d => d.EncargadoNavigation).WithMany(p => p.PuestosRegionales)
                .HasForeignKey(d => d.Encargado)
                .HasConstraintName("FK_encargado");

            entity.HasOne(d => d.IdDeptoNavigation).WithMany(p => p.PuestosRegionales)
                .HasForeignKey(d => d.IdDepto)
                .HasConstraintName("FK__PuestosRe__Id_de__3A81B327");

            entity.HasOne(d => d.IdDivisionNavigation).WithMany(p => p.PuestosRegionales)
                .HasForeignKey(d => d.IdDivision)
                .HasConstraintName("FK__PuestosRe__Id_di__398D8EEE");

            entity.HasOne(d => d.IdEmpresaNavigation).WithMany(p => p.PuestosRegionales)
                .HasForeignKey(d => d.IdEmpresa)
                .HasConstraintName("FK__PuestosRe__Id_em__37A5467C");

            entity.HasOne(d => d.IdEstadoNavigation).WithMany(p => p.PuestosRegionales)
                .HasForeignKey(d => d.IdEstado)
                .HasConstraintName("fk_Estado");

            entity.HasOne(d => d.IdPaisNavigation).WithMany(p => p.PuestosRegionales)
                .HasForeignKey(d => d.IdPais)
                .HasConstraintName("FK__PuestosRe__Id_pa__36B12243");

            entity.HasOne(d => d.IdPuestoLaboralNavigation).WithMany(p => p.PuestosRegionaleIdPuestoLaboralNavigations)
                .HasForeignKey(d => d.IdPuestoLaboral)
                .HasConstraintName("FK__PuestosRe__Id_pu__3B75D760");

            entity.HasOne(d => d.IdResponsableNavigation).WithMany(p => p.PuestosRegionales)
                .HasForeignKey(d => d.IdResponsable)
                .HasConstraintName("FK__PuestosRe__Id_re__38996AB5");

            entity.HasOne(d => d.IdRiesgoNavigation).WithMany(p => p.PuestosRegionales)
                .HasForeignKey(d => d.IdRiesgo)
                .HasConstraintName("FK_Id_Riesgo");

            entity.HasOne(d => d.PuestoEncargadoNavigation).WithMany(p => p.PuestosRegionalePuestoEncargadoNavigations)
                .HasForeignKey(d => d.PuestoEncargado)
                .HasConstraintName("FK_puestoEncargado");
        });

        modelBuilder.Entity<ResolucionHallazgo>(entity =>
        {
            entity.HasKey(e => e.IdResolucion).HasName("PK__Resoluci__3AAA29FAB5A9208D");

            entity.ToTable("Resolucion_Hallazgo");

            entity.Property(e => e.IdResolucion).HasColumnName("Id_Resolucion");
            entity.Property(e => e.Resolucion)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Responsable>(entity =>
        {
            entity.HasKey(e => e.IdResponsable).HasName("PK__Responsa__A0F1B35DCB196D4E");

            entity.ToTable("Responsable");

            entity.Property(e => e.IdResponsable).HasColumnName("Id_responsable");
            entity.Property(e => e.Activo).HasDefaultValue(true);
            entity.Property(e => e.Contrasenia)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("contrasenia");
            entity.Property(e => e.Correo)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("correo");
            entity.Property(e => e.IdPerfil)
                .HasDefaultValue(1)
                .HasColumnName("Id_Perfil");
            entity.Property(e => e.NombreNombreResponsable)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombreNombreResponsable");
            entity.Property(e => e.UsuarioRed)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("usuarioRed");

            entity.HasOne(d => d.IdPerfilNavigation).WithMany(p => p.Responsables)
                .HasForeignKey(d => d.IdPerfil)
                .HasConstraintName("fk_Perfil");
        });

        modelBuilder.Entity<Riesgo>(entity =>
        {
            entity.HasKey(e => e.IdRiesgo).HasName("PK__Riesgo__D0F382814D90D844");

            entity.ToTable("Riesgo");

            entity.Property(e => e.IdRiesgo).HasColumnName("Id_Riesgo");
            entity.Property(e => e.Riesgo1)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Riesgo");
        });

        modelBuilder.Entity<TerminologiaDetalle>(entity =>
        {
            entity.HasKey(e => e.IdTerminologiaDetalle).HasName("PK__Terminol__29D970BE1BB35DBC");

            entity.ToTable("TerminologiaDetalle");

            entity.Property(e => e.IdTerminologiaDetalle).HasColumnName("Id_terminologiaDetalle");
            entity.Property(e => e.IdListaTerminologia).HasColumnName("Id_listaTerminologia");
            entity.Property(e => e.IdPuestosRegionales).HasColumnName("Id_puestosRegionales");

            entity.HasOne(d => d.IdListaTerminologiaNavigation).WithMany(p => p.TerminologiaDetalles)
                .HasForeignKey(d => d.IdListaTerminologia)
                .HasConstraintName("FK__Terminolo__Id_li__44FF419A");

            entity.HasOne(d => d.IdPuestosRegionalesNavigation).WithMany(p => p.TerminologiaDetalles)
                .HasForeignKey(d => d.IdPuestosRegionales)
                .HasConstraintName("FK__Terminolo__Id_pu__440B1D61");
        });

        modelBuilder.Entity<TiempoEstimado>(entity =>
        {
            entity.HasKey(e => e.IdTiempoEstimado).HasName("PK__TiempoEs__E7C1A4B195107DA3");

            entity.ToTable("TiempoEstimado");

            entity.Property(e => e.IdTiempoEstimado).HasColumnName("Id_TiempoEstimado");
            entity.Property(e => e.IdAplicacion).HasColumnName("Id_aplicacion");
            entity.Property(e => e.IdPuestosRegionales).HasColumnName("Id_puestosRegionales");
            entity.Property(e => e.TiempoEstimado1)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("TiempoEstimado");

            entity.HasOne(d => d.IdAplicacionNavigation).WithMany(p => p.TiempoEstimados)
                .HasForeignKey(d => d.IdAplicacion)
                .HasConstraintName("FK__TiempoEst__Id_ap__59FA5E80");

            entity.HasOne(d => d.IdPuestosRegionalesNavigation).WithMany(p => p.TiempoEstimados)
                .HasForeignKey(d => d.IdPuestosRegionales)
                .HasConstraintName("FK__TiempoEst__Id_pu__59063A47");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
