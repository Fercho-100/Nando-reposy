﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Criterio
{
    public int IdCriterio { get; set; }

    public string? NombreCriterio { get; set; }

    public virtual ICollection<MatrizHallazgo> MatrizHallazgos { get; set; } = new List<MatrizHallazgo>();
}
