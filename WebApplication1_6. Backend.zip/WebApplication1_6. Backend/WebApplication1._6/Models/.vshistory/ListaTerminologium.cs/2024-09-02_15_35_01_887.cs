﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class ListaTerminologium
{
    public int IdListaTerminologia { get; set; }

    public string? Nombre { get; set; }

    public string? Concepto { get; set; }

    public virtual ICollection<TerminologiaDetalle> TerminologiaDetalles { get; set; } = new List<TerminologiaDetalle>();
}
