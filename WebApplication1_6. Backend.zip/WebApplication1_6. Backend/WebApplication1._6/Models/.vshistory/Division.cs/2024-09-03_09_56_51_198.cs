﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class Division
{
    public int IdDivision { get; set; }

    public string? NombreDivision { get; set; }

    public bool? ActivoDivision

    public virtual ICollection<PuestosRegionale> PuestosRegionales { get; set; } = new List<PuestosRegionale>();
}
