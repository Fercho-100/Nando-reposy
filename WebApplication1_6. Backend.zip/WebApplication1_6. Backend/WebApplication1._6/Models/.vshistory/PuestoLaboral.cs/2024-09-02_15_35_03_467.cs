﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class PuestoLaboral
{
    public int IdPuestoLaboral { get; set; }

    public string? NombrePuestoLaboral { get; set; }

    public virtual ICollection<PuestosRegionale> PuestosRegionaleIdPuestoLaboralNavigations { get; set; } = new List<PuestosRegionale>();

    public virtual ICollection<PuestosRegionale> PuestosRegionalePuestoEncargadoNavigations { get; set; } = new List<PuestosRegionale>();
}
