﻿using System;
using System.Collections.Generic;

namespace WebApplication1._6.Models;

public partial class TerminologiaDetalle
{
    public int IdTerminologiaDetalle { get; set; }

    public int? IdPuestosRegionales { get; set; }

    public int? IdListaTerminologia { get; set; }

    public virtual ListaTerminologium? IdListaTerminologiaNavigation { get; set; }

    public virtual PuestosRegionale? IdPuestosRegionalesNavigation { get; set; }
}
