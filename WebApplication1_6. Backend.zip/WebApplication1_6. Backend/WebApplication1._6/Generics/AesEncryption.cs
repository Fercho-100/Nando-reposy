﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
namespace WebApplication1._6.Generics
{
    // Prototipos encriptacion por AesEncryption
    // No es funcional Actualmente en ninguna parte del codigo y todavia tiene fallos
    
    public class AesEncryption
    {

        private static readonly byte[] Key = Encoding.UTF8.GetBytes("MichaelMendoza11062001"); // Cambia esto por una clave segura
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("Mendoza11062001"); // Cambia esto por un vector inicial seguro

        public static byte[] Encrypt(byte[] data)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        csEncrypt.Write(data, 0, data.Length);
                    }
                    return msEncrypt.ToArray();
                }
            }
        }

        public static byte[] Decrypt(byte[] encryptedData)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msDecrypt = new MemoryStream(encryptedData))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (MemoryStream originalData = new MemoryStream())
                        {
                            csDecrypt.CopyTo(originalData);
                            return originalData.ToArray();
                        }
                    }
                }
            }
        }
    }
}
/*
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace WebApplication1._6.Generics
{
    public class AesEncryption
    {
        // Genera una clave de 128 bits (16 bytes)
        private static readonly byte[] Key = GenerateSecureKey(16);

        // Genera un IV de 128 bits (16 bytes)
        private static readonly byte[] IV = GenerateSecureKey(16);

        private static byte[] GenerateSecureKey(int length)
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                byte[] key = new byte[length];
                rng.GetBytes(key);
                return key;
            }
        }

        public static byte[] Encrypt(byte[] data)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        csEncrypt.Write(data, 0, data.Length);
                    }
                    return msEncrypt.ToArray();
                }
            }
        }

        public static byte[] Decrypt(byte[] encryptedData)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key; // Asegúrate de que Key e IV sean los mismos que se usaron para cifrar los datos
                aesAlg.IV = IV;

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msDecrypt = new MemoryStream(encryptedData))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (MemoryStream originalData = new MemoryStream())
                        {
                            csDecrypt.CopyTo(originalData);
                            return originalData.ToArray();
                        }
                    }
                }
            }
        }
    }
}*/