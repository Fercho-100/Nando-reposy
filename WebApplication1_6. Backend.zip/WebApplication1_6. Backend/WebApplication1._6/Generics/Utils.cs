﻿using System.Security.Cryptography;
using System.Text;

namespace WebApplication1._6.Generics
{
    public class Utils
    {

        // El siguiente metodo es la forma de encriptacion de contraseñas en eñ sistema
        public static string GetSHA256(string str)
        {
            // Crea una instancia de SHA256
            using (SHA256 sha256 = SHA256.Create())
            {
                // Calcula el hash SHA-256 de la cadena de texto
                byte[] stream = sha256.ComputeHash(Encoding.UTF8.GetBytes(str));
                StringBuilder sb = new StringBuilder();

                // Convierte cada byte a su representación hexadecimal y agrégalo al StringBuilder
                foreach (byte b in stream)
                {
                    sb.Append(b.ToString("x2"));
                }

                // Devuelve la representación hexadecimal completa del hash
                return sb.ToString();
            }
        }

    }
}