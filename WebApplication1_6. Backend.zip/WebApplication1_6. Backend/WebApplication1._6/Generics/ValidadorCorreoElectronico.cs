﻿using System.Text.RegularExpressions;

namespace WebApplication1._6.Generics
{
    public class ValidadorCorreoElectronico
    {

        // El siguiente metodo sirve para validar que se esta registrando el correo 
        public static bool EsCorreoValido(string correo)
        {
            // Expresión regular para validar el formato del correo electrónico
            string patron = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

            // Comprueba si el correo coincide con el patrón
            return Regex.IsMatch(correo, patron);
        }
    }
}
