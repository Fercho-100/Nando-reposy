﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class PerfilsController : Controller
    {
        private readonly SegregacionContext _context;

        public PerfilsController(SegregacionContext context)
        {
            _context = context;
        }

        // El siguiente metodo nos sirve para ingresar el nombre del nuevo perfil al cual se le asignaran permisos mas adelante
        [HttpPost]
        [Route("InsertarPerfil")]
        public IActionResult InsertarPerfil([FromBody] List<ClasePerfil> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var perfil in datos)
                    {
                        var entidadPerfil = new Perfil
                        {
                            NombrePerfil = perfil.NombrePerfil,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadPerfil);
                    }

                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Nombre del perfil Guardado");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }


        // El siguiente metodo nos retorna cuales serian los accesos en global del sistema para posteriormente asignarselo al ultimo perfil registrado
        [HttpGet("obtenerlistaAccesos")]
        public List<ClaseListaAccesos> obtenerlistaAccesos()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseListaAccesos> lista1 = new List<ClaseListaAccesos>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla aplicaciones y los guardamos en nuestro list
                    lista1 = (from a in bd.DescripcionAccesos
                              select new ClaseListaAccesos()
                              {
                                  IdDescripcionAcceso = a.IdDescripcionAcceso,
                                  DescripcionAcceso1 = a.DescripcionAcceso1
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }


        }


        // El siguiente metodo nos sirve para ingresar los permisos que tendra el ultimo perfil registrado
        [HttpPost]
        [Route("InsertarPermisos")]
        public IActionResult InsertarPermisos([FromBody] List<ClasePermisos> datos)
        {
            try
            {

                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }
                int idPerfil = 0; //Inicializamos una variable para guardar el id del perfil

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    // Obtenemos el id del ultimo perfil registrado (La idea es que este metodo se ejecute despues de guardar el nombre del perfil), y lo guardamos en nuestra variable
                    idPerfil = segregacion.Perfils
                                       .OrderByDescending(e => e.IdPerfil)
                                       .Select(e => e.IdPerfil)
                                       .FirstOrDefault();

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var permisos in datos)
                    {
                        var entidadHallazgo = new PermisosPerfil
                        {
                            IdPerfil = idPerfil,
                            IdDescripcionAcceso = permisos.id,
                            Acceso = permisos.respuesta,
                        };

                        // Verificar si ya existe un registro con el mismo IdDescripcionAcceso e IdPerfil
                        var permisoExistente = segregacion.PermisosPerfils.FirstOrDefault(p =>
                            p.IdDescripcionAcceso == entidadHallazgo.IdDescripcionAcceso &&
                            p.IdPerfil == entidadHallazgo.IdPerfil);

                        if (permisoExistente == null)
                        {
                            // Agregar la entidadHallazgo a la lista segregacion
                            segregacion.Add(entidadHallazgo);
                        }
                    }

                    // Guardar los cambios en la base de datos
                    segregacion.SaveChanges();


                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();

                }

                return Ok("Permisos agregados exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }

        [HttpGet("obtenerPerfiles")]
        public List<ClasePerfil2> obtenerPerfiles()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClasePerfil2> lista1 = new List<ClasePerfil2>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla aplicaciones y los guardamos en nuestro list
                    lista1 = (from a in bd.Perfils

                              select new ClasePerfil2()
                              {
                                  Id = a.IdPerfil,
                                  nombrePerfil = a.NombrePerfil
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }

        [HttpGet("ObtenerAccesos")]
        public List<ClaseAccesos> obtenerAccesos(int IdPerfil)
        {

            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseAccesos> lista3 = new List<ClaseAccesos>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla de puestos y tomamos los registros del responsable que lo0s este solicitando y los guardamos en nuestro list
                    lista3 = (from pr in bd.PermisosPerfils
                              join p in bd.DescripcionAccesos on pr.IdDescripcionAcceso equals p.IdDescripcionAcceso
                              
                              where pr.IdPerfil == IdPerfil && pr.Acceso==true
                              select new ClaseAccesos()
                              {
                                  IdPerfil = pr.IdPerfil,
                                  IdDescripcionAccesos = pr.IdDescripcionAcceso,
                                  DescripcionAcceso = p.DescripcionAcceso1,

                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }
    }
}

