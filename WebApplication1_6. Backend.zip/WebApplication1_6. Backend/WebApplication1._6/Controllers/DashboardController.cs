﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using System.Linq;
using WebApplication1._6.Models;
using WebApplication1._6.Clases;

namespace WebApplication1._6.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //Atraves de este metodo enviamos informacion de los puestos organizada por pais para actualizar el dashboard correspondiente conforme a un periodo de tiempo especifico
        // Entradas:
        // fechainicio: Fecha de inicio para filtrar los registros.
        // fechafinal: Fecha final para filtrar los registros.
        //
        //
        // Salidas:
        // Lista de objetos de la suma de todos los puestos de la base de datos dividido por pais en el periodo de tiempo definido
        [HttpGet]
        [Route("registros-con-paises")]
        public IActionResult ObtenerRegistrosConPaises()
        {
        try
        {
                using (SegregacionContext db = new SegregacionContext())
                { 

                // Guardamos la cantidad de registros que hay por pais a travez del IdPais
                var registrosPorPais = db.PuestosRegionales
                                      .Where(r => r.IdPais == 1 || r.IdPais == 2 || r.IdPais == 3 || r.IdPais == 4 )
                                      .GroupBy(r => r.IdPais)
                                      .Select(g => new
                                      {
                                          IdPais = g.Key,
                                          NombrePais = db.Pais.FirstOrDefault(c => c.IdPais == g.Key).NombrePais,
                                          CantidadRegistros = g.Count(),
                                          PuestosRevisados = g.Sum(r => r.IdEstado != 1 && r.IdEstado != 2 && r.IdEstado != 3 && r.IdEstado != 5 ? 1 : 0),
                                          UsuariosImpactados = g.Sum(r => r.NdeUsuarios),
                                          PuestosSocializados = g.Sum(r => r.IdEstado != 1 && r.IdEstado != 2 && r.IdEstado != 3 && r.IdEstado != 4 && r.IdEstado != 5 ? 1 : 0),



                                      })
                                      .ToList();

                 // Creamos una segunda variable para obtener la cantidad de aplicaciones q2ue hay por pais al unir la  tabla de hallazgos con la tabla puestos
                 // y clasificarlos por el IdPais 
                    var registrosPorPais2 = db.PuestosRegionales
                     .Join(db.MatrizHallazgos,
                         pr => pr.IdPuestosRegionales,
                         p => p.IdPuestosRegionales,
                         (pr, p) => new
                         {
                             IdPais = pr.IdPais,
                             IdPuestosRegionales = pr.IdPuestosRegionales,
                             IdAplicacion = 1, // Utilizamos el ID de aplicación
                         })
                     .GroupBy(r => new { r.IdPais }) // Agrupar por ID de país
                     .Select(g => new
                     {
                         IdPais = g.Key.IdPais,
                         CantidadAplicaciones = g.Sum(r => r.IdAplicacion), // Sumamos la cantidad de aplicaciones
                     })
                     .ToList();

                    // Unimos las dos variables para poder enviar al usuario un solo json
                    var registrosCombinados = registrosPorPais
                       .Join(registrosPorPais2,
                           rp1 => rp1.IdPais,
                           rp2 => rp2.IdPais,
                           (rp1, rp2) => new
                           {
                               IdPais = rp1.IdPais,
                               NombrePais = rp1.NombrePais,
                               CantidadRegistros = rp1.CantidadRegistros,
                               PuestosRevisados = rp1.PuestosRevisados,
                               CantidadAplicaciones = rp2.CantidadAplicaciones,
                               UsuariosImpactados = rp1.UsuariosImpactados,
                               PuestosSocializados= rp1 .PuestosSocializados,

                           })
                         .ToList();



                    // Y por ultimo retornamos el json resultante de la combinacion de los dos json
                    return Json(registrosCombinados);
            }
        }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
    }


        //Atraves de este metodo enviamos informacion de la cantidad de registros que hay por cada criterio disponible para actualizar el dashboard correspondiente
        // Entradas:
        //
        // Salidas:
        // Lista de objetos de la suma de todos los registros de la tabla MatrizHallazgos de la base de datos dividido por criterio
        [HttpGet]
        [Route("ObtenerCantidadCriterios")]
        public IActionResult ObtenerCantidadCriterios()
        {
           try
            {
                // Guardamos en una variable el llamado a la base de datos

                using (SegregacionContext db = new SegregacionContext())
                {
                    // Guardamos la cantidad de registros que hay por criterio exceptuando el criterio 6 (Reservado para los registros sin hallazgos)
                    var registrosPorPais = db.MatrizHallazgos
                        .Where(r => r.IdCriterio != 6 && r.IdCriterio != null) // Filtra los registros donde el IdCriterio no sea 6
                        .GroupBy(r => r.IdCriterio)
                        .Select(g => new
                        {
                            IdPCriterio = g.Key,
                            NombreCriterio = db.Criterios.FirstOrDefault(c => c.IdCriterio == g.Key).NombreCriterio,
                            CantidadCriterios = g.Count(),
                        })
                        .ToList();

                    // Finalmente enviamos al usuario el json resultante
                    return Json(registrosPorPais);
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }

        //Atraves de este metodo enviamos informacion de la cantidad de registros que hay por cada aplicacion disponible para actualizar el dashboard correspondiente
        // Entradas:
        //
        // Salidas:
        // Lista de objetos de la suma de todos los registros de la tabla MatrizHallazgos de la base de datos dividido por aplicacion

        [HttpGet]
        [Route("ObtenerCantidadAplicacion")]
        public IActionResult ObtenerCantidadAplicacion()
        {
            try
            {
                // Guardamos en una variable el llamado a la base de datos

                using (SegregacionContext db = new SegregacionContext())
                {

                    // Guardamos la cantidad de registros que hay por aplicacion
                    var registrosPorPais = db.MatrizHallazgos
                                .Where(r => r.IdAplicacion != null) // Filtra los registros donde el IdCriterio no sea 6
                               .GroupBy(r => r.IdAplicacion)
                               .Select(g => new
                               {
                                   IdAplicacion = g.Key,
                                   NombreAplicacion = db.Aplicacions.FirstOrDefault(c => c.IdAplicacion == g.Key).NombreAplicacion,
                                   CantidadCriterios = g.Count(),
                               })
                               .ToList();

                    // Finalmente enviamos al usuario el json resultante
                    return Json(registrosPorPais);
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }


        //Atraves de este metodo enviamos informacion de la cantidad de registros que hay por cada criterio disponible en un periodo de tiempo determinado para actualizar el
        //dashboard correspondiente
        // Entradas:
        // fechainicio: Fecha de inicio para filtrar los registros.
        // fechafinal: Fecha final para filtrar los registros.
        //
        //
        // Salidas:
        // Lista de objetos de la suma de todos los registros de la tabla MatrizHallazgos de la base de datos dividido por criterio en el periodo de tiempo definido

        [HttpGet]
        [Route("ObtenerCantidadCriteriosPorFecha")]
        public IActionResult ObtenerCantidadCriteriosPorFecha(string fechainicio, string fechafinal)
        {
            try
            {
                // Convierte las cadenas de fecha a objetos DateOnly
                DateOnly fechaInicio = DateOnly.Parse(fechainicio);
                DateOnly fechaFin = DateOnly.Parse(fechafinal);

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {
                    // Guardamos la cantidad de registros que hay por criterio teniendo como limitante las fechas enviadas 
                    var registrosPorPais = db.MatrizHallazgos
                    .Join(db.PuestosRegionales,
                        matriz => matriz.IdPuestosRegionales, 
                        otra => otra.IdPuestosRegionales, 
                        (matriz, otra) => new
                        {
                            FechaReferencia = otra.FechaFinalizacion, 
                            IdCriterio = matriz.IdCriterio,
                            NombreCriterio = db.Criterios.FirstOrDefault(c => c.IdCriterio == matriz.IdCriterio).NombreCriterio,
                        })
                    .Where(r => r.IdCriterio != 6 && r.FechaReferencia >= fechaInicio && r.FechaReferencia <= fechaFin) //Limitamos los registros a un periodo de tiempo especifico
                    .GroupBy(r => r.IdCriterio)
                    .Select(g => new
                    {
                        IdPCriterio = g.Key,
                        NombreCriterio = g.FirstOrDefault().NombreCriterio,
                        CantidadCriterios = g.Count(),
                    })
                    .ToList();

                    // Finalmente enviamos al usuario el json resultante
                    return Json(registrosPorPais);
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }


        //Atraves de este metodo enviamos informacion de la cantidad de registros que hay por cada aplicacion disponible en un periodo de tiempo determinado para actualizar el
        //dashboard correspondiente
        // Entradas:
        // fechainicio: Fecha de inicio para filtrar los registros.
        // fechafinal: Fecha final para filtrar los registros.
        //
        //
        // Salidas:
        // Lista de objetos de la suma de todos los registros de la tabla MatrizHallazgos de la base de datos dividido por aplicacion en el periodo de tiempo definido
        [HttpGet]
        [Route("ObtenerCantidadAplicacionesPorFecha")]
        public IActionResult ObtenerCantidadAplicacionesPorFecha(string fechainicio, string fechafinal)
        {
            try
            {
                // Convierte las cadenas de fecha a objetos DateOnly
                DateOnly fechaInicio = DateOnly.Parse(fechainicio);
                DateOnly fechaFin = DateOnly.Parse(fechafinal);
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {
                    // Guardamos la cantidad de registros que hay por aplicacion teniendo como limitante las fechas enviadas 
                    var registrosPorPais = db.MatrizHallazgos
                    .Join(db.PuestosRegionales,
                        matriz => matriz.IdPuestosRegionales,
                        otra => otra.IdPuestosRegionales, 
                        (matriz, otra) => new
                        {
                            FechaReferencia = otra.FechaFinalizacion, 
                            IdAplicacion = matriz.IdAplicacion,
                            NombreAplicacion = db.Aplicacions.FirstOrDefault(c => c.IdAplicacion == matriz.IdAplicacion).NombreAplicacion,
                        })
                    .Where(r => r.IdAplicacion != 6 && r.FechaReferencia >= fechaInicio && r.FechaReferencia <= fechaFin) //Limitamos los registros a un periodo de tiempo especifico
                    .GroupBy(r => r.IdAplicacion)
                    .Select(g => new
                    {
                        IdAplicacion = g.Key,
                        NombreAplicacion = g.FirstOrDefault().NombreAplicacion,
                        CantidadAplicaciones = g.Count(),
                    })
                    .ToList();

                    // Finalmente enviamos al usuario el json resultante
                    return Json(registrosPorPais);
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }


        [HttpGet]
        [Route("ObtenerAplicacion")]
        public IActionResult ObtenerAplicaciones()
        {
            try
            {
                // Guardamos en una variable el llamado a la base de datos

                using (SegregacionContext db = new SegregacionContext())
                {

                    // Guardamos la cantidad de registros que hay por aplicacion
                    var registros = db.MatrizHallazgos
                                .Where(r => r.IdAplicacion != null && r.IdCriterio !=6) // Filtra los registros donde el IdCriterio no sea 6
                               .GroupBy(r => new { r.IdAplicacion, r.IdCriterio })
                               .Select(g => new
                               {
                                   NombreAplicacion = db.Aplicacions.FirstOrDefault(a => a.IdAplicacion == g.Key.IdAplicacion).NombreAplicacion,
                                   NombreCriterio = db.Criterios.FirstOrDefault(a => a.IdCriterio == g.Key.IdCriterio).NombreCriterio,
                                   CantidadRegistros = g.Count(),
                               })
                               .OrderByDescending(r => r.CantidadRegistros) // Ordena por cantidad de registros de mayor a menor
                               .ToList();

                    // Finalmente enviamos al usuario el json resultante
                    return Json(registros);
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpGet]
        [Route("ObtenerAplicacionesPorPais")]
        public IActionResult ObtenerAplicacionesPorPais()
        {
            try
            {
                // Guardamos en una variable el llamado a la base de datos

                using (SegregacionContext db = new SegregacionContext())
                {
                    var resultado = (from x in db.PuestosRegionales
                                     join y in db.MatrizHallazgos on x.IdPuestosRegionales equals y.IdPuestosRegionales
                                     join z in db.Aplicacions on y.IdAplicacion equals z.IdAplicacion
                                     join w in db.Pais on x.IdPais equals w.IdPais
                                     group new { x,y, z, w } by new { x.IdPais, y.IdAplicacion } into grouped
                                     select new ClaseAplicacionesPais
                                     {
                                         IdPais = grouped.Key.IdPais,
                                         NombrePais = grouped.First().w.NombrePais,
                                         IdAplicacion = grouped.First().y.IdAplicacion,
                                         NombreAplicacion = grouped.First().z.NombreAplicacion,
                                         CountIdAplicacion = grouped.Count() // Variable que cuenta los registros para el IdAplicacion actual

                                     }).ToList();
                    var resultadoOrdenado = resultado.OrderBy(r => r.NombrePais).ToList();


                    // Finalmente enviamos al usuario el json resultante
                    return Json(resultadoOrdenado);
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpGet]
        [Route("ObtenerAplicacionesPorPaisLimitado")]
        public IActionResult ObtenerAplicacionesPorPaisLimitado()
        {
            try
            {
                // Guardamos en una variable el llamado a la base de datos

                using (SegregacionContext db = new SegregacionContext())
                {
                    var resultado = (from x in db.PuestosRegionales
                                     join y in db.MatrizHallazgos on x.IdPuestosRegionales equals y.IdPuestosRegionales
                                     join z in db.Aplicacions on y.IdAplicacion equals z.IdAplicacion
                                     join w in db.Pais on x.IdPais equals w.IdPais
                                     where y.IdAplicacion == 36 || y.IdAplicacion == 37 || y.IdAplicacion == 31 || y.IdAplicacion == 29 || y.IdAplicacion == 24 || y.IdAplicacion == 8 || y.IdAplicacion == 1 // Agrega esta línea con tu valor específico
                                     group new { x, y, z, w } by new { x.IdPais, y.IdAplicacion } into grouped
                                     select new ClaseAplicacionesPais
                                     {
                                         IdPais = grouped.Key.IdPais,
                                         NombrePais = grouped.First().w.NombrePais,
                                         IdAplicacion = grouped.First().y.IdAplicacion,
                                         NombreAplicacion = grouped.First().z.NombreAplicacion,
                                         CountIdAplicacion = grouped.Count() // Variable que cuenta los registros para el IdAplicacion actual

                                     }).ToList();
                    var resultadoOrdenado = resultado.OrderBy(r => r.NombrePais).ToList();


                    // Finalmente enviamos al usuario el json resultante
                    return Json(resultadoOrdenado);
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpGet]
        [Route("ObtenerHallazgosGenerales")]
        public IActionResult ObtenerHallazgosGenerales()
        {
            try
            {
                // Guardamos en una variable el llamado a la base de datos

                using (SegregacionContext db = new SegregacionContext())
                {

                    // Guardamos la cantidad de registros que hay por aplicacion
                    var registrosPorPais = db.PuestosRegionales
                               .GroupBy(r => r.IdEstado)
                               .Select(g => new
                               {
                                   IdAplicacion = g.Key,
                                   NombreAplicacion = db.Aplicacions.FirstOrDefault(c => c.IdAplicacion == g.Key).NombreAplicacion,
                                   CantidadCriterios = g.Count(),
                               })
                               .ToList();

                    // Finalmente enviamos al usuario el json resultante
                    return Json(registrosPorPais);
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }


        //Prototipo
        /*[HttpGet]
       [Route("registros-con-paises-por-aplicaciones2")]
       public IActionResult ObtenerRegistrosConPaisesPorAplicaciones2(string fechainicio, string fechafinal)
       {
           try
           {
               // Convierte las cadenas de fecha a objetos DateOnly
               DateOnly fechaInicio = DateOnly.Parse(fechainicio);
               DateOnly fechaFin = DateOnly.Parse(fechafinal);

               using (SegregacionContext db = new SegregacionContext())
               {
                   /*var registrosPorPais = db.PuestosRegionales
                       .Join(db.MatrizHallazgos,
                           pr => pr.IdPuestosRegionales,
                           p => p.IdPuestosRegionales,
                           (pr, p) => new
                           {
                               IdPais = pr.IdPais,
                               IdPuestosRegionales = pr.IdPuestosRegionales,
                               IdAplicacion = 1, // Utilizamos el ID de aplicación
                               CantidadAceptados = pr.IdEstado == 4 ? 1 : 0,
                               FechaFinalizacion = pr.FechaFinalizacion,
                           })
                       .Where(r => r.FechaFinalizacion >= fechaInicio && r.FechaFinalizacion <= fechaFin) // Filtrar por intervalo de tiempo
                       .GroupBy(r => new { r.IdPais }) // Agrupar por ID de país
                       .Select(g => new
                       {
                           IdPais = g.Key.IdPais,
                           NombrePais = db.Pais.FirstOrDefault(c => c.IdPais == g.Key.IdPais).NombrePais, // Obtener el nombre del país
                           CantidadRegistros = g.Select(r => r.IdPuestosRegionales).Distinct().Count(),
                           CantidadAplicaciones = g.Sum(r => r.IdAplicacion), // Sumamos la cantidad de aplicaciones
                           CantidadAceptados = g.Sum(r => r.CantidadAceptados),
                       })
                       .ToList();

                   var registrosPorPais = db.PuestosRegionales
                       .Join(db.MatrizHallazgos,
                           pr => pr.IdPuestosRegionales,
                           p => p.IdPuestosRegionales,
                           (pr, p) => new
                           {
                               IdPais = pr.IdPais,
                               IdPuestosRegionales = pr.IdPuestosRegionales,
                               IdAplicacion = 1, // Utilizamos el ID de aplicación
                               FechaFinalizacion = pr.FechaFinalizacion,
                           })
                       .Where(r => r.FechaFinalizacion >= fechaInicio && r.FechaFinalizacion <= fechaFin) // Filtrar por intervalo de tiempo
                       .Where(r => r.IdAplicacion != 38) // Excluir aplicaciones con número 38
                       .GroupBy(r => new { r.IdPais }) // Agrupar por ID de país
                       .Select(g => new
                       {
                           IdPais = g.Key.IdPais,
                           NombrePais = db.Pais.FirstOrDefault(c => c.IdPais == g.Key.IdPais).NombrePais, // Obtener el nombre del país
                           CantidadAplicaciones = g.Sum(r => r.IdAplicacion), // Sumamos la cantidad de aplicaciones excluyendo las de número 38
                       })
                       .ToList();

                   return Json(registrosPorPais);
               }
           }
           catch (Exception ex)
           {
               // Manejo de excepciones
               return StatusCode(500, "Error interno del servidor");
           }
       }*/



    }

}
