﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class IngresarDatosAdicionalesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // En el siguiente metodo sirve para ingresar en la tabla puestos regionales la seccion de labels en la segunda pantalla de ingresar hallazgos
        // Entradas:
        // - ClaseTabla2 : Clase que contiene las variables que vamos a recibir en el JSON
        // 
        //
        // Salidas:
        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error

        [HttpPost]
        [Route("InsertTabla2")]
        public IActionResult InsertTabla2([FromBody] List<ClaseTabla2> datos)
        {
            try
            {


                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {
                    //Encerramos lo enviado a un bucle foreach para poder guardar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {
                        // Guardamos en una variable los datos necesarios para poder acceder al puesto que estamos agregando informacion
                        var lista = db.PuestosRegionales.Find(campos.IdPuestosRegionales);

                        int cantidadRegistros = db.PuestosRegionales.Count(p => p.IdEstado == 4 && p.IdPais == lista.IdPais);

                        cantidadRegistros += 1;

                        // Metodo para crear de forma automatica el id del informe
                        var resultado = (from t1 in db.PuestosRegionales
                                         join t2 in db.Pais on t1.IdPais equals t2.IdPais
                                         join t3 in db.Empresas on t1.IdEmpresa equals t3.IdEmpresa
                                         where t1.IdPuestosRegionales == campos.IdPuestosRegionales
                                         select t2.AbreviacionPais + t3.AbreviacionEmpresa +
                            (t1.FechaAsignacion != null ? t1.FechaAsignacion.Value.ToString("ddMMyyyy") : "") +
                            "-" + cantidadRegistros + "/SF").FirstOrDefault();

                        // y si existe el registro al cual esta haciendo la referencia hace los inserts
                        if (lista != null)
                        {
                            lista.EvaluacionPuesto = campos.EvaluacionPuesto;
                            lista.NivelImpacto = campos.NivelImpacto;
                            lista.IdRiesgo = campos.IdRiesgo;
                            lista.IdEstado = 4;
                            lista.IdInforme = resultado;
                            lista.FechaFinalizacion = DateOnly.FromDateTime(DateTime.Today);
                            lista.Encargado = campos.empleadoSeleccionado;
                            lista.PuestoEncargado = campos.selectedPuestoLaboral;
                            db.SaveChanges();
                        }
                    }
                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {

                // Captura la excepción y muestra detalles
                Console.WriteLine($"Error: {ex.Message}");
                if (ex.InnerException != null)
                {
                    //Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                    return StatusCode(500, $"Error en el servidor: {ex.InnerException.Message}");
                }
                else
                {
                    return Ok("Todo bien");
                }
            }
        }

        // En el siguiente metodo sirve para insertar las respuestas de la tabla en la segunda pantalla de ingresar hallazgos
        // Entradas:
        // - ClaseTabla2_1 : Clase que contiene las variables que vamos a recibir en el JSON
        // 
        //
        // Salidas:
        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error

        [HttpPost]
        [Route("InsertTabla2_1")]
        public IActionResult InsertarDetalleCriterios([FromBody] List<ClaseTabla2_1> datos)
        {
            try
            {

                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var criterio in datos)
                    {
                        var entidadCriterio = new CriteriosDetalle
                        {
                            IdPuestosRegionales = criterio.IdPuestosRegionales,
                            IdListaCriterios = criterio.IdListaCriterios,
                            Respuesta = criterio.Respuesta,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadCriterio);
                    }
                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Criterio Guardado");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }






    }
}











