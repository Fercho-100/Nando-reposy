﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class EntrevistadoesController : Controller
    {
        private readonly SegregacionContext _context;

        public EntrevistadoesController(SegregacionContext context)
        {
            _context = context;
        }

        //Este metodo sirve para ingresar los ids de los empleados entrevistados por cada puesto, mismo que nos servira mas adelante para el informe
        //Este metodo es para ingresar una nueva aplicacion para que podamos utilizarla en otros procesos que lo requieran
        // Entradas:
        // ClaseEntrevistados : Clase que contiene las variables que vamos a recibir en el JSON
        //
        // Salidas:
        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error

        [HttpPost]
        [Route("InsertarEntrevistados")]
        public IActionResult InsertarEntrevistados([FromBody] List<ClaseEntrevistados> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {
                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var Entrevistado in datos)
                    {
                        // Verificar si el empleado ya existe por su ID
                        var empleadoExistente = segregacion.Entrevistados.FirstOrDefault(e => e.IdEmpleado == Entrevistado.IdEmpleado && e.IdPuestosRegionales == Entrevistado.IdPuestosRegionales);
                        if (empleadoExistente != null)
                        {
                            // Empleado ya existe, no lo agregamos nuevamente
                            continue;
                        }

                        var entrevistado = new Entrevistado
                        {
                            IdPuestosRegionales = Entrevistado.IdPuestosRegionales,
                            IdEmpleado = Entrevistado.IdEmpleado,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entrevistado);
                    }

                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Empleados agregados exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }

    }
}
