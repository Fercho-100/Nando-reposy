﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;
using WebApplication1._6.Generics;
using System.Drawing;
using System.IO;

namespace WebApplication1._6.Controllers
{
    public class InformeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


        //Este metodo nos retorna todos los hallazgos del puesto del cual estamos creando el informe
        // Entradas:
        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
        // Tipo: Int
        //
        // Salidas:
        // Lista de objetos con las variables de la clase ClaseMatriz2 la cual nos dara todos los hallazgos que tenga el puesto

        [HttpGet("SelectInformeMatricesHallazgo")]
        public List<ClaseMatriz2> SelectInforme1(int IdPuestosRegionales)
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseMatriz2> lista3 = new List<ClaseMatriz2>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla matrices para obtener toda la informacion y los guardamos en nuestro list
                    lista3 = (from pr in bd.MatrizHallazgos
                              join p in bd.PuestosRegionales on pr.IdPuestosRegionales equals p.IdPuestosRegionales
                              join f in bd.Aplicacions on pr.IdAplicacion equals f.IdAplicacion
                              join g in bd.Criterios on pr.IdCriterio equals g.IdCriterio
                              where p.IdPuestosRegionales == IdPuestosRegionales
                              select new ClaseMatriz2()
                              {
                                  IdPuestosRegionales = p.IdPuestosRegionales,
                                  NombreAplicacion = f.NombreAplicacion,
                                  Descripcion = pr.Descripcion,
                                  NombreMenu = pr.NombreMenu ,
                                  NombreSubMenu = pr.NombreSubMenu + Environment.NewLine, 
                                  Hallazgo = pr.Hallazgo != null ? pr.Hallazgo.Replace("\n", "") : null,
                                  NombreCriterio = g.NombreCriterio,
                                  Recomendacion = pr.Recomendación != null ? pr.Recomendación.Replace("\n", "") : null,

                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }

        //Este metodo nos retorna todos datos del puesto del cual estamos creando el informe
        // Entradas:
        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
        // Tipo: Int
        //
        // Salidas:
        // Lista de objetos con las variables de la clase ClaseCampos3 la cual nos dara todos los registros unicos que tenga el puesto

        [HttpGet("SelectInformePuestoRegional")]
        public List<ClaseCampos3> SelectInforme2(int IdPuestosRegionales)
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseCampos3> lista3 = new List<ClaseCampos3>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla de puestos para obtener toda la informacion y los guardamos en nuestro list
                    lista3 = (from pr in bd.PuestosRegionales
                              join p in bd.Pais on pr.IdPais equals p.IdPais
                              join f in bd.Empresas on pr.IdEmpresa equals f.IdEmpresa
                              join g in bd.PuestoLaborals on pr.IdPuestoLaboral equals g.IdPuestoLaboral
                              join j in bd.Divisions on pr.IdDivision equals j.IdDivision
                              join k in bd.Deptos on pr.IdDepto equals k.IdDepto
                              join l in bd.Estados on pr.IdEstado equals l.IdEstado
                              join m in bd.Responsables on pr.IdResponsable equals m.IdResponsable
                              join o in bd.Riesgos on pr.IdRiesgo equals o.IdRiesgo
                              join e in bd.Empleados on pr.Encargado equals e.IdEmpleado
                              join b in bd.PuestoLaborals on pr.PuestoEncargado equals b.IdPuestoLaboral
                              where pr.IdPuestosRegionales == IdPuestosRegionales
                              select new ClaseCampos3()
                              {
                                  NombrePuestoLaboral = g.NombrePuestoLaboral,
                                  NombrePais = p.NombrePais,
                                  NombreEmpresa = f.NombreEmpresa,
                                  NombreDivision = j.NombreDivision,
                                  NombreDepto = k.NombreDepto,
                                  NombreResponsable = m.NombreNombreResponsable,
                                  IdInforme = pr.IdInforme,
                                  FechaRevision = pr.FechaRevision,
                                  Riesgo = o.Riesgo1,
                                  EvaluacionPuesto = pr.EvaluacionPuesto != null ? pr.EvaluacionPuesto.Replace("\n", "") : null,
                                  NivelImpacto = pr.NivelImpacto != null ? pr.NivelImpacto.Replace("\n", "") : null,
                                  FechaFinalizacion = pr.FechaFinalizacion,
                                  encargado = e.NombreEmpleado,
                                  puestoEncargado = b.NombrePuestoLaboral,


                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }

        //Este metodo nos retorna todos los criterios para saber el nivel de amenaza del puesto del cual estamos creando el informe
        // Entradas:
        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
        // Tipo: Int
        //
        // Salidas:
        // Lista de objetos con las variables de la clase ClaseListaCriterio2 la cual nos dara las selecciones de los criterios de evaluacion que tenga el puesto

        [HttpGet("SelectInformeListaCriterios")]
        public List<ClaseListaCriterio2> SelectInforme3(int IdPuestosRegionales)
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseListaCriterio2> lista3 = new List<ClaseListaCriterio2>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla de puestos para obtener toda la informacion y los guardamos en nuestro list
                    lista3 = (from pr in bd.CriteriosDetalles
                              join p in bd.ListaCriterios on pr.IdListaCriterios equals p.IdListaCriterios
                              where pr.IdPuestosRegionales == IdPuestosRegionales
                              select new ClaseListaCriterio2()
                              {
                                  Criterio = p.Criterio,
                                  Respuesta = pr.Respuesta,

                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }

        // Este metodo nos retorna los empleados que fueron entrevistados del puesto del cual estamos haciendo el informe
        // Entradas:
        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
        // Tipo: Int
        //
        // Salidas:
        // Lista de objetos con las variables de la clase ClaseEntrevistados2 la cual nos dara los empleados entrevistados que tenga el puesto

        [HttpGet("SelectInformeEntrevistado")]
        public List<ClaseEntrevistados2> SelectInforme4(int IdPuestosRegionales)
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseEntrevistados2> lista3 = new List<ClaseEntrevistados2>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla de entrevistados para obtener toda la informacion y los guardamos en nuestro list
                    lista3 = (from pr in bd.Entrevistados
                              join p in bd.Empleados on pr.IdEmpleado equals p.IdEmpleado
                              where pr.IdPuestosRegionales == IdPuestosRegionales
                              select new ClaseEntrevistados2()
                              {
                                  IdEmpleado = pr.IdEmpleado,
                                  NombreEmpleado = p.NombreEmpleado,

                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }


        // Este metodo nos retorna el tiempo estimado por aplicacion del puesto del cual se esta haciendo el informe
        // Entradas:
        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
        // Tipo: Int
        //
        // Salidas:
        // Lista de objetos con las variables de la clase ClaseEntrevistados2 la cual nos dara los empleados entrevistados que tenga el puesto

        [HttpGet("SelectInformeTiempoEstimado")]
        public List<ClaseTiempoEstimado2> SelectInforme5(int IdPuestosRegionales)
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseTiempoEstimado2> lista3 = new List<ClaseTiempoEstimado2>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla de tiempo estimado para obtener toda la informacion y los guardamos en nuestro list
                    lista3 = (from pr in bd.TiempoEstimados
                              join p in bd.PuestosRegionales on pr.IdPuestosRegionales equals p.IdPuestosRegionales
                              join q in bd.Aplicacions on pr.IdAplicacion equals q.IdAplicacion
                              where pr.IdPuestosRegionales == IdPuestosRegionales
                              select new ClaseTiempoEstimado2()
                              {
                                  NombreAplicacion = q.NombreAplicacion,
                                  TiempoEstimado1 = pr.TiempoEstimado1,

                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }

        // Este metodo nos retorna los conceptos necesarios para el informe que estamos haciendo actualmente
        // Entradas:
        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
        // Tipo: Int
        //
        // Salidas:
        // Lista de objetos con las variables de la clase ClaseListaTerminologia3 la cual nos dara los terminos seleccionados que tenga el puesto

        [HttpGet("SelectTerminologia")]
        public List<ClaseListaTerminologia2> SelectInforme6(int IdPuestosRegionales)
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseListaTerminologia2> lista3 = new List<ClaseListaTerminologia2>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla de terminologías para obtener toda la información y la guardamos en nuestro list
                    lista3 = (from pr in bd.TerminologiaDetalles
                              join p in bd.ListaTerminologia on pr.IdListaTerminologia equals p.IdListaTerminologia
                              where pr.IdPuestosRegionales == IdPuestosRegionales
                              select new ClaseListaTerminologia3()
                              {
                                  Nombre = p.Nombre,
                                  Concepto = p.Concepto != null ? p.Concepto.Replace("\n", "") : null,

                              }).ToList();

                    // Y por último, retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error, enviaremos la lista vacía
                return lista3;
            }
        }



        // En este metodo nos retorna las evidencias de los hallazgos que tenemos para el informe del puesto que estamos haciendo actualmente
        // Entradas:
        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
        // Tipo: Int
        //
        // Salidas:
        // Lista de objetos con las evidencias de la tabla evidencias la cual nos dara los terminos seleccionados que tenga el puesto

      

        [HttpGet("obtenerEvidenciasPorPuestoRegional")]
        public IActionResult GetImagesByPuestoRegional(int idPuestoRegional)
        {
            try
            {
                using (SegregacionContext db = new SegregacionContext())
                {
                    // Obtén todos los IdMatrizHallazgos relacionados con el IdPuestoRegional
                    var idMatrizHallazgosList = ObtenerIdMatrizHallazgosList(idPuestoRegional);

                    // Consulta las imágenes relacionadas con esos IdMatrizHallazgos
                    var images = db.Evidencias
                        .Where(e => idMatrizHallazgosList.Contains((int)e.IdMatrizHallazgos))
                        .ToList();

                    // Crear una lista de objetos que contienen idMatrizHallazgo y la imagen base64
                    var imageList = new List<object>();
                    foreach (var image in images)
                    {
                        /*// Convertir los bytes de la imagen a base64
                        string base64Image = Convert.ToBase64String(image.Evidencia1);
                        imageList.Add(new { idMatrizHallazgo = image.IdMatrizHallazgos, imageData = base64Image });*/
                        imageList.Add(new { idMatrizHallazgo = image.IdMatrizHallazgos, imageData = image.Evidencia1 });
                    }
                    // Y al final nos retorna en un json las evidencias del puesto en el que esta trabajando
                    return Json(imageList);
                }
            }
            catch (Exception ex)
            {
                // Manejo de la excepción: puedes registrar el error, mostrar un mensaje al usuario, etc.
                return BadRequest($"Error al obtener imágenes: {ex.Message}");
            }
        }

        // Método para obtener una lista de IdMatrizHallazgos relacionados con el IdPuestoRegional
        // Entradas:
        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
        // Tipo: Int
        //
        // Salidas:
        // Lista de hallazgos relacionados con el puesto  
        private List<int> ObtenerIdMatrizHallazgosList(int idPuestoRegional)
        {
            using (SegregacionContext db = new SegregacionContext())
            {
                // Implementa la lógica para obtener una lista de IdMatrizHallazgos
                // según el IdPuestoRegional desde la tabla PuestosRegionales.
                return db.MatrizHallazgos
                 .Where(pr => pr.IdPuestosRegionales == idPuestoRegional)
                 .Select(pr => pr.IdMatrizHallazgos)
                 .ToList();
            }
        }

        //Prototipo encriptado de imagenes con AESEncryption
     
    }
}
