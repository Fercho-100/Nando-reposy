﻿//using Microsoft.AspNetCore.Mvc;
//using System.Globalization;
//using WebApplication1._6.Clases;
//using WebApplication1._6.Models;

//namespace WebApplication1._6.Controllers
//{
//    public class IngresarHallazgosController : Controller
//    {

//        public IActionResult Index()
//        {
//            return View();
//        }

//        // Este metodo sirve para ingresar cada hallazgo que sea registrado
//        // Entradas:
//        // ClaseMatriz: Clase que contiene las variables que vamos a recibir en el JSON
//        //
//        // Salidas:
//        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error

//        [HttpPost]
//        [Route("InsertTabla1")]
//        public IActionResult InsertarHallazgos([FromBody] List<ClaseMatriz> datos)
//        {
//            try
//            {

//                // primero verificamos que no se halla enviado el arreglo nulo o vacio
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                // Guardamos en una variable el llamado a la base de datos
//                using (var segregacion = new SegregacionContext())
//                {
//                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
//                    foreach (var matrizHallazgo in datos)
//                    {
//                        // Y vamos guardando lo enviado en una variable
//                        var entidadHallazgo = new MatrizHallazgo
//                        {
//                            IdPuestosRegionales = matrizHallazgo.IdPuestosRegionales,
//                            IdAplicacion = matrizHallazgo.IdAplicacion,
//                            Descripcion = matrizHallazgo.Descripcion,
//                            NombreMenu = matrizHallazgo.NombreMenu,
//                            NombreSubMenu = matrizHallazgo.NombreSubMenu,
//                            Hallazgo = matrizHallazgo.Hallazgo,
//                            IdCriterio = matrizHallazgo.IdCriterio,
//                            Recomendación = matrizHallazgo.Recomendacion,
//                            Resolucion = 1,
//                            EstadoHallazgo = "Pendiente"
//                        };
//                        //al tener las variables disponibles las mandamos a la base de datos
//                        segregacion.Add(entidadHallazgo);
//                    }

//                    // Y al final guardamos los cambios en el sistema
//                    segregacion.SaveChanges();

//                }

//                return Ok("Datos de hallazgos agregados exitosamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al insertar los datossss: {ex.Message}");
//            }
//        }


//        // El siguiente metodo nos retorna los hallazgos registrados para el puesto que se esta evaluando excluyendo los registros que sean sin hallazgos
//        // Esto nos servira para ir mostrando los hallazgos registrados en ese perfil
//        // Entradas:
//        // 
//        //
//        // Salidas:
//        // Lista de objetos con las variables de  la clase ClaseHallazgos

//        [HttpGet("obtenerHallazgos")]
//        public List<ClaseHallazgos> obtenerHallazgos(int IdPuestosRegionales)
//        {

//            // Creamos una lista para poder guardar los datos que vamos a obtener
//            List<ClaseHallazgos> lista = new List<ClaseHallazgos>();
//            try
//            {

//                // Guardamos en una variable el llamado a la base de datos
//                using (SegregacionContext bd = new SegregacionContext())
//                {

//                    // Hacemos el llamado a la tabla de hallazgos los registros con hallazgos y los guardamos en nuestro list
//                    lista = (from pr in bd.MatrizHallazgos
//                             join p in bd.Aplicacions on pr.IdAplicacion equals p.IdAplicacion
//                             join f in bd.Criterios on pr.IdCriterio equals f.IdCriterio
//                             join g in bd.PuestosRegionales on pr.IdPuestosRegionales equals g.IdPuestosRegionales
//                             where pr.IdPuestosRegionales == IdPuestosRegionales && pr.NombreMenu != "N/A"  //Aqui verificamos que los registros efectivamente tengan hallazgos
//                             select new ClaseHallazgos()
//                             {
//                                 IdMatrizHallazgos = pr.IdMatrizHallazgos,
//                                 IdPuestosRegionales = IdPuestosRegionales,
//                                 NombreAplicacion = p.NombreAplicacion,
//                                 NombreMenu = pr.NombreMenu,
//                                 NombreSubMenu = pr.NombreSubMenu,
//                                 Hallazgo = pr.Hallazgo,
//                                 NombreCriterio = f.NombreCriterio,
//                                 Recomendacion = pr.Recomendación,
//                                 Descripcion = pr.Descripcion,

//                             }).ToList();

//                    // Y por ultimo retornamos esa lista al usuario
//                    return lista;
//                }
//            }
//            catch (Exception ex)
//            {
//                // Si aparece un error enviaremos la cadena vacia
//                return lista;
//            }
//        }

//        // El siguiente metodo nos retorna los registros que sean sin hallazgos
//        // Esto nos servira para ir mostrando los registros los cuales no tienen hallazgos registrados en ese perfil
//        // El siguiente metodo nos retorna los hallazgos registrados para el puesto que se esta evaluando excluyendo los registros que sean sin hallazgos
//        // Esto nos servira para ir mostrando los hallazgos registrados en ese perfil
//        // Entradas:
//        // - IdPuestosRegionales : Variable la cual nos indica cual es el puesto que estamos revisando
//        // Tipo: Int
//        //
//        // Salidas:
//        // Lista de objetos con las variables de  la clase ClaseHallazgos2

//        [HttpGet("obtenerSinHallazgos")]
//        public List<ClaseHallazgos2> obtenerSinHallazgos(int IdPuestosRegionales)
//        {

//            // Creamos una lista para poder guardar los datos que vamos a obtener
//            List<ClaseHallazgos2> lista = new List<ClaseHallazgos2>();
//            try
//            {

//                // Guardamos en una variable el llamado a la base de datos
//                using (SegregacionContext bd = new SegregacionContext())
//                {

//                    // Hacemos el llamado a la tabla de hallazgos los registros sin hallazgos y los guardamos en nuestro list
//                    lista = (from pr in bd.MatrizHallazgos
//                             join g in bd.PuestosRegionales on pr.IdPuestosRegionales equals g.IdPuestosRegionales
//                             join p in bd.Aplicacions on pr.IdAplicacion equals p.IdAplicacion
//                             where pr.IdPuestosRegionales == IdPuestosRegionales && pr.NombreMenu == "N/A" //Aqui verificamos que los registros efectivamente no tengan hallazgos
//                             select new ClaseHallazgos2()
//                             {
//                                 IdMatrizHallazgos = pr.IdMatrizHallazgos,
//                                 Descripcion = pr.Descripcion,
//                                 NombreAplicacion = p.NombreAplicacion,

//                             }).ToList();

//                    // Y por ultimo retornamos esa lista al usuario
//                    return lista;
//                }
//            }
//            catch (Exception ex)
//            {

//                // Si aparece un error enviaremos la cadena vacia
//                return lista;
//            }
//        }

//        // El siguiente metodo sirve para ingresar los terminos de los cuales obtendremos los conceptos para el informe
//        // Entradas:
//        // ClaseTerminosDetalle: Clase que contiene las variables que vamos a recibir en el JSON
//        //
//        // Salidas:
//        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error

//        [HttpPost]
//        [Route("InsertarTerminologia")]
//        public IActionResult InsertarEmpleado([FromBody] List<ClaseTerminosDetalle> datos)
//        {
//            try
//            {

//                // primero verificamos que no se halla enviado el arreglo nulo o vacio
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                // Guardamos en una variable el llamado a la base de datos
//                using (var segregacion = new SegregacionContext())
//                {

//                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
//                    foreach (var Terminos in datos)
//                    {
//                        var terminos = new TerminologiaDetalle
//                        {
//                            IdPuestosRegionales = Terminos.IdPuestosRegionales,
//                            IdListaTerminologia = Terminos.IdListaTerminologia,
//                        };

//                        //al tener las variables disponibles las mandamos a la base de datos
//                        segregacion.Add(terminos);
//                    }

//                    // Y al final guardamos los cambios en el sistema
//                    segregacion.SaveChanges();
//                }

//                return Ok("Terminologia agregada exitosamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
//            }
//        }

//        // En el siguiente metodo nos sirve para registrar la fecha de revision, misma la cual es la unica fecha actualmente(I Fase del proyecto) la cual es manual
//        // Entradas:
//        // ClaseFecha: Clase que contiene las variables que vamos a recibir en el JSON
//        //
//        // Salidas:
//        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error

//        [HttpPost]
//        [Route("agregarFechaRevision")]
//        public IActionResult AgregarFechaRevision([FromBody] List<ClaseFecha> datos)
//        {
//            try
//            {

//                // Guardamos en una variable el llamado a la base de datos
//                using (SegregacionContext db = new SegregacionContext())
//                {

//                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
//                    foreach (var fecha in datos)
//                    {
//                        //Ubicamos el puesto con el cual se esta trabajando
//                        var lista = db.PuestosRegionales.Find(fecha.IdPuestosRegionales);
//                        if (lista != null)
//                        {

//                            // Verificamos que se este enviando realmente una fecha
//                            if (DateTime.TryParseExact(fecha.FechaAsignacion, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fechaCompleta))
//                            {
//                                // Crea un objeto DateOnly a partir del DateTime
//                                DateOnly fechaSinHora = new DateOnly(fechaCompleta.Year, fechaCompleta.Month, fechaCompleta.Day);

//                                // Asigna la fecha sin la hora al objeto lista
//                                lista.FechaRevision = fechaSinHora;

//                                // Guardamos los cambios
//                                db.SaveChanges();
//                            }
//                            else
//                            {
//                                return BadRequest("La cadena de fecha no es válida o no se pudo analizar correctamente.");
//                            }
//                        }
//                        else
//                        {
//                            return NotFound($"No se encontró el registro con ID {fecha.IdPuestosRegionales}.");
//                        }
//                    }
//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }


//        /*// En el siguiente metodo nos sirve para insertar imagenes que nos serviran como evidencia en el informe
//        [HttpPost]
//        [Route("insertarEvidencias")]
//        public IActionResult UploadImage(IFormFile imageFiles)
//        {
//            if (imageFiles == null || imageFiles.Length == 0)
//            {
//                return BadRequest("No se proporcionó ningún archivo o el archivo está vacío.");
//            }

//            try
//            {

//                // Guardamos en una variable el llamado a la base de datos
//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    int idMatrizHallazgos = 0; // Inicializa con un valor adecuado


//                    // verificamos que no se halla enviado el arreglo nulo o vacio
//                    if (imageFiles != null && imageFiles.Length != 0)
//                    {

//                        //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales

//                            if (imageFiles != null && imageFiles.Length > 0)
//                            {

//                                // Declaramos una variable para poder utilizar para convertir las evidencias
//                                using (var memoryStream = new MemoryStream())
//                                {
//                                    imageFiles.CopyTo(memoryStream);

//                                    // Y convertimos las imagenes a byte
//                                    var imageBytes = memoryStream.ToArray();

//                                    // Obtén el último IdMatrizHallazgos dentro del bucle
//                                    idMatrizHallazgos = db.MatrizHallazgos
//                                        .OrderByDescending(e => e.IdMatrizHallazgos)
//                                        .Select(e => e.IdMatrizHallazgos)
//                                        .FirstOrDefault();

//                                    // Y guardamos la evidencia en el ultimo hallazgo registrado (Esto ya que esta misma se va a guardar despues de crear un nuevo hallazgo)
//                                    db.Evidencias.Add(new Evidencia
//                                    {
//                                        Evidencia1 = imageBytes,
//                                        IdMatrizHallazgos = idMatrizHallazgos
//                                    });

//                                    db.SaveChanges();
//                                }
//                            }

//                    }
//                    else
//                    {
//                       return BadRequest("No se han enviado imágenes.");
//                    }
//                }

//                // Redirecciona a la página de éxito o muestra un mensaje al usuario
//                return Ok("Carga exitosa");
//            }
//            catch (Exception ex)
//            {

//                return BadRequest($"Error al cargar imágenes: {ex.Message}");
//            }
//        }*/

//        /*
//        [HttpPost]
//        [Route("insertarEvidencias")]
//        public IActionResult UploadImages(IFormFileCollection imageFiles)
//        {
//            if (imageFiles == null || imageFiles.Count == 0)
//            {
//                return BadRequest("No se proporcionaron archivos o los archivos están vacíos.");
//            }

//            try
//            {
//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    int idMatrizHallazgos = 0; // Inicializa con un valor adecuado
//                    foreach (var imageFile in imageFiles)
//                    {
//                        if (imageFile.Length > 0)
//                        {
//                            using (var memoryStream = new MemoryStream())
//                            {
//                                imageFile.CopyTo(memoryStream);
//                                var imageBytes = memoryStream.ToArray();

//                                // Obtén el último IdMatrizHallazgos dentro del bucle
//                                idMatrizHallazgos = db.MatrizHallazgos
//                                    .OrderByDescending(e => e.IdMatrizHallazgos)
//                                    .Select(e => e.IdMatrizHallazgos)
//                                    .FirstOrDefault();

//                                // Guarda la evidencia en la base de datos (ajusta según tu modelo)
//                                db.Evidencias.Add(new Evidencia
//                                {
//                                    Evidencia1 = imageBytes,
//                                    IdMatrizHallazgos = idMatrizHallazgos
//                                });
//                            }
//                        }
//                    }

//                    db.SaveChanges();
//                }

//                return Ok("Evidencias guardadas correctamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al cargar las imágenes: {ex.Message}");
//            }
//        }*/

//        [HttpPost]
//        [Route("insertarEvidencias")]
//        public IActionResult UploadImages(List<IFormFile> imageFiles)
//        {

//            /*if (imageFiles == null || imageFiles.Count == 0)
//            {
//                return BadRequest("No se proporcionaron archivos o los archivos están vacíos.");
//            }*/

//            try
//            {
//                using (SegregacionContext db = new SegregacionContext())
//                {

//                    int idMatrizHallazgos = 0; // Inicializa con un valor adecuado
//                    foreach (var imageFile in imageFiles)
//                    {
//                        if (imageFile != null && imageFile.Length > 0)
//                        {
//                            using (var memoryStream = new MemoryStream())
//                            {
//                                imageFile.CopyTo(memoryStream);
//                                var imageBytes = memoryStream.ToArray();
//                                // Obtén el último IdMatrizHallazgos dentro del bucle
//                                idMatrizHallazgos = db.MatrizHallazgos
//                                    .OrderByDescending(e => e.IdMatrizHallazgos)
//                                    .Select(e => e.IdMatrizHallazgos)
//                                    .FirstOrDefault();

//                                db.Evidencias.Add(new Evidencia
//                                {
//                                    Evidencia1 = imageBytes,
//                                    IdMatrizHallazgos = idMatrizHallazgos
//                                });
//                                db.SaveChanges();
//                            }
//                        }
//                    }
//                }

//                // Redirecciona a la página de éxito o muestra un mensaje al usuario
//                return Ok("UploadSuccess");
//            }
//            catch (Exception ex)
//            {
//                // Manejo de la excepción: puedes registrar el error, mostrar un mensaje al usuario, etc.
//                // Por ejemplo:
//                // Log.Error($"Error al cargar imágenes: {ex.Message}");
//                // return View("ErrorPage");
//                return BadRequest($"Error al cargar imágenes: {ex.Message}"); 
//            }
//        }


//        /*[HttpPost("insertarEvidencias")]
//        public IActionResult InsertarEvidencias([FromBody] byte[] evidenciaBytes)
//        {
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    if (evidenciaBytes != null && evidenciaBytes.Length > 0)
//                    {
//                        // Crear un nuevo objeto Evidencia y asignar los datos binarios de la imagen
//                        var evidencia = new Evidencia
//                        {
//                            Evidencia1 = evidenciaBytes,
//                            // Asigna el IdMatrizHallazgos adecuado (por ejemplo, el último registrado)
//                            IdMatrizHallazgos = ObtenerUltimoIdMatrizHallazgos()
//                        };

//                        // Agregar la evidencia a la base de datos y guardar los cambios
//                        bd.Evidencias.Add(evidencia);
//                        bd.SaveChanges();

//                        return Ok("Carga exitosa");
//                    }
//                    else
//                    {
//                        return BadRequest("No se proporcionó evidencia válida.");
//                    }
//                }
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al procesar la imagen: {ex.Message}");
//            }
//        }

//        private int ObtenerUltimoIdMatrizHallazgos()
//        {
//            // Obtén el último IdMatrizHallazgos registrado en la base de datos
//            using (SegregacionContext bd = new SegregacionContext())
//            {
//                return bd.MatrizHallazgos
//                .OrderByDescending(e => e.IdMatrizHallazgos)
//                .Select(e => e.IdMatrizHallazgos)
//                .FirstOrDefault();
//            }
//        }*/


//        [HttpPost]
//        [Route("actualizarAplicacionesMatrizHallazgo")]
//        public IActionResult ActualizarAplicacionesMatrizHallazgo([FromBody] List<ClaseActualizarAplicacion> datos)
//        {
//            try
//            {
//                // primero verificamos que no se halla enviado el arreglo nulo o vacio
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                // Guardamos en una variable el llamado a la base de datos
//                using (SegregacionContext db = new SegregacionContext())
//                {

//                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
//                    foreach (var campos in datos)
//                    {

//                        // Buscamos el puesto correspondiente con el vamos a trabajar
//                        var lista = db.MatrizHallazgos.Find(campos.IdMatrizHallazgos);

//                        // Si Existe el puesto ingresa los datos correspondientes
//                        if (lista != null)
//                        {
//                            lista.IdAplicacion = campos.IdAplicacion;
//                            db.SaveChanges();
//                        }

//                    }

//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {

//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        [HttpPost]
//        [Route("actualizarCriteriosMatrizHallazgo")]
//        public IActionResult ActualizarCriteriosMatrizHallazgo([FromBody] List<ClaseActualizarCriterio> datos)
//        {
//            try
//            {
//                // primero verificamos que no se halla enviado el arreglo nulo o vacio
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                // Guardamos en una variable el llamado a la base de datos
//                using (SegregacionContext db = new SegregacionContext())
//                {

//                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
//                    foreach (var campos in datos)
//                    {

//                        // Buscamos el puesto correspondiente con el vamos a trabajar
//                        var lista = db.MatrizHallazgos.Find(campos.IdMatrizHallazgos);

//                        // Si Existe el puesto ingresa los datos correspondientes
//                        if (lista != null)
//                        {
//                            lista.IdCriterio = campos.IdCriterio;
//                            db.SaveChanges();
//                        }

//                    }

//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {

//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        [HttpPost]
//        [Route("editarHallazgos")]
//        public IActionResult EditarHallazgos([FromBody] List<ClaseActualizarHallazgos> datos)
//        {
//            try
//            {
//                // primero verificamos que no se halla enviado el arreglo nulo o vacio
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                // Guardamos en una variable el llamado a la base de datos
//                using (SegregacionContext db = new SegregacionContext())
//                {

//                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
//                    foreach (var campos in datos)
//                    {

//                        // Buscamos el puesto correspondiente con el vamos a trabajar
//                        var lista = db.MatrizHallazgos.Find(campos.id);

//                        // Si Existe el puesto ingresa los datos correspondientes
//                        if (lista != null)
//                        {
//                            lista.NombreMenu = campos.nombreMenu;
//                            lista.NombreSubMenu = campos.nombreSubMenu;
//                            lista.Hallazgo = campos.hallazgo;
//                            lista.Recomendación = campos.recomendacion;
//                            db.SaveChanges();
//                        }

//                    }

//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {

//                return StatusCode(500, "Error interno del servidor");
//            }
//        }
//    }
//}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///


//ESTA VERSION ES FUNSIONAL PERO LA EDICION DE AppSinHallazgos tiene un detalle 



//using Microsoft.AspNetCore.Mvc;
//using System.Globalization;
//using WebApplication1._6.Clases;
//using WebApplication1._6.Models;

//namespace WebApplication1._6.Controllers
//{
//    public class IngresarHallazgosController : Controller
//    {
//        public IActionResult Index()
//        {
//            return View();
//        }

//        // Método para insertar hallazgos
//        [HttpPost]
//        [Route("InsertTabla1")]
//        public IActionResult InsertarHallazgos([FromBody] List<ClaseMatriz> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (var segregacion = new SegregacionContext())
//                {
//                    foreach (var matrizHallazgo in datos)
//                    {
//                        var entidadHallazgo = new MatrizHallazgo
//                        {
//                            IdPuestosRegionales = matrizHallazgo.IdPuestosRegionales,
//                            IdAplicacion = matrizHallazgo.IdAplicacion,
//                            Descripcion = matrizHallazgo.Descripcion,
//                            NombreMenu = matrizHallazgo.NombreMenu,
//                            NombreSubMenu = matrizHallazgo.NombreSubMenu,
//                            Hallazgo = matrizHallazgo.Hallazgo,
//                            IdCriterio = matrizHallazgo.IdCriterio,
//                            Recomendación = matrizHallazgo.Recomendacion,
//                            Resolucion = 1,
//                            EstadoHallazgo = "Pendiente"
//                        };
//                        segregacion.Add(entidadHallazgo);
//                    }

//                    segregacion.SaveChanges();
//                }

//                return Ok("Datos de hallazgos agregados exitosamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
//            }
//        }

//        // Método para obtener los hallazgos
//        [HttpGet("obtenerHallazgos")]
//        public List<ClaseHallazgos> ObtenerHallazgos(int IdPuestosRegionales)
//        {
//            List<ClaseHallazgos> lista = new List<ClaseHallazgos>();
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    lista = (from pr in bd.MatrizHallazgos
//                             join p in bd.Aplicacions on pr.IdAplicacion equals p.IdAplicacion
//                             join f in bd.Criterios on pr.IdCriterio equals f.IdCriterio
//                             join g in bd.PuestosRegionales on pr.IdPuestosRegionales equals g.IdPuestosRegionales
//                             where pr.IdPuestosRegionales == IdPuestosRegionales && pr.NombreMenu != "N/A"
//                             select new ClaseHallazgos()
//                             {
//                                 IdMatrizHallazgos = pr.IdMatrizHallazgos,
//                                 IdPuestosRegionales = IdPuestosRegionales,
//                                 NombreAplicacion = p.NombreAplicacion,
//                                 NombreMenu = pr.NombreMenu,
//                                 NombreSubMenu = pr.NombreSubMenu,
//                                 Hallazgo = pr.Hallazgo,
//                                 NombreCriterio = f.NombreCriterio,
//                                 Recomendacion = pr.Recomendación,
//                                 Descripcion = pr.Descripcion,
//                             }).ToList();
//                    return lista;
//                }
//            }
//            catch (Exception ex)
//            {
//                return lista;
//            }
//        }

//        // Método para obtener sin hallazgos
//        [HttpGet("obtenerSinHallazgos")]
//        public List<ClaseHallazgos2> ObtenerSinHallazgos(int IdPuestosRegionales)
//        {
//            List<ClaseHallazgos2> lista = new List<ClaseHallazgos2>();
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    lista = (from pr in bd.MatrizHallazgos
//                             join g in bd.PuestosRegionales on pr.IdPuestosRegionales equals g.IdPuestosRegionales
//                             join p in bd.Aplicacions on pr.IdAplicacion equals p.IdAplicacion
//                             where pr.IdPuestosRegionales == IdPuestosRegionales && pr.NombreMenu == "N/A"
//                             select new ClaseHallazgos2()
//                             {
//                                 IdMatrizHallazgos = pr.IdMatrizHallazgos,
//                                 Descripcion = pr.Descripcion,
//                                 NombreAplicacion = p.NombreAplicacion,
//                             }).ToList();

//                    return lista;
//                }
//            }
//            catch (Exception ex)
//            {
//                return lista;
//            }
//        }

//        // Método para eliminar sin hallazgos
//        [HttpDelete("eliminarSinHallazgo/{id}")]
//        public IActionResult EliminarSinHallazgo(int id)
//        {
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    var hallazgo = bd.MatrizHallazgos.FirstOrDefault(ap => ap.IdMatrizHallazgos == id);
//                    if (hallazgo == null)
//                    {
//                        return NotFound($"No se encontró el hallazgo con ID {id}");
//                    }

//                    bd.MatrizHallazgos.Remove(hallazgo);
//                    bd.SaveChanges();
//                }
//                return Ok("Aplicación sin hallazgo eliminada correctamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al eliminar la aplicación sin hallazgo: {ex.Message}");
//            }
//        }

//        // Método para eliminar hallazgos
//        [HttpDelete("eliminarHallazgo/{id}")]
//        public IActionResult EliminarHallazgo(int id)
//        {
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    var hallazgo = bd.MatrizHallazgos.FirstOrDefault(ap => ap.IdMatrizHallazgos == id);
//                    if (hallazgo == null)
//                    {
//                        return NotFound($"No se encontró el hallazgo con ID {id}");
//                    }

//                    bd.MatrizHallazgos.Remove(hallazgo);
//                    bd.SaveChanges();
//                }
//                return Ok("Hallazgo eliminado correctamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al eliminar el hallazgo: {ex.Message}");
//            }
//        }

//        // Método para subir y guardar evidencias en la base de datos
//        [HttpPost]
//        [Route("insertarEvidencias")]
//        public IActionResult UploadImages(List<IFormFile> imageFiles, int idMatrizHallazgos)
//        {
//            try
//            {
//                if (imageFiles == null || imageFiles.Count == 0)
//                {
//                    return BadRequest("No se proporcionaron archivos o los archivos están vacíos.");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var imageFile in imageFiles)
//                    {
//                        if (imageFile != null && imageFile.Length > 0)
//                        {
//                            using (var memoryStream = new MemoryStream())
//                            {
//                                imageFile.CopyTo(memoryStream);
//                                var imageBytes = memoryStream.ToArray();

//                                db.Evidencias.Add(new Evidencia
//                                {
//                                    Evidencia1 = imageBytes,
//                                    IdMatrizHallazgos = idMatrizHallazgos
//                                });
//                            }
//                        }
//                    }

//                    db.SaveChanges();
//                }

//                return Ok("Evidencias subidas exitosamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al cargar imágenes: {ex.Message}");
//            }
//        }

//        // Método para insertar terminología
//        [HttpPost]
//        [Route("InsertarTerminologia")]
//        public IActionResult InsertarTerminologia([FromBody] List<ClaseTerminosDetalle> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (var segregacion = new SegregacionContext())
//                {
//                    foreach (var Terminos in datos)
//                    {
//                        var terminos = new TerminologiaDetalle
//                        {
//                            IdPuestosRegionales = Terminos.IdPuestosRegionales,
//                            IdListaTerminologia = Terminos.IdListaTerminologia,
//                        };

//                        segregacion.Add(terminos);
//                    }

//                    segregacion.SaveChanges();
//                }

//                return Ok("Terminología agregada exitosamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
//            }
//        }

//        // Método para agregar fecha de revisión
//        [HttpPost]
//        [Route("agregarFechaRevision")]
//        public IActionResult AgregarFechaRevision([FromBody] List<ClaseFecha> datos)
//        {
//            try
//            {
//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var fecha in datos)
//                    {
//                        var lista = db.PuestosRegionales.Find(fecha.IdPuestosRegionales);
//                        if (lista != null)
//                        {
//                            if (DateTime.TryParseExact(fecha.FechaAsignacion, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fechaCompleta))
//                            {
//                                DateOnly fechaSinHora = new DateOnly(fechaCompleta.Year, fechaCompleta.Month, fechaCompleta.Day);
//                                lista.FechaRevision = fechaSinHora;

//                                db.SaveChanges();
//                            }
//                            else
//                            {
//                                return BadRequest("La cadena de fecha no es válida o no se pudo analizar correctamente.");
//                            }
//                        }
//                        else
//                        {
//                            return NotFound($"No se encontró el registro con ID {fecha.IdPuestosRegionales}.");
//                        }
//                    }
//                }

//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        // Método para actualizar las aplicaciones en MatrizHallazgos
//        [HttpPost]
//        [Route("actualizarAplicacionesMatrizHallazgo")]
//        public IActionResult ActualizarAplicacionesMatrizHallazgo([FromBody] List<ClaseActualizarAplicacion> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var campos in datos)
//                    {
//                        var lista = db.MatrizHallazgos.Find(campos.IdMatrizHallazgos);

//                        if (lista != null)
//                        {
//                            lista.IdAplicacion = campos.IdAplicacion;
//                            db.SaveChanges();
//                        }
//                    }
//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        // Método para actualizar los criterios en MatrizHallazgos
//        [HttpPost]
//        [Route("actualizarCriteriosMatrizHallazgo")]
//        public IActionResult ActualizarCriteriosMatrizHallazgo([FromBody] List<ClaseActualizarCriterio> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var campos in datos)
//                    {
//                        var lista = db.MatrizHallazgos.Find(campos.IdMatrizHallazgos);

//                        if (lista != null)
//                        {
//                            lista.IdCriterio = campos.IdCriterio;
//                            db.SaveChanges();
//                        }
//                    }
//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        // Método para editar hallazgos
//        [HttpPost]
//        [Route("editarHallazgos")]
//        public IActionResult EditarHallazgos([FromBody] List<ClaseActualizarHallazgos> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var campos in datos)
//                    {
//                        var lista = db.MatrizHallazgos.Find(campos.id);

//                        if (lista != null)
//                        {
//                            lista.NombreMenu = campos.nombreMenu;
//                            lista.NombreSubMenu = campos.nombreSubMenu;
//                            lista.Hallazgo = campos.hallazgo;
//                            lista.Recomendación = campos.recomendacion;
//                            db.SaveChanges();
//                        }
//                    }
//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }
//    }
//}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//ESTA VERSION ES FUNSIONAL PERO solo edita las descripciones de AppSinHallazgos 



//using Microsoft.AspNetCore.Mvc;
//using System.Globalization;
//using WebApplication1._6.Clases;
//using WebApplication1._6.Models;

//namespace WebApplication1._6.Controllers
//{
//    public class IngresarHallazgosController : Controller
//    {
//        public IActionResult Index()
//        {
//            return View();
//        }

//        // Método para insertar hallazgos
//        [HttpPost]
//        [Route("InsertTabla1")]
//        public IActionResult InsertarHallazgos([FromBody] List<ClaseMatriz> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (var segregacion = new SegregacionContext())
//                {
//                    foreach (var matrizHallazgo in datos)
//                    {
//                        var entidadHallazgo = new MatrizHallazgo
//                        {
//                            IdPuestosRegionales = matrizHallazgo.IdPuestosRegionales,
//                            IdAplicacion = matrizHallazgo.IdAplicacion,
//                            Descripcion = matrizHallazgo.Descripcion,
//                            NombreMenu = matrizHallazgo.NombreMenu,
//                            NombreSubMenu = matrizHallazgo.NombreSubMenu,
//                            Hallazgo = matrizHallazgo.Hallazgo,
//                            IdCriterio = matrizHallazgo.IdCriterio,
//                            Recomendación = matrizHallazgo.Recomendacion,
//                            Resolucion = 1,
//                            EstadoHallazgo = "Pendiente"
//                        };
//                        segregacion.Add(entidadHallazgo);
//                    }

//                    segregacion.SaveChanges();
//                }

//                return Ok("Datos de hallazgos agregados exitosamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
//            }
//        }

//        // Método para obtener los hallazgos
//        [HttpGet("obtenerHallazgos")]
//        public List<ClaseHallazgos> ObtenerHallazgos(int IdPuestosRegionales)
//        {
//            List<ClaseHallazgos> lista = new List<ClaseHallazgos>();
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    lista = (from pr in bd.MatrizHallazgos
//                             join p in bd.Aplicacions on pr.IdAplicacion equals p.IdAplicacion
//                             join f in bd.Criterios on pr.IdCriterio equals f.IdCriterio
//                             join g in bd.PuestosRegionales on pr.IdPuestosRegionales equals g.IdPuestosRegionales
//                             where pr.IdPuestosRegionales == IdPuestosRegionales && pr.NombreMenu != "N/A"
//                             select new ClaseHallazgos()
//                             {
//                                 IdMatrizHallazgos = pr.IdMatrizHallazgos,
//                                 IdPuestosRegionales = IdPuestosRegionales,
//                                 NombreAplicacion = p.NombreAplicacion,
//                                 NombreMenu = pr.NombreMenu,
//                                 NombreSubMenu = pr.NombreSubMenu,
//                                 Hallazgo = pr.Hallazgo,
//                                 NombreCriterio = f.NombreCriterio,
//                                 Recomendacion = pr.Recomendación,
//                                 Descripcion = pr.Descripcion,
//                             }).ToList();
//                    return lista;
//                }
//            }
//            catch (Exception ex)
//            {
//                return lista;
//            }
//        }

//        // Método para obtener sin hallazgos
//        [HttpGet("obtenerSinHallazgos")]
//        public List<ClaseHallazgos2> ObtenerSinHallazgos(int IdPuestosRegionales)
//        {
//            List<ClaseHallazgos2> lista = new List<ClaseHallazgos2>();
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    lista = (from pr in bd.MatrizHallazgos
//                             join g in bd.PuestosRegionales on pr.IdPuestosRegionales equals g.IdPuestosRegionales
//                             join p in bd.Aplicacions on pr.IdAplicacion equals p.IdAplicacion
//                             where pr.IdPuestosRegionales == IdPuestosRegionales && pr.NombreMenu == "N/A"
//                             select new ClaseHallazgos2()
//                             {
//                                 IdMatrizHallazgos = pr.IdMatrizHallazgos,
//                                 Descripcion = pr.Descripcion,
//                                 NombreAplicacion = p.NombreAplicacion,
//                             }).ToList();

//                    return lista;
//                }
//            }
//            catch (Exception ex)
//            {
//                return lista;
//            }
//        }

//        // Método para eliminar sin hallazgos
//        [HttpDelete("eliminarSinHallazgo/{id}")]
//        public IActionResult EliminarSinHallazgo(int id)
//        {
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    var hallazgo = bd.MatrizHallazgos.FirstOrDefault(ap => ap.IdMatrizHallazgos == id);
//                    if (hallazgo == null)
//                    {
//                        return NotFound($"No se encontró el hallazgo con ID {id}");
//                    }

//                    bd.MatrizHallazgos.Remove(hallazgo);
//                    bd.SaveChanges();
//                }
//                return Ok("Aplicación sin hallazgo eliminada correctamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al eliminar la aplicación sin hallazgo: {ex.Message}");
//            }
//        }

//        // Método para eliminar hallazgos
//        [HttpDelete("eliminarHallazgo/{id}")]
//        public IActionResult EliminarHallazgo(int id)
//        {
//            try
//            {
//                using (SegregacionContext bd = new SegregacionContext())
//                {
//                    var hallazgo = bd.MatrizHallazgos.FirstOrDefault(ap => ap.IdMatrizHallazgos == id);
//                    if (hallazgo == null)
//                    {
//                        return NotFound($"No se encontró el hallazgo con ID {id}");
//                    }

//                    bd.MatrizHallazgos.Remove(hallazgo);
//                    bd.SaveChanges();
//                }
//                return Ok("Hallazgo eliminado correctamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al eliminar el hallazgo: {ex.Message}");
//            }
//        }

//        // Método para subir y guardar evidencias en la base de datos
//        [HttpPost]
//        [Route("insertarEvidencias")]
//        public IActionResult UploadImages(List<IFormFile> imageFiles, int idMatrizHallazgos)
//        {
//            try
//            {
//                if (imageFiles == null || imageFiles.Count == 0)
//                {
//                    return BadRequest("No se proporcionaron archivos o los archivos están vacíos.");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var imageFile in imageFiles)
//                    {
//                        if (imageFile != null && imageFile.Length > 0)
//                        {
//                            using (var memoryStream = new MemoryStream())
//                            {
//                                imageFile.CopyTo(memoryStream);
//                                var imageBytes = memoryStream.ToArray();

//                                db.Evidencias.Add(new Evidencia
//                                {
//                                    Evidencia1 = imageBytes,
//                                    IdMatrizHallazgos = idMatrizHallazgos
//                                });
//                            }
//                        }
//                    }

//                    db.SaveChanges();
//                }

//                return Ok("Evidencias subidas exitosamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al cargar imágenes: {ex.Message}");
//            }
//        }

//        // Método para insertar terminología
//        [HttpPost]
//        [Route("InsertarTerminologia")]
//        public IActionResult InsertarTerminologia([FromBody] List<ClaseTerminosDetalle> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (var segregacion = new SegregacionContext())
//                {
//                    foreach (var Terminos in datos)
//                    {
//                        var terminos = new TerminologiaDetalle
//                        {
//                            IdPuestosRegionales = Terminos.IdPuestosRegionales,
//                            IdListaTerminologia = Terminos.IdListaTerminologia,
//                        };

//                        segregacion.Add(terminos);
//                    }

//                    segregacion.SaveChanges();
//                }

//                return Ok("Terminología agregada exitosamente.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
//            }
//        }

//        // Método para agregar fecha de revisión
//        [HttpPost]
//        [Route("agregarFechaRevision")]
//        public IActionResult AgregarFechaRevision([FromBody] List<ClaseFecha> datos)
//        {
//            try
//            {
//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var fecha in datos)
//                    {
//                        var lista = db.PuestosRegionales.Find(fecha.IdPuestosRegionales);
//                        if (lista != null)
//                        {
//                            if (DateTime.TryParseExact(fecha.FechaAsignacion, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fechaCompleta))
//                            {
//                                DateOnly fechaSinHora = new DateOnly(fechaCompleta.Year, fechaCompleta.Month, fechaCompleta.Day);
//                                lista.FechaRevision = fechaSinHora;

//                                db.SaveChanges();
//                            }
//                            else
//                            {
//                                return BadRequest("La cadena de fecha no es válida o no se pudo analizar correctamente.");
//                            }
//                        }
//                        else
//                        {
//                            return NotFound($"No se encontró el registro con ID {fecha.IdPuestosRegionales}.");
//                        }
//                    }
//                }

//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        // Método para actualizar las aplicaciones en MatrizHallazgos
//        [HttpPost]
//        [Route("actualizarAplicacionesMatrizHallazgo")]
//        public IActionResult ActualizarAplicacionesMatrizHallazgo([FromBody] List<ClaseActualizarAplicacion> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var campos in datos)
//                    {
//                        var lista = db.MatrizHallazgos.Find(campos.IdMatrizHallazgos);

//                        if (lista != null)
//                        {
//                            lista.IdAplicacion = campos.IdAplicacion;
//                            db.SaveChanges();
//                        }
//                    }
//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        // Método para actualizar los criterios en MatrizHallazgos
//        [HttpPost]
//        [Route("actualizarCriteriosMatrizHallazgo")]
//        public IActionResult ActualizarCriteriosMatrizHallazgo([FromBody] List<ClaseActualizarCriterio> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var campos in datos)
//                    {
//                        var lista = db.MatrizHallazgos.Find(campos.IdMatrizHallazgos);

//                        if (lista != null)
//                        {
//                            lista.IdCriterio = campos.IdCriterio;
//                            db.SaveChanges();
//                        }
//                    }
//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        // Método para editar hallazgos
//        [HttpPost]
//        [Route("editarHallazgos")]
//        public IActionResult EditarHallazgos([FromBody] List<ClaseActualizarHallazgos> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var campos in datos)
//                    {
//                        var lista = db.MatrizHallazgos.Find(campos.id);

//                        if (lista != null)
//                        {
//                            lista.NombreMenu = campos.nombreMenu;
//                            lista.NombreSubMenu = campos.nombreSubMenu;
//                            lista.Hallazgo = campos.hallazgo;
//                            lista.Recomendación = campos.recomendacion;
//                            db.SaveChanges();
//                        }
//                    }
//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }

//        // Método para editar Sin hallazgos
//        [HttpPost]
//        [Route("editarSinHallazgos")]
//        public IActionResult EditarSinHallazgos([FromBody] List<ClaseActualizarSinHallazgos> datos)
//        {
//            try
//            {
//                if (datos == null || datos.Count == 0)
//                {
//                    return BadRequest("La lista de Datos está vacía o es nula");
//                }

//                using (SegregacionContext db = new SegregacionContext())
//                {
//                    foreach (var campos in datos)
//                    {
//                        var lista = db.MatrizHallazgos.Find(campos.id);

//                        if (lista != null)
//                        {
//                            lista.Descripcion = campos.descripcion;
//                            db.SaveChanges();
//                        }
//                    }
//                }
//                return Ok("Datos Insertados Correctamente");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Error interno del servidor");
//            }
//        }
//    }
//}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Globalization;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class IngresarHallazgosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // Método para insertar hallazgos
        [HttpPost]
        [Route("InsertTabla1")]
        public IActionResult InsertarHallazgos([FromBody] List<ClaseMatriz> datos)
        {
            try
            {
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                using (var segregacion = new SegregacionContext())
                {
                    foreach (var matrizHallazgo in datos)
                    {
                        var entidadHallazgo = new MatrizHallazgo
                        {
                            IdPuestosRegionales = matrizHallazgo.IdPuestosRegionales,
                            IdAplicacion = matrizHallazgo.IdAplicacion,
                            Descripcion = matrizHallazgo.Descripcion,
                            NombreMenu = matrizHallazgo.NombreMenu,
                            NombreSubMenu = matrizHallazgo.NombreSubMenu,
                            Hallazgo = matrizHallazgo.Hallazgo,
                            IdCriterio = matrizHallazgo.IdCriterio,
                            Recomendación = matrizHallazgo.Recomendacion,
                            Resolucion = 1,
                            EstadoHallazgo = "Pendiente"
                        };
                        segregacion.Add(entidadHallazgo);
                    }

                    segregacion.SaveChanges();
                }

                return Ok("Datos de hallazgos agregados exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }

        // Método para obtener los hallazgos
        [HttpGet("obtenerHallazgos")]
        public List<ClaseHallazgos> ObtenerHallazgos(int IdPuestosRegionales)
        {
            List<ClaseHallazgos> lista = new List<ClaseHallazgos>();
            try
            {
                using (SegregacionContext bd = new SegregacionContext())
                {
                    lista = (from pr in bd.MatrizHallazgos
                             join p in bd.Aplicacions on pr.IdAplicacion equals p.IdAplicacion
                             join f in bd.Criterios on pr.IdCriterio equals f.IdCriterio
                             join g in bd.PuestosRegionales on pr.IdPuestosRegionales equals g.IdPuestosRegionales
                             where pr.IdPuestosRegionales == IdPuestosRegionales && pr.NombreMenu != "N/A"
                             select new ClaseHallazgos()
                             {
                                 IdMatrizHallazgos = pr.IdMatrizHallazgos,
                                 IdPuestosRegionales = IdPuestosRegionales,
                                 NombreAplicacion = p.NombreAplicacion,
                                 NombreMenu = pr.NombreMenu,
                                 NombreSubMenu = pr.NombreSubMenu,
                                 Hallazgo = pr.Hallazgo,
                                 NombreCriterio = f.NombreCriterio,
                                 Recomendacion = pr.Recomendación,
                                 Descripcion = pr.Descripcion,
                             }).ToList();
                    return lista;
                }
            }
            catch (Exception ex)
            {
                return lista;
            }
        }

        // Método para obtener sin hallazgos
        [HttpGet("obtenerSinHallazgos")]
        public List<ClaseHallazgos2> ObtenerSinHallazgos(int IdPuestosRegionales)
        {
            List<ClaseHallazgos2> lista = new List<ClaseHallazgos2>();
            try
            {
                using (SegregacionContext bd = new SegregacionContext())
                {
                    lista = (from pr in bd.MatrizHallazgos
                             join g in bd.PuestosRegionales on pr.IdPuestosRegionales equals g.IdPuestosRegionales
                             join p in bd.Aplicacions on pr.IdAplicacion equals p.IdAplicacion
                             where pr.IdPuestosRegionales == IdPuestosRegionales && pr.NombreMenu == "N/A"
                             select new ClaseHallazgos2()
                             {
                                 IdMatrizHallazgos = pr.IdMatrizHallazgos,
                                 Descripcion = pr.Descripcion,
                                 NombreAplicacion = p.NombreAplicacion,
                                 IdAplicacion = p.IdAplicacion // Agregar esta línea para obtener el ID de la aplicación
                             }).ToList();

                    return lista;
                }
            }
            catch (Exception ex)
            {
                return lista;
            }
        }

        // Método para eliminar sin hallazgos
        [HttpDelete("eliminarSinHallazgo/{id}")]
        public IActionResult EliminarSinHallazgo(int id)
        {
            try
            {
                using (SegregacionContext bd = new SegregacionContext())
                {
                    var hallazgo = bd.MatrizHallazgos.FirstOrDefault(ap => ap.IdMatrizHallazgos == id);
                    if (hallazgo == null)
                    {
                        return NotFound($"No se encontró el hallazgo con ID {id}");
                    }

                    bd.MatrizHallazgos.Remove(hallazgo);
                    bd.SaveChanges();
                }
                return Ok("Aplicación sin hallazgo eliminada correctamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar la aplicación sin hallazgo: {ex.Message}");
            }
        }

        // Método para eliminar hallazgos
        [HttpDelete("eliminarHallazgo/{id}")]
        public IActionResult EliminarHallazgo(int id)
        {
            try
            {
                using (SegregacionContext bd = new SegregacionContext())
                {
                    var hallazgo = bd.MatrizHallazgos.FirstOrDefault(ap => ap.IdMatrizHallazgos == id);
                    if (hallazgo == null)
                    {
                        return NotFound($"No se encontró el hallazgo con ID {id}");
                    }

                    bd.MatrizHallazgos.Remove(hallazgo);
                    bd.SaveChanges();
                }
                return Ok("Hallazgo eliminado correctamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar el hallazgo: {ex.Message}");
            }
        }

        // Método para subir y guardar evidencias en la base de datos
        [HttpPost]
        [Route("insertarEvidencias")]
        public IActionResult UploadImages(List<IFormFile> imageFiles, int idMatrizHallazgos)
        {
            try
            {
                if (imageFiles == null || imageFiles.Count == 0)
                {
                    return BadRequest("No se proporcionaron archivos o los archivos están vacíos.");
                }

                using (SegregacionContext db = new SegregacionContext())
                {
                    foreach (var imageFile in imageFiles)
                    {
                        if (imageFile != null && imageFile.Length > 0)
                        {
                            using (var memoryStream = new MemoryStream())
                            {
                                imageFile.CopyTo(memoryStream);
                                var imageBytes = memoryStream.ToArray();

                                db.Evidencias.Add(new Evidencia
                                {
                                    Evidencia1 = imageBytes,
                                    IdMatrizHallazgos = idMatrizHallazgos
                                });
                            }
                        }
                    }

                    db.SaveChanges();
                }

                return Ok("Evidencias subidas exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al cargar imágenes: {ex.Message}");
            }
        }

        // Método para insertar terminología
        [HttpPost]
        [Route("InsertarTerminologia")]
        public IActionResult InsertarTerminologia([FromBody] List<ClaseTerminosDetalle> datos)
        {
            try
            {
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                using (var segregacion = new SegregacionContext())
                {
                    foreach (var Terminos in datos)
                    {
                        var terminos = new TerminologiaDetalle
                        {
                            IdPuestosRegionales = Terminos.IdPuestosRegionales,
                            IdListaTerminologia = Terminos.IdListaTerminologia,
                        };

                        segregacion.Add(terminos);
                    }

                    segregacion.SaveChanges();
                }

                return Ok("Terminología agregada exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }

        // Método para agregar fecha de revisión
        [HttpPost]
        [Route("agregarFechaRevision")]
        public IActionResult AgregarFechaRevision([FromBody] List<ClaseFecha> datos)
        {
            try
            {
                using (SegregacionContext db = new SegregacionContext())
                {
                    foreach (var fecha in datos)
                    {
                        var lista = db.PuestosRegionales.Find(fecha.IdPuestosRegionales);
                        if (lista != null)
                        {
                            if (DateTime.TryParseExact(fecha.FechaAsignacion, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fechaCompleta))
                            {
                                DateOnly fechaSinHora = new DateOnly(fechaCompleta.Year, fechaCompleta.Month, fechaCompleta.Day);
                                lista.FechaRevision = fechaSinHora;

                                db.SaveChanges();
                            }
                            else
                            {
                                return BadRequest("La cadena de fecha no es válida o no se pudo analizar correctamente.");
                            }
                        }
                        else
                        {
                            return NotFound($"No se encontró el registro con ID {fecha.IdPuestosRegionales}.");
                        }
                    }
                }

                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error interno del servidor");
            }
        }

        // Método para actualizar las aplicaciones en MatrizHallazgos
        [HttpPost]
        [Route("actualizarAplicacionesMatrizHallazgo")]
        public IActionResult ActualizarAplicacionesMatrizHallazgo([FromBody] List<ClaseActualizarAplicacion> datos)
        {
            try
            {
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                using (SegregacionContext db = new SegregacionContext())
                {
                    foreach (var campos in datos)
                    {
                        var lista = db.MatrizHallazgos.Find(campos.IdMatrizHallazgos);

                        if (lista != null)
                        {
                            lista.IdAplicacion = campos.IdAplicacion;
                            db.SaveChanges();
                        }
                    }
                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error interno del servidor");
            }
        }

        // Método para actualizar los criterios en MatrizHallazgos
        [HttpPost]
        [Route("actualizarCriteriosMatrizHallazgo")]
        public IActionResult ActualizarCriteriosMatrizHallazgo([FromBody] List<ClaseActualizarCriterio> datos)
        {
            try
            {
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                using (SegregacionContext db = new SegregacionContext())
                {
                    foreach (var campos in datos)
                    {
                        var lista = db.MatrizHallazgos.Find(campos.IdMatrizHallazgos);

                        if (lista != null)
                        {
                            lista.IdCriterio = campos.IdCriterio;
                            db.SaveChanges();
                        }
                    }
                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error interno del servidor");
            }
        }

        // Método para editar hallazgos
        [HttpPost]
        [Route("editarHallazgos")]
        public IActionResult EditarHallazgos([FromBody] List<ClaseActualizarHallazgos> datos)
        {
            try
            {
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                using (SegregacionContext db = new SegregacionContext())
                {
                    foreach (var campos in datos)
                    {
                        var lista = db.MatrizHallazgos.Find(campos.id);

                        if (lista != null)
                        {
                            lista.NombreMenu = campos.nombreMenu;
                            lista.NombreSubMenu = campos.nombreSubMenu;
                            lista.Hallazgo = campos.hallazgo;
                            lista.Recomendación = campos.recomendacion;
                            db.SaveChanges();
                        }
                    }
                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error interno del servidor");
            }
        }

        // Método para editar Sin hallazgos
        [HttpPost]
        [Route("editarSinHallazgos")]
        public IActionResult EditarSinHallazgos([FromBody] List<ClaseActualizarSinHallazgos> datos)
        {
            try
            {
                if

(datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                using (SegregacionContext db = new SegregacionContext())
                {
                    foreach (var campos in datos)
                    {
                        var lista = db.MatrizHallazgos.Find(campos.id);

                        if (lista != null)
                        {
                            lista.Descripcion = campos.descripcion;
                            
                            lista.IdAplicacion = campos.idAplicacion; // Actualización de IdAplicacion
                            db.SaveChanges();
                        }
                    }
                }
                return Ok("Datos actualizados correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }
    }
}
