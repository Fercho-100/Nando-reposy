﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class DivisionsController : Controller
    {
        private readonly SegregacionContext _context;

        public DivisionsController(SegregacionContext context)
        {
            _context = context;
        }

        //Este metodo nos retorna las divisiones guardadas en la base de datos para alimentar cualquier pantalla que lo necesite
        // Entradas:
        // 
        //
        // Salidas:
        // Lista de objetos con las variables de  la clase ClaseDivision

        [HttpGet("obtenerDivisiones")]
        public List<ClaseDivision> obtenerDivisiones()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseDivision> lista1 = new List<ClaseDivision>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla divisiones y los guardamos en nuestro list exceptuando los registros que sean N/A  (Reservado para registros sin hallazgo)
                    lista1 = (from a in bd.Divisions
                              where a.NombreDivision != "N/A"
                              select new ClaseDivision()
                              {
                                  IdDivision = a.IdDivision,
                                  NombreDivision = a.NombreDivision
                                  ActivoDivision = a.ActivoDivision
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }

        //Este metodo sirve para ingresar una nueva division para que podamos utilizarla en otros procesos que lo requieran
        // Entradas:
        // ClaseDivision2: Clase que contiene las variables que vamos a recibir en el JSON
        //
        // Salidas:
        // Respuesta atravez de un mensaje indicando si la division se agregó exitosamente o si hubo un error

        [HttpPost]
        [Route("InsertarDivision")]
        public IActionResult InsertarDivision([FromBody] List<ClaseDivision2> datos)
        {
            try
            {
                // Primero verificamos que no se halla enviado el arreglo nulo o vacio

                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var Division in datos)
                    {
                        var division = new Division
                        {
                            NombreDivision = division.NombreDivision,
                            ActivoDivision = division.ActivoDivision = true
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(division);
                    }
                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Division agregada exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }
    }
}
