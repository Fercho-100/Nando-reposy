﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Models;
using WebApplication1._6.Clases;

namespace WebApplication1._6.Controllers
{
    public class AplicacionsController : Controller
    {
        private readonly SegregacionContext _context;

        public AplicacionsController(SegregacionContext context)
        {
            _context = context;
        }


        // Este método nos retorna las aplicaciones guardadas en la base de datos para alimentar cualquier pantalla que lo necesite
        // Entradas:
        // 
        //
        // Salidas:
        // Lista de objetos con las variables de  la clase ClaseAplicaciones

        [HttpGet("obtenerAplicaciones")]
        public List<ClaseAplicaciones> obtenerAplicaciones()
        {
            // Creamos una lista para guardar los datos que vamos a obtener
            List<ClaseAplicaciones> lista1 = new List<ClaseAplicaciones>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla "Aplicacions" y guardamos los resultados en nuestra lista
                    lista1 = (from a in bd.Aplicacions
                              select new ClaseAplicaciones()
                              {
                                  IdAplicacion = a.IdAplicacion,
                                  label = a.NombreAplicacion,
                                  ActivoAplicacion = a.ActivoAplicacion
                              }).ToList();

                    // Por último, retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error, enviamos una lista vacía
                return lista1;
            }
        }


        //Este metodo es para ingresar una nueva aplicacion para que podamos utilizarla en otros procesos que lo requieran
        // Entradas:
        // ClaseAplicaciones2: Clase que contiene las variables que vamos a recibir en el JSON
        //
        // Salidas:
        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error
        [HttpPost]
        [Route("InsertarAplicaciones")]
        public IActionResult InsertarAplicaciones([FromBody] List<ClaseAplicaciones2> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {
                    
                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var Aplicacion in datos)
                    {
                        var entidadHallazgo = new Aplicacion
                        {
                            NombreAplicacion = Aplicacion.NombreAplicacion,
                            ActivoAplicacion = Aplicacion.ActivoAplicacion = true,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadHallazgo);
                    }
                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Aplicacion agregada exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }

        [HttpPut("ModificarAplicacion/{id}")]
        public IActionResult ModificarAplicacion(int id, [FromBody] ClaseAplicacionesModificar datos)
        {
            try
            {
                // Verificamos que los datos no sean nulos
                if (datos == null)
                {
                    return BadRequest("Los datos proporcionados son nulos.");
                }

                // Usamos el contexto de la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Buscamos la aplicación a modificar
                    var aplicacion = bd.Aplicacions.FirstOrDefault(ap => ap.IdAplicacion == id);

                    if (aplicacion != null)
                    {
                        // Si la aplicación existe, actualizamos sus campos
                        aplicacion.NombreAplicacion = datos.NombreAplicacion;

                        // Guardamos los cambios en la base de datos
                        bd.SaveChanges();

                        return Ok("Aplicación modificada correctamente.");
                    }
                    else
                    {
                        return NotFound("No se encontró la aplicación con el ID proporcionado.");
                    }
                }
            }
            catch (Exception ex)
            {
                // En caso de un error, devolvemos un mensaje de error
                return StatusCode(500, $"Ocurrió un error al intentar modificar la aplicación: {ex.Message}");
            }
        }

        [HttpDelete("eliminarAplicacion/{id}")]
        public IActionResult EliminarAplicacion(int id)
        {
            // Creamos una lista para manejar posibles errores y devoluciones
            List<ClaseAplicacionesDelete> lista = new List<ClaseAplicacionesDelete>();

            try
            {
                // Usamos el contexto de la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Buscamos la aplicación a deshabilitar
                    var aplicacion = bd.Aplicacions.FirstOrDefault(ap => ap.IdAplicacion == id);

                    if (aplicacion != null)
                    {
                        // Deshabilitamos la aplicación (marcamos IsActive como false)
                        aplicacion.ActivoAplicacion = false;

                        // Guardamos los cambios en la base de datos
                        bd.SaveChanges();

                        return Ok("Responsable eliminado correctamente.");
                    }
                    else
                    {
                        return NotFound("No se encontró el responsable con el ID proporcionado.");
                    }
                }
            }
            catch (Exception ex)
            {
                // En caso de un error, devolvemos un mensaje de error
                return StatusCode(500, "Ocurrió un error al intentar eliminar el responsable.");
            }
        }




    }
}
