﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Generics;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


        // El siguiente metodo nos sirve para crear un nuevo responsable, los cuales seran los usuarios que vayan a usar el sistema
        [HttpPost]
        [Route("Registro")]
        public IActionResult Registro([FromBody] List<ClaseRegistro> listaModelos)
        {
            try
            {

                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (listaModelos == null || listaModelos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var model in listaModelos)
                    {
                        {
                            // verificamos que no vengan ningun campo nulo
                            if (!string.IsNullOrEmpty(model.NombreNombreResponsable))
                            {
                                if (!string.IsNullOrEmpty(model.Contrasenia))
                                {
                                    if (!string.IsNullOrEmpty(model.Correo) && ValidadorCorreoElectronico.EsCorreoValido(model.Correo)) // En este caso verificamos tambien que venga
//                                                                                                                                        escrito un correo
                                    {
                                        if (!string.IsNullOrEmpty(model.UsuarioRed))
                                        {
                                            // Encriptamos la contraseña antes de guardarla en nuesttra base de datos
                                            string hashedPassword = Utils.GetSHA256(model.Contrasenia);


                                            
                                            // Guardamos todo en una variable
                                            var usuario = new Responsable
                                            {
                                                NombreNombreResponsable = model.NombreNombreResponsable,
                                                UsuarioRed = model.UsuarioRed.ToUpper(),
                                                Contrasenia = hashedPassword,
                                                Correo = model.Correo,
                                                IdPerfil = model.IdPerfil,

                                            };

                                            //al tener las variables disponibles las mandamos a la base de datos
                                            var resultado = segregacion.Add(usuario);

                                            // Y al final guardamos los cambios en el sistema
                                            segregacion.SaveChanges();
                                        }
                                        else
                                        {
                                            return BadRequest("El usuario de red es obligatorio.");
                                        }

                                    }
                                    else
                                    {
                                        return BadRequest("El formato del correo electrónico no es válido.");
                                    }

                                }
                                else
                                {
                                    return BadRequest("La contraseña es obligatoria.");
                                }

                            }
                            else
                            {
                                return BadRequest("El nombre es obligatorio.");
                            }

                        }
                    }
                }
                return Ok("Nuevo Responsable Registrado");
            }
            catch (Exception ex)
            {
                // Captura la excepción y muestra detalles
                Console.WriteLine($"Error: {ex.Message}");
                if (ex.InnerException != null)
                {
                    //Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                    return StatusCode(500, $"Error en el servidor: {ex.InnerException.Message}");
                }
                else {
                    return Ok("Nuevo Responsable Registrado");
                }
            }

        }
        
        // El siguiente metodo nos servira para poder hacer el login del sistema, el cual sera la forma de que vamos a diferenciar a los usuarios en el sistema
        [HttpPost]
        [Route("Login")]
        public ActionResult Login([FromBody] List<ClaseLogin> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {
                   
                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {
                        
                        // Verificamos si el usuario de red esta registrado en la base no sin antes convertir todo a mayusculas (Siempre tiene que ir en mayusculas para poder revisar la base de datos)
                        var usuario = db.Responsables.FirstOrDefault(p => p.UsuarioRed == campos.UsuarioRed.ToUpper());

                        // Si no se envia un usuario enviamos un mensaje de error
                        /*if (usuario == null)
                        {
                            var mensajeError = "El usuario de red o la contraseña no son validos.";
                            var respuesta = new
                            {
                                Mensaje = mensajeError
                            };
                            return NotFound(respuesta);
                        }*/

                        // Si se envian todos los datos encriptamos la contraseña y verificamos si esta registrada en la base de datos
                        var hashContraseniaIngresada = Utils.GetSHA256(campos.Contrasenia);

                        var permisosIds = db.PermisosPerfils
                        .Where(p =>p.IdPerfil == usuario.IdPerfil && p.Acceso == true)
                        .Select(p => p.IdDescripcionAcceso)
                        .ToList();

                        // Si la contraseña es valida enviamos toda la informacion que se necesite
                        if (hashContraseniaIngresada == usuario.Contrasenia)
                        {
                            var lista = new
                            {
                                IdResponsable = usuario.IdResponsable,
                                NombreResponsable = usuario.NombreNombreResponsable,
                                PermisosIds = permisosIds // Asigna la lista de IDs de permisos aquí
                            };
                            return Ok(lista); // Devuelve el contenido del objeto lista si todo sale bien
                        }
                        // Si la contraseña es incorrecta enviamos un mensaje de error

                        else
                        {
                            var mensajeError = "El usuario de red o la contraseña no son validos.";
                            var respuesta = new
                            {
                                Mensaje = mensajeError
                            };
                            return BadRequest(respuesta);
                        }
                    }

                    // Si llegamos aquí, no se encontraron errores
                    return Ok("");
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }
        //Prototipo Login
        /*[HttpGet]
        [Route("/Login")]
        public ActionResult GetLogin(string usuarioRed, string contrasenia)
        {
            using (SegregacionContext db = new SegregacionContext())
            {
                var usuario = db.Responsables.FirstOrDefault(p => p.UsuarioRed == usuarioRed.ToUpper());


                if (usuario == null)
                {
                    var mensajeError = "El usuario de red o la contraseña no son validos.";
                    var respuesta = new
                    {
                        Mensaje = mensajeError
                    };
                    return NotFound(respuesta);
                }


                var hashContraseniaIngresada = Utils.GetSHA256(contrasenia);

                if (hashContraseniaIngresada == usuario.Contrasenia)
                {
                    var lista = new
                    {
                        IdIdResponsable = usuario.IdResponsable,
                        NombreNombreResponsable = usuario.NombreNombreResponsable
                    };
                    return Ok(lista);
                }
                else
                {
                    var mensajeError = "El usuario de red o la contraseña no son validos.";
                    var respuesta = new
                    {
                        Mensaje = mensajeError
                    };
                    return BadRequest(respuesta);
                }
            }
        }*/

        /* Si se guarda una contraseña sin codificar se puede usar esta funcion para codificarla
         * [HttpGet("cambiarContrasena")]
        public IActionResult CambiarContrasena(int IdResponsable)
        {
            try
            {
                ClaseContra datosResponsable; // Declara la variable temporal

                using (SegregacionContext bd = new SegregacionContext())
                {
                    datosResponsable = (from a in bd.Responsables
                                        where a.IdResponsable == IdResponsable
                                        select new ClaseContra()
                                        {
                                            Contrasenia = a.Contrasenia,
                                        }).FirstOrDefault(); // Asigna el resultado a la variable temporal

                    if (datosResponsable != null)
                    {
                        // Calcula el hash SHA-256 de la contraseña actual
                        string hashedPassword = Utils.GetSHA256(datosResponsable.Contrasenia);

                        // Aquí puedes manipular la variable hashedPassword según tus necesidades
                          bd.Responsables.FirstOrDefault(a => a.IdResponsable == IdResponsable).Contrasenia = hashedPassword;
                          bd.SaveChanges();

                        return Ok("Datos obtenidos correctamente");
                    }
                    else
                    {
                        return NotFound("No se encontraron datos para el IdResponsable proporcionado.");
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al obtener los datos: {ex.Message}");
            }
        }*/


    }
}
