﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class PuestosRegionalesController : Controller
    {
        private readonly SegregacionContext _context;

        public PuestosRegionalesController(SegregacionContext context)
        {
            _context = context;
        }

        //Este metodo sirve para ingresar un nuevo puesto para que podamos utilizarla en todo el proceso del sistema
        [HttpPost]
        [Route("InsertarPuestoRegional")]
        public IActionResult InsertarPuestoRegional([FromBody] List<ClasePuestoRegional> datos)
        {
            try
            {

                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }



                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var Puesto in datos)
                    {
                        var puesto = new PuestosRegionale
                        {
                            IdPais = Puesto.IdPais,
                            IdEmpresa = Puesto.IdEmpresa,
                            IdDivision = Puesto.IdDivision,
                            IdDepto = Puesto.IdDepto,
                            IdPuestoLaboral = Puesto.value,
                            NdeUsuarios = Puesto.NdeUsuarios,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(puesto);
                    }

                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Puesto agregado exitosamente.");
            }
            catch (Exception ex)
            {
                // Captura la excepción y muestra detalles
                Console.WriteLine($"Error: {ex.Message}");
                if (ex.InnerException != null)
                {
                    //Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                    return StatusCode(500, $"Error en el servidor: {ex.InnerException.Message}");
                }
                else
                {
                    return Ok("Todo bien");
                }
            }
        }


        


    }
}
