﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class DeptoesController : Controller
    {
        private readonly SegregacionContext _context;

        public DeptoesController(SegregacionContext context)
        {
            _context = context;
        }


        [HttpGet("obtenerDepto")]
        public IActionResult obtenerDeptos()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseDepto2> lista1 = new List<ClaseDepto2>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla deptos y los guardamos en nuestro list
                    lista1 = (from a in bd.Deptos
                              select new ClaseDepto2()
                              {
                                  IdDepto = a.IdDepto,
                                  NombreDepto = a.NombreDepto,
                                  ActivoDepto = a.ActivoDepto,
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return Ok(new { data = lista1 });
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, $"Error al obtener los datos: {ex.Message}");
            }
        }

        //Este metodo sirve para ingresar un nuevo departamento para que podamos utilizarla en otros procesos que lo requieran
        // Entradas:
        // ClaseDepto: Clase que contiene las variables que vamos a recibir en el JSON
        //
        // Salidas:
        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error
        [HttpPost]
        [Route("InsertarDepto")]
        public IActionResult InsertarDepto([FromBody] List<ClaseDepto> datos)
        {
            try
            {
                // Primero verificamos que no se halla enviado el arreglo nulo o vacio

                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos

                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var depto in datos)
                    {
                        var entidadDepto = new Depto
                        {
                            NombreDepto = depto.NombreDepto,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadDepto);
                    }
                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Departamento Guardado");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }


        //Este metodo nos retorna los departamentos guardados en la base de datos para alimentar cualquier pantalla que lo necesite
        // Entradas:
        // 
        //
        // Salidas:
        // Lista de objetos con las variables de  la clase ClaseDepto2


    }
}
