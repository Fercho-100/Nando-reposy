﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class PaisController : Controller
    {
        private readonly SegregacionContext _context;

        public PaisController(SegregacionContext context)
        {
            _context = context;
        }



        //Este metodo sirve para ingresar un nuevo pais para que podamos utilizarlo en otros procesos que lo requieran
        [HttpGet("obtenerPaises")]
        public List<ClasePais2> obtenerPaises()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClasePais2> lista1 = new List<ClasePais2>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla aplicaciones y los guardamos en nuestro list
                    lista1 = (from a in bd.Pais

                              select new ClasePais2()
                              {
                                  IdPais = a.IdPais,
                                  NombrePais = a.NombrePais,
                                  AbreviacionPais = a.AbreviacionPais,
                                  ActivoPais = a.ActivoPais,

                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }


        [HttpPost]
        [Route("InsertarPais")]
        public IActionResult InsertarPais([FromBody] List<ClasePais> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {
                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var pais in datos)
                    {
                        var entidadPais = new Pai
                        {
                            NombrePais = pais.NombrePais,
                            AbreviacionPais = pais.AbreviacionPais,
                            ActivoPais = pais.
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadPais);
                    }

                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Pais Guardado");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }


        //Este metodo nos retorna los paises guardados en la base de datos para alimentar cualquier pantalla que lo necesite

       

        // Prototipo 
        /*       [HttpPost]
               [Route("insertarPais/{NombrePais}/{AbreviacionPais}")]
               public ActionResult InsertarPais(string NombrePais, string AbreviacionPais)
               {
                   try
                   {
                       using (SegregacionContext db = new SegregacionContext())
                       {
                           var nuevoPais = new Pai
                           {
                               NombrePais = NombrePais,
                               AbreviacionPais = AbreviacionPais
                           };

                           db.Pais.Add(nuevoPais);
                           db.SaveChanges();

                           return Ok("Pais Insertado Correctamente");
                       }
                   }
                   catch (Exception ex)
                   {
                       Console.WriteLine($"Error durante la insercion: {ex.Message}");

                       return StatusCode(500, "Error interno del servidor");
                   }
               }*/
    }
}
