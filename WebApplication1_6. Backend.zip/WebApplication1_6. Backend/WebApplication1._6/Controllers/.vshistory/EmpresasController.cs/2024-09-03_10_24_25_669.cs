﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class EmpresasController : Controller
    {
        private readonly SegregacionContext _context;

        public EmpresasController(SegregacionContext context)
        {
            _context = context;
        }

        //Este metodo sirve para ingresar una nueva Empresa para que podamos utilizarla en otros procesos que lo requieran
        // Entradas:
        // ClaseEmpresa: Clase que contiene las variables que vamos a recibir en el JSON
        //
        // Salidas:
        // Respuesta atravez de un mensaje indicando si la aplicación se agregó exitosamente o si hubo un error

        [HttpPost]
        [Route("InsertarEmpresa")]
        public IActionResult InsertarEmpresa([FromBody] List<ClaseEmpresa> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {
                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var Empresa in datos)
                    {
                        var entidadEmpresa = new Empresa
                        {
                            NombreEmpresa = Empresa.NombreEmpresa,
                            AbreviacionEmpresa = Empresa.AbreviacionEmpresa,
                            ActivoEmpresa = Empresa.ActivoEmpresa = true
                        };
                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadEmpresa);

                    }
                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Empresa agregada exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }

        //Este metodo nos retorna las empresas guardadas en la base de datos para alimentar cualquier pantalla que lo necesite
        // Entradas:
        // 
        //
        // Salidas:
        // Lista de objetos con las variables de la clase ClaseEmpresa2

        [HttpGet("obtenerEmpresas")]
        public List<ClaseEmpresa2> obtenerEmpresas()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseEmpresa2> lista1 = new List<ClaseEmpresa2>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla aplicaciones y los guardamos en nuestro list
                    lista1 = (from a in bd.Empresas

                              select new ClaseEmpresa2()
                              {
                                  IdEmpresa = a.IdEmpresa,
                                  NombreEmpresa = a.NombreEmpresa,
                                  AbreviacionEmpresa = a.AbreviacionEmpresa,
                                  ActivoEmpresa = a.ActivoEmpresa,
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }


    }
}
