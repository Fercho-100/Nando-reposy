﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class EmpleadoesController : Controller
    {
        private readonly SegregacionContext _context;

        public EmpleadoesController(SegregacionContext context)
        {
            _context = context;
        }

        //Este metodo nos retorna los empleados guardados en la base de datos para alimentar cualquier pantalla que lo necesite
        // Entradas:
        // 
        //
        // Salidas:
        // Lista de objetos con las variables de  la clase ClaseAplicaciones

        [HttpGet("obtenerEmpleados")]
        public List<ClaseEmpleados> obtenerEmpleados()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseEmpleados> lista1 = new List<ClaseEmpleados>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla empleados y los guardamos en nuestro list

                    lista1 = (from a in bd.Empleados

                              select new ClaseEmpleados()
                              {
                                  UsuarioRed = a.UsuarioRed,
                                  value = a.IdEmpleado,
                                  label = a.NombreEmpleado,
                                  ActivoEmpleado = a.ActivoEmpleado
                                  
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }


        //Este metodo sirve para ingresar un nuevo Empleado para que podamos utilizarla en otros procesos que lo requieran
        // Entradas:
        // ClaseAplicaciones2: Clase que contiene las variables que vamos a recibir en el JSON
        //
        //
        // Salidas:
        // Respuesta atravez de un mensaje indicando si el empleado se agregó exitosamente o si hubo un error
        [HttpPost]
        [Route("InsertarEmpleado")]
        public IActionResult InsertarEmpleado([FromBody] List<ClaseEmpleados2> datos)
        {
            try
            {
                /*// primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }*/

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {
                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var Empleado in datos)
                    {
                        var empleados = new Empleado
                        {
                            IdEmpleado = Empleado.IdEmpleado,
                            NombreEmpleado = Empleado.NombreEmpleado,
                            CorreoEmpleado = Empleado.CorreoEmpleado,
                            ActivoEmpleado = Empleado.ActivoEmpleado = true,
                        };
                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(empleados);
                    }
                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Empleado agregado exitosamente.");
            }
            catch (Exception ex)
            {
                // Captura la excepción y muestra detalles
                Console.WriteLine($"Error: {ex.Message}");
                if (ex.InnerException != null)
                {
                    //Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                    return StatusCode(500, $"Error en el servidor: {ex.InnerException.Message}");
                }
                else
                {
                    return BadRequest("Error desconocido");
                }
            }
        }
        


        //Prototipo
          /*[HttpPost]
            [Route("actualizarEmpleado")]
            public IActionResult ActualizarEmpleado([FromBody] List<ClaseUpdateEmpleado> datos)
            {
                try
                {
                    using (SegregacionContext db = new SegregacionContext())
                    {
                        foreach (var campos in datos)
                        {
                            var lista = db.PuestosRegionales.Find(campos.IdPuestosRegionales);
                            if (lista != null)
                            {
                                //lista.IdEmpleado = campos.IdEmpleado;
                                db.SaveChanges();
                            }

                        }
                    }
                    return Ok("Datos Insertados Correctamente");
                }
                catch (Exception ex)
                {

                    return StatusCode(500, "Error interno del servidor");
                }
            }*/
    }
}
