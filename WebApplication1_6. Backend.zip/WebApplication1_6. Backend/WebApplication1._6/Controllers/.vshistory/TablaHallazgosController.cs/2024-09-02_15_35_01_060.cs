﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Sockets;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class TablaHallazgosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("obtenerTablaHallazgos")]
        public List<ClaseCampos5> ObtenerTablaHallazgos()
        {
            //List<PuestosRegionale>lista = new List<PuestosRegionale>();
            //var Lista = new List<PuestosRegionale>();

            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseCampos5> lista3 = new List<ClaseCampos5>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla y tomamos los registros que esten completados y los guardamos en nuestro list
                    lista3 = (from pr in bd.MatrizHallazgos
                              join j in bd.PuestosRegionales on pr.IdPuestosRegionales equals j.IdPuestosRegionales
                              join p in bd.Pais on j.IdPais equals p.IdPais
                              join f in bd.Empresas on j.IdEmpresa equals f.IdEmpresa
                              join g in bd.PuestoLaborals on j.IdPuestoLaboral equals g.IdPuestoLaboral    
                              join e in bd.Estados on j.IdEstado equals e.IdEstado
                              join m in bd.Aplicacions on pr.IdAplicacion equals m.IdAplicacion
                              join n in bd.Criterios on pr.IdCriterio equals n.IdCriterio
                              join o in bd.Empresas on j.IdEmpresa equals o.IdEmpresa
                              join q in bd.Pais on j.IdPais equals q.IdPais
                              join r in bd.ResolucionHallazgos on pr.Resolucion equals r.IdResolucion
                              select new ClaseCampos5()
                              {
                                  id = pr.IdMatrizHallazgos,
                                  puesto = g.NombrePuestoLaboral,
                                  aplicacion = m.NombreAplicacion,
                                  menu = pr.NombreMenu,
                                  submenu = pr.NombreSubMenu,
                                  hallazgos = pr.Hallazgo,
                                  criterio = n.NombreCriterio,
                                  recomendaciones = pr.Recomendación,
                                  estado = e.NombreEstado,
                                  empresa = o.NombreEmpresa,
                                  pais = q.NombrePais,
                                  idPais = j.IdPais,
                                  idEmpresa = j.IdEmpresa,
                                  idPuesto = j.IdPuestoLaboral,
                                  Resolucion = r.Resolucion,
                                  EstadoHallazgo = pr.EstadoHallazgo,
                                  TiempoResolucion = pr.TiempoResolucion,
                                  EstadoAceptacion = pr.EstadoAceptacion,
                                  NotasInternas = pr.NotasInternas,
                                  PlanAccion = pr.PlanAccion,
                                  Ticket = pr.Ticket,



                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }

        [HttpGet("obtenerResoluciones")]
        public List<ClaseResoluciones> ObtenerResoluciones()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseResoluciones> lista1 = new List<ClaseResoluciones>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla y los guardamos en nuestro list
                    lista1 = (from a in bd.ResolucionHallazgos

                              select new ClaseResoluciones()
                              {
                                  IdResolucion = a.IdResolucion,
                                  Resolucion = a.Resolucion,
                              })
                              .OrderBy(r => r.Resolucion) // Ordena por cantidad de registros de mayor a menor

                              .ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }

        [HttpPost]
        [Route("actualizarResolucion")]
        public IActionResult ActualizarResponsables([FromBody] List<ClaseActualizarResolucion> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.MatrizHallazgos.Find(campos.id);

                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista != null)
                        {
                            lista.Resolucion = campos.resolucion;
                            db.SaveChanges();
                        }

                    }

                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpPost]
        [Route("actualizarEstadoHallazgo")]
        public IActionResult ActualizarEstadoHallazgo([FromBody] List<ClaseActualizarEstadoHallazgo> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.MatrizHallazgos.Find(campos.id);

                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista != null)
                        {
                            lista.EstadoHallazgo = campos.EstadoHallazgo;
                            db.SaveChanges();
                        }

                    }

                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpPost]
        [Route("actualizarAceptacion")]
        public IActionResult ActualizarAceptacion([FromBody] List<ClaseActualizarAceptacion> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.MatrizHallazgos.Find(campos.id);

                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista != null)
                        {
                            lista.EstadoAceptacion = campos.EstadoAceptacion;
                            db.SaveChanges();
                        }

                    }

                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpPost]
        [Route("actualizarTiempoResolucion")]
        public IActionResult ActualizarTiempoResolucion([FromBody] List<ClaseActualizarTiempoResolucion> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.MatrizHallazgos.Find(campos.id);

                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista != null)
                        {
                            lista.TiempoResolucion = campos.TiempoResolucion;
                            db.SaveChanges();
                        }

                    }

                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }


        //[HttpPost]
        //[Route("ingresarNotasInternas")]
        //public IActionResult actualizarNotasInternas([FromBody] List<ClaseActualizarNotasInternas> datos)
        //{
        //    try
        //    {
        //        // primero verificamos que no se halla enviado el arreglo nulo o vacio
        //        if (datos == null || datos.Count == 0)
        //        {
        //            return BadRequest("La lista de Datos está vacía o es nula");
        //        }

        //        // Guardamos en una variable el llamado a la base de datos
        //        using (SegregacionContext db = new SegregacionContext())
        //        {

        //            //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
        //            foreach (var campos in datos)
        //            {

        //                // Buscamos el puesto correspondiente con el vamos a trabajar
        //                var lista = db.MatrizHallazgos.Find(campos.id);

        //                // Si Existe el puesto ingresa los datos correspondientes
        //                if (lista != null)
        //                {
        //                    lista.NotasInternas = campos.NotasInternas;
        //                    db.SaveChanges();
        //                }

        //            }

        //        }
        //        return Ok("Datos Insertados Correctamente");
        //    }
        //    catch (Exception ex)
        //    {

        //        return StatusCode(500, "Error interno del servidor");
        //    }
        //}


        //[HttpPost]
        //[Route("ingresarPlanAccion")]
        //public IActionResult actualizarPlanAccion([FromBody] List<ClaseActualizarPlanAccion> datos)
        //{
        //    try
        //    {
        //        // primero verificamos que no se halla enviado el arreglo nulo o vacio
        //        if (datos == null || datos.Count == 0)
        //        {
        //            return BadRequest("La lista de Datos está vacía o es nula");
        //        }

        //        // Guardamos en una variable el llamado a la base de datos
        //        using (SegregacionContext db = new SegregacionContext())
        //        {

        //            //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
        //            foreach (var campos in datos)
        //            {

        //                // Buscamos el puesto correspondiente con el vamos a trabajar
        //                var lista = db.MatrizHallazgos.Find(campos.id);

        //                // Si Existe el puesto ingresa los datos correspondientes
        //                if (lista != null)
        //                {
        //                    lista.PlanAccion = campos.PlanAccion;
        //                    db.SaveChanges();
        //                }

        //            }

        //        }
        //        return Ok("Datos Insertados Correctamente");
        //    }
        //    catch (Exception ex)
        //    {

        //        return StatusCode(500, "Error interno del servidor");
        //    }
        //}


        //[HttpPost]
        //[Route("ingresarTicket")]
        //public IActionResult actualizarTicket([FromBody] List<ClaseActualizarTicket> datos)
        //{
        //    try
        //    {
        //        // primero verificamos que no se halla enviado el arreglo nulo o vacio
        //        if (datos == null || datos.Count == 0)
        //        {
        //            return BadRequest("La lista de Datos está vacía o es nula");
        //        }

        //        // Guardamos en una variable el llamado a la base de datos
        //        using (SegregacionContext db = new SegregacionContext())
        //        {

        //            //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
        //            foreach (var campos in datos)
        //            {

        //                // Buscamos el puesto correspondiente con el vamos a trabajar
        //                var lista = db.MatrizHallazgos.Find(campos.id);

        //                // Si Existe el puesto ingresa los datos correspondientes
        //                if (lista != null)
        //                {
        //                    lista.Ticket = campos.Ticket;
        //                    db.SaveChanges();
        //                }

        //            }

        //        }
        //        return Ok("Datos Insertados Correctamente");
        //    }
        //    catch (Exception ex)
        //    {

        //        return StatusCode(500, "Error interno del servidor");
        //    }
        //}

        [HttpPost]
        [Route("ingresartextboxs")]
        public IActionResult ActualizarCampos([FromBody] List<ClaseActualizarTextboxs> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.MatrizHallazgos.Find(campos.id);

                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista != null)
                        {
                            lista.NotasInternas = campos.NotasInternas;
                            lista.PlanAccion = campos.PlanAccion;
                            lista.Ticket = campos.Ticket;
                            db.SaveChanges();
                        }

                    }

                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }
    }
}
