﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class ListaCriteriosController : Controller
    {
        private readonly SegregacionContext _context;

        public ListaCriteriosController(SegregacionContext context)
        {
            _context = context;
        }

        //Este metodo nos retorna la lista de los criterios guardados en la base de datos para alimentar cualquier pantalla que lo necesite

        [HttpGet("obtenerListaCriterios")]
        public List<ClaseListaCriterios> obtenerListaCriterios()
        {

            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseListaCriterios> lista1 = new List<ClaseListaCriterios>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla ListaCriterios y los guardamos en nuestro list
                    lista1 = (from a in bd.ListaCriterios
                              where a.Estado == true
                              select new ClaseListaCriterios()
                              {
                                  IdListaCriterios = a.IdListaCriterios,
                                  Criterio = a.Criterio,
                                  Peso = a.Peso,
                                  Estado = a.Estado
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }

        //Este metodo sirve para ingresar un nuevo criterio de la lista de criterios del nivel de riezgo para que podamos utilizarla en otros procesos que lo requieran

        [HttpPost]
        [Route("InsertarListaCriterios")]
        public IActionResult InsertarListaCriterios([FromBody] List<ClaseListaCriterios2> datos)
        {
            try
            {

                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var ListaCriterios in datos)
                    {
                        var entidadListaCriterios = new ListaCriterio
                        {
                            Criterio = ListaCriterios.Criterio,
                            Peso = ListaCriterios.Peso,
                            Estado = ListaCriterios.Estado = true,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadListaCriterios);
                    }

                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Item de lista de criterios agregada exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }
    }
}
