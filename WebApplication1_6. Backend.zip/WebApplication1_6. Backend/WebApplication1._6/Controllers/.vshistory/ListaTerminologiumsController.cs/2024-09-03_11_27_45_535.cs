﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class ListaTerminologiumsController : Controller
    {
        private readonly SegregacionContext _context;

        public ListaTerminologiumsController(SegregacionContext context)
        {
            _context = context;
        }

        [HttpGet("obtenerListaTerminos")]
        public List<ClaseListaTerminologia2> obtenerListaTerminos()
        {

            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseListaTerminologia2> lista1 = new List<ClaseListaTerminologia2>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla aplicaciones y los guardamos en nuestro list
                    lista1 = (from a in bd.ListaTerminologia

                              select new ClaseListaTerminologia2()
                              {
                                  value = a.IdListaTerminologia,
                                  label = a.Nombre,
                                  Concepto = a.Concepto,
                                  ActivoLista = a.ActivoLista,
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }

        // El siguiente metodo nos sirve para poder ingresar conceptos los cuales nos servira para tener un diccionario de variables
        [HttpPost]
        [Route("InsertarListaTerminologia")]
        public IActionResult InsertarListaTerminologia([FromBody] List<ClaseListaTerminologia> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var Lista in datos)
                    {
                        var lista = new ListaTerminologium
                        {
                            Nombre = Lista.Nombre,
                            Concepto = Lista.Concepto,
                            ActivoLista = Lista.ActivoLista,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(lista);
                    }

                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Conceptos agregados exitosamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }


        //  En el siguiente metodo nos retorna los nombres clave del diccionario de variable los cuales nos servira para selleccionar cuales van a ser los conceptos
        // que vamos a necesitar en el informe

    }
}
