﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Generics;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class ResponsablesController : Controller
    {
        private readonly SegregacionContext _context;

        public ResponsablesController(SegregacionContext context)
        {
            _context = context;
        }


        //Este metodo nos retorna los responsables guardados en la base de datos para alimentar cualquier pantalla que lo necesite

        [HttpGet("obtenerResponsables")]
        public List<ClaseResponsables> obtenerResponsables()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseResponsables> lista1 = new List<ClaseResponsables>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla aplicaciones y los guardamos en nuestro list
                    lista1 = (from a in bd.Responsables
                              where a.Activo == true

                              select new ClaseResponsables()
                              {
                                  IdResponsable = a.IdResponsable,
                                  NombreNombreResponsable = a.NombreNombreResponsable
                              })
                              .OrderBy(r => r.NombreNombreResponsable) // Ordena por cantidad de registros de mayor a menor

                              .ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }


        // El siguiente metodo nos sirve para poder asignar el responsables que tendra cada puesto

        [HttpPost]
        [Route("actualizarResponsables")]
        public IActionResult ActualizarResponsables([FromBody] List<ClaseActualizarResponsable> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.PuestosRegionales.Find(campos.IdPuestosRegionales);
                        
                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista != null)
                        {
                            lista.IdResponsable = campos.IdResponsable;
                            lista.FechaAsignacion = DateOnly.FromDateTime(DateTime.Today); //Forma de actualizar automaticamente la variable de fecha de asignacion 
                            db.SaveChanges();
                        }

                    }

                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }
        /*
        [HttpGet("obtenerInformacionResponsables")]
        public List<ClaseResponsables2> obtenerInformacionResponsables()
        {
            List<ClaseResponsables2> lista1 = new List<ClaseResponsables2>();
            try
            {
                using (SegregacionContext bd = new SegregacionContext())
                {
                    lista1 = (from a in bd.Responsables
                              select new ClaseResponsables2()
                              {
                                  IdResponsable = a.IdResponsable,
                                  NombreNombreResponsable = a.NombreNombreResponsable,
                                  Correo = a.Correo,
                                  UsuarioRed = a.UsuarioRed,
                                  IdPerfil = a.IdPerfil,
                              }).ToList();

                    return lista1;
                }
            }
            catch (Exception ex)
            {
                // Aquí podrías manejar el error de manera más adecuada, como lanzar una excepción o registrar el error.
                throw new Exception("Error al obtener información de responsables: " + ex.Message);
            }
        }*/

        [HttpGet("obtenerInformacionResponsables")]
        public List<ClaseResponsables2> obtenerInformacionResponsables(int IdResponsable)
        {

            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseResponsables2> lista3 = new List<ClaseResponsables2>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla de puestos y tomamos los registros del responsable que lo0s este solicitando y los guardamos en nuestro list
                    lista3 = (from a in bd.Responsables
                              join b in bd.Perfils on a.IdPerfil equals b.IdPerfil
                              where a.IdResponsable == IdResponsable 
                              select new ClaseResponsables2()
                              {
                                  IdResponsable = IdResponsable,
                                  NombreNombreResponsable = a.NombreNombreResponsable,
                                  Correo = a.Correo,
                                  UsuarioRed = a.UsuarioRed,
                                  IdPerfil = a.IdPerfil,
                                  NombrePerfil= b.NombrePerfil,
                                  Activo= a.Activo

                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }

        [HttpDelete("EliminarUsuario")]
        public IActionResult EliminarUsuario(int idResponsableEliminar)
        {
            using (SegregacionContext bd = new SegregacionContext())
            {
                var entity = bd.Responsables.Find(idResponsableEliminar);
                bd.Responsables.Remove(entity);
                bd.SaveChanges();
            
            }

            return Ok("Usuario Eliminado");
        }

        [HttpPost]
        [Route("DesactivarUsuarios")]
        public IActionResult DesactivarUsuarios([FromBody] List<ClaseResponsables> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.Responsables.Find(campos.IdResponsable);

                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista != null)
                        {
                            lista.Contrasenia = null;
                            lista.Activo = false; //Forma de actualizar automaticamente la variable de fecha de asignacion 
                            db.SaveChanges();
                        }

                    }

                }
                return Ok("Usuario desactivado");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpPost]
        [Route("modificarResponsables")]
        public IActionResult ModificarResponsables([FromBody] List<ClaseResponsables3> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.Responsables.Find(campos.IdResponsable);

                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista == null)
                        { 
                            return NotFound();
                        
                        }

                        if (campos.NombreNombreResponsable != null && !string.IsNullOrWhiteSpace(campos.NombreNombreResponsable))
                        {

                            lista.NombreNombreResponsable = campos.NombreNombreResponsable;
                        }

                        if (campos.Correo != null && !string.IsNullOrWhiteSpace(campos.Correo))
                        {

                            lista.Correo = campos.Correo;
                        }

                        if (campos.UsuarioRed != null && !string.IsNullOrWhiteSpace(campos.UsuarioRed))
                        {

                            lista.UsuarioRed = campos.UsuarioRed;
                        }

                        if (campos.IdPerfil != null && campos.IdPerfil != default)
                        {
                            lista.IdPerfil = campos.IdPerfil;
                        }

                        if (campos.Contrasenia != null && !string.IsNullOrWhiteSpace(campos.Contrasenia))
                        {

                            string hashedPassword = Utils.GetSHA256(campos.Contrasenia);
                            lista.Contrasenia = hashedPassword;
                            lista.Activo = true;
                        }

                        db.SaveChanges();

                    }

                }
                return Ok("Datos Actualizados Correctamente");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }
        // Prototipo
        /*[HttpPost]
          [Route("actualizarResponsable/{IdPuestosRegionales}/{IdResponsable}")]
          public ActionResult ActualizarResponsable(int IdPuestosRegionales, int IdResponsable)
          {
          try
          {
          using (SegregacionContext db = new SegregacionContext())
          {
              var lista = db.PuestosRegionales.FirstOrDefault(item => item.IdPuestosRegionales == IdPuestosRegionales);
              if (lista != null)
              {
                  lista.IdResponsable = IdResponsable; // Actualiza el campo IdResponsable de la entidad lista
              }
              db.SaveChanges();

              return Ok("Datos Insertados Correctamente");
          }
          }
          catch (Exception ex)
          {


          return StatusCode(500, "Error interno del servidor");
          }
}*/
    }
}
