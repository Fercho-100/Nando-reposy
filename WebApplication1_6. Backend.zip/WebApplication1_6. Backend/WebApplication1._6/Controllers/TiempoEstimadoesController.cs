﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class TiempoEstimadoesController : Controller
    {
        private readonly SegregacionContext _context;

        public TiempoEstimadoesController(SegregacionContext context)
        {
            _context = context;
        }


        //Este metodo sirve para ingresar el tiempo estimado por cada aplicacion para que podamos utilizarla en el informe del puesto respectivo

        [HttpPost]
        [Route("InsertarTiempoEstimado")]
        public IActionResult InsertarTiempoEstimado([FromBody] List<ClaseTiempoEstimado> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var tiempo in datos)
                    {
                        var entidadTiempo = new TiempoEstimado
                        {
                            IdPuestosRegionales = tiempo.IdPuestosRegionales,
                            IdAplicacion  = tiempo.IdAplicacion,
                            TiempoEstimado1 = tiempo.TiempoEstimado1,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadTiempo);
                    }
                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Tiempo Estimado Guardado");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }

        [HttpGet("SelectAplicacionesParaTiempoEstimado")]
        public List<ClaseTiempoEstimado3> SelectAplicacionesParaTiempoEstimado(int IdPuestosRegionales)
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseTiempoEstimado3> lista3 = new List<ClaseTiempoEstimado3>();
            try
            {
                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla matrices para obtener toda la informacion y los guardamos en nuestro list
                    lista3 = (from pr in bd.MatrizHallazgos
                              join f in bd.Aplicacions on pr.IdAplicacion equals f.IdAplicacion
                              where pr.IdPuestosRegionales == IdPuestosRegionales
                              select new ClaseTiempoEstimado3()
                              {
                                  IdAplicacion = pr.IdAplicacion,
                                  Aplicacion = f.NombreAplicacion,
                              })
                              .Distinct() // Elimina duplicados
                              .ToList();

                    // Y por último, retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error, enviaremos la cadena vacía
                return lista3;
            }
        }

    }
}
