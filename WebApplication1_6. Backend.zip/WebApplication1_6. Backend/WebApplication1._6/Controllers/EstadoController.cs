﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class EstadoController : Controller
    {
        private readonly SegregacionContext _context;

        public EstadoController(SegregacionContext context)
        {
            _context = context;
        }



        // El siguiente metodo nos retorna cuales serian los accesos en global del sistema para posteriormente asignarselo al ultimo perfil registrado
        [HttpGet("obtenerlistaEstados")]
        public List<ClaseEstadoSeleccionado> obtenerlistaEstados()
        {
            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseEstadoSeleccionado> lista1 = new List<ClaseEstadoSeleccionado>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {
                    // Hacemos el llamado a la tabla aplicaciones y los guardamos en nuestro list
                    lista1 = (from a in bd.Estados
                              where a.IdEstado !=1 && a.IdEstado != 2 && a.IdEstado != 3 && a.IdEstado != 4 && a.IdEstado != 5
                              select new ClaseEstadoSeleccionado()
                              {
                                  IdEstado = a.IdEstado,
                                  NombreEstado = a.NombreEstado
                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista1;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista1;
            }
        }

        [HttpPost]
        [Route("actualizarEstados")]
        public IActionResult ActualizarEstados([FromBody] List<ClaseActualizarEstado> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext db = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var campos in datos)
                    {

                        // Buscamos el puesto correspondiente con el vamos a trabajar
                        var lista = db.PuestosRegionales.Find(campos.IdPuestosRegionales);

                        // Si Existe el puesto ingresa los datos correspondientes
                        if (lista != null)
                        {
                            lista.IdEstado = campos.IdEstado;
                            db.SaveChanges();
                        }

                    }

                }
                return Ok("Datos Insertados Correctamente");
            }
            catch (Exception ex)
            {

                return StatusCode(500, "Error interno del servidor");
            }
        }

    }


}
