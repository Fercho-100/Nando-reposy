﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class ResolucionHallazgoesController : Controller
    {
        private readonly SegregacionContext _context;

        public ResolucionHallazgoesController(SegregacionContext context)
        {
            _context = context;
        }


        // El siguiente metodo nos sirve para ingresar el nombre del nuevo perfil al cual se le asignaran permisos mas adelante
        [HttpPost]
        [Route("InsertarResolucion")]
        public IActionResult InsertarResolucion([FromBody] List<ClaseResolucion> datos)
        {
            try
            {
                // primero verificamos que no se halla enviado el arreglo nulo o vacio
                if (datos == null || datos.Count == 0)
                {
                    return BadRequest("La lista de Datos está vacía o es nula");
                }

                // Guardamos en una variable el llamado a la base de datos
                using (var segregacion = new SegregacionContext())
                {

                    //Encerramos lo enviado a un bucle foreach para poder manejar los registros enviados y guardarlos en consultas individuales
                    foreach (var perfil in datos)
                    {
                        var entidadPerfil = new ResolucionHallazgo
                        {
                            Resolucion = perfil.Resolucion,
                        };

                        //al tener las variables disponibles las mandamos a la base de datos
                        segregacion.Add(entidadPerfil);
                    }

                    // Y al final guardamos los cambios en el sistema
                    segregacion.SaveChanges();
                }

                return Ok("Nombre de la resolucion Guardado");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar los datos: {ex.Message}");
            }
        }
    }
}
