﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class TablaCompletadosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        /*
        //Este metodo nos retorna los puestos completados guardados en la base de datos para alimentar la pantalla respectiva

        [HttpGet("obtenerCamposCompletados")]
        public List<ClaseCampos> obtenerCamposCompletados(int IdResponsable)
        {
            //List<PuestosRegionale>lista = new List<PuestosRegionale>();
            //var Lista = new List<PuestosRegionale>();

            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseCampos> lista3 = new List<ClaseCampos>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla de puestos y tomamos los registros que esten completados y los guardamos en nuestro list
                    lista3 = (from pr in bd.PuestosRegionales
                              join p in bd.Pais on pr.IdPais equals p.IdPais
                              join f in bd.Empresas on pr.IdEmpresa equals f.IdEmpresa
                              join g in bd.PuestoLaborals on pr.IdPuestoLaboral equals g.IdPuestoLaboral
                              join j in bd.Divisions on pr.IdDivision equals j.IdDivision
                              join k in bd.Deptos on pr.IdDepto equals k.IdDepto
                              join l in bd.Estados on pr.IdEstado equals l.IdEstado
                              where pr.IdResponsable == IdResponsable && pr.IdEstado == 4
                              select new ClaseCampos()
                              {
                                  IdPuestosRegionales = pr.IdPuestosRegionales,
                                  NombrePuestoLaboral = g.NombrePuestoLaboral,
                                  Nombrepais = p.NombrePais,
                                  nombreEmpresa = f.NombreEmpresa,
                                  NombreDivision = j.NombreDivision,
                                  NombreDepto = k.NombreDepto,

                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }
        */
        [HttpGet("obtenerCamposCompletados")]
        public List<ClaseCampos4> obtenerCamposCompletados()
        {
            //List<PuestosRegionale>lista = new List<PuestosRegionale>();
            //var Lista = new List<PuestosRegionale>();

            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseCampos4> lista3 = new List<ClaseCampos4>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla de puestos y tomamos los registros que esten completados y los guardamos en nuestro list
                    lista3 = (from pr in bd.PuestosRegionales
                              join p in bd.Pais on pr.IdPais equals p.IdPais
                              join f in bd.Empresas on pr.IdEmpresa equals f.IdEmpresa
                              join g in bd.PuestoLaborals on pr.IdPuestoLaboral equals g.IdPuestoLaboral
                              join j in bd.Divisions on pr.IdDivision equals j.IdDivision
                              join k in bd.Deptos on pr.IdDepto equals k.IdDepto
                              join l in bd.Estados on pr.IdEstado equals l.IdEstado
                              join m in bd.Responsables on pr.IdResponsable equals m.IdResponsable
                              join e in bd.Estados on pr.IdEstado equals e.IdEstado
                              where pr.IdEstado != 1 && pr.IdEstado != 2 && pr.IdEstado != 3 && pr.IdEstado != 5
                              select new ClaseCampos4()
                              {
                                  IdPuestosRegionales = pr.IdPuestosRegionales,
                                  NombrePuestoLaboral = g.NombrePuestoLaboral,
                                  Nombrepais = p.NombrePais,
                                  nombreEmpresa = f.NombreEmpresa,
                                  NombreDivision = j.NombreDivision,
                                  NombreDepto = k.NombreDepto,
                                  NombreResponsable = m.NombreNombreResponsable,
                                  FechaRevision = pr.FechaRevision,
                                  Estado = e.NombreEstado


                              }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista3;
                }
            }
            catch (Exception ex)
            {

                // Si aparece un error enviaremos la cadena vacia
                return lista3;
            }
        }
    }
}
