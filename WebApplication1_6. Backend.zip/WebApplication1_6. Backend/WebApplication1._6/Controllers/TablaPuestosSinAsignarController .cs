﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1._6.Clases;
using WebApplication1._6.Models;

namespace WebApplication1._6.Controllers
{
    public class TablaPuestosSinAsignarController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //Este metodo nos retorna los puestos registrados sin asignar, esto para alimentar la pantalla respectiva

        [HttpGet("puestosSinAsignar")]
        public List<ClaseCampos> obtenerCampos()
        {

            // Creamos una lista para poder guardar los datos que vamos a obtener
            List<ClaseCampos> lista = new List<ClaseCampos>();
            try
            {

                // Guardamos en una variable el llamado a la base de datos
                using (SegregacionContext bd = new SegregacionContext())
                {

                    // Hacemos el llamado a la tabla de puestos y tomamos los  y los guardamos en nuestro list
                    lista = (from pr in bd.PuestosRegionales
                             join p in bd.Pais on pr.IdPais equals p.IdPais
                             join f in bd.Empresas on pr.IdEmpresa equals f.IdEmpresa
                             join g in bd.PuestoLaborals on pr.IdPuestoLaboral equals g.IdPuestoLaboral
                             join j in bd.Divisions on pr.IdDivision equals j.IdDivision
                             join k in bd.Deptos on pr.IdDepto equals k.IdDepto
                             where pr.IdResponsable == null
                             select new ClaseCampos()
                             {
                                 IdPuestosRegionales = pr.IdPuestosRegionales,
                                 NombrePuestoLaboral = g.NombrePuestoLaboral,
                                 Nombrepais = p.NombrePais,
                                 nombreEmpresa = f.NombreEmpresa,
                                 NombreDivision = j.NombreDivision,
                                 NombreDepto = k.NombreDepto,
                                 
                }).ToList();

                    // Y por ultimo retornamos esa lista al usuario
                    return lista;
                }
            }
            catch (Exception ex)
            {
                // Si aparece un error enviaremos la cadena vacia
                return lista;
            }
        }
    }
}
