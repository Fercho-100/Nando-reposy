﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1._6.Models;
using WebApplication1._6.Generics;

namespace WebApplication1._6.Controllers
{
    public class EvidenciasController : Controller
    {
        private readonly SegregacionContext _context;

        public EvidenciasController(SegregacionContext context)
        {
            _context = context;
        }
        //Prototipos para agregar y obtener imagenes de la base de datos (Los funcionales estan en los controladores de IngresarHallazgos e Informe)

        //[HttpPost]
        //[Route("insertarEvidenciasManual")]
        //public IActionResult UploadImages(List<IFormFile> imageFiles, int Id_matrizHallazgos)
        //{
        //    try
        //    {
        //        using (SegregacionContext db = new SegregacionContext())
        //        {
        //            foreach (var imageFile in imageFiles)
        //            {
        //                if (imageFile != null && imageFile.Length > 0)
        //                {
        //                    using (var memoryStream = new MemoryStream())
        //                    {
        //                        imageFile.CopyTo(memoryStream);
        //                        var imageBytes = memoryStream.ToArray();

        //                       // var encryptedImageBytes = AesEncryption.Encrypt(imageBytes);

        //                        db.Evidencias.Add(new Evidencia { Evidencia1 = imageBytes, IdMatrizHallazgos = Id_matrizHallazgos });
        //                        db.SaveChanges();
        //                    }
        //                }
        //            }
        //        }

        //        // Redirecciona a la página de éxito o muestra un mensaje al usuario
        //        return Ok("UploadSuccess");
        //    }
        //    catch (Exception ex)
        //    {
        //        // Manejo de la excepción: puedes registrar el error, mostrar un mensaje al usuario, etc.
        //        // Por ejemplo:
        //        // Log.Error($"Error al cargar imágenes: {ex.Message}");
        //        // return View("ErrorPage");
        //        return BadRequest($"Error al cargar imágenes: {ex.Message}"); 
        //    }
        //}

        [HttpPost]
        [Route("insertarEvidenciasManual")]
        public IActionResult UploadImages(List<IFormFile> imageFiles, int IdMatrizHallazgos)
        {
            try
            {
                using (SegregacionContext db = new SegregacionContext())
                {
                    foreach (var imageFile in imageFiles)
                    {
                        if (imageFile != null && imageFile.Length > 0)
                        {
                            using (var memoryStream = new MemoryStream())
                            {
                                imageFile.CopyTo(memoryStream);
                                var imageBytes = memoryStream.ToArray();

                                // Almacenar la imagen en la tabla de evidencias
                                db.Evidencias.Add(new Evidencia { Evidencia1 = imageBytes, IdMatrizHallazgos = IdMatrizHallazgos });
                                db.SaveChanges();
                            }
                        }
                    }
                }

                return Ok("UploadSuccess");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al cargar imágenes: {ex.Message}");
            }
        }




    }
}
